﻿=== PeepSo - BadgeOS Integration Plugin ===
Contributors: Septiyan, Eric, Matt Jasiukiewicz
Donate link: https://peepso.com
Tags: badge, badges, credly, achievement, award, reward, engagement, nomination, peepso, community, badgeos
Requires at least: 4.6
Tested up to: 4.9
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Integrates BadgeOS and PeepSo. Users can earn badges for their community engagement. The badges are displayed in users's profiles. When a badge is earned there's a corresponding activity created on PeepSo stream as well.

== Description ==

Integrates BadgeOS and PeepSo. Users can earn badges for their community engagement. The badges are displayed in users's profiles. When a badge is earned there's a corresponding activity created on PeepSo stream as well.

**Note:** For this integration to work you need both [BadgeOS plugin](http://wordpress.org/extend/plugins/badgeos/ "BadgeOS") as well as [PeepSo plugin](https://wordpress.org/plugins/peepso-core/ "BadgeOS").

The following is the list of PeepSo actions available in this integration:
*   **PeepSo Core:**

   *   Admin Approves User Account
   *   Change Profile Avatar
   *   Change Provile Cover
   *   Write a Post
   *   Write a Comment

* **FriendSo:** - Requires FriendSo Plugin to work. You can get it here: [FriendSo](https://www.peepso.com/downloads/friendso/ "FriendSo")

   *   Send a Friend Request
   *   Add a New Friend

* **MsgSo:** - Requires MsgSo Plugin to work. You can get it here: [MsgSo](https://www.peepso.com/downloads/msgso/ "MsgSo")

   *   Send a Message

* **Groups:** - Requires GroupSo Plugin to work. You can get it here: [GroupSo](https://www.peepso.com/downloads/groupso/ "GroupSo")

   *   Create a Group
   *   Join a Group
   *   Change Group Avatar
   *   Change Group Cover


== Installation ==


1. Install and activate and configure the free [BadgeOS plugin](http://wordpress.org/extend/plugins/badgeos/ "BadgeOS") to your WordPress site.
2. Install and activate and configure the free [PeepSo plugin](http://wordpress.org/plugins/peepso-core/ "PeepSo") to your WordPress site.
3. Install and PeepSo - BadgeOS Integration Plugin.
4. Activate the plugin through the 'Plugins' menu in WordPress
5. You're done. You can now proceed to configuring your Badges.

== Frequently Asked Questions ==

= Where can I create my own badges? =

You can definitely do that here: [Credly.com](https://credly.com/badge-builder/ "Badge Builder Tool") and use it to create your own badges.

= Can I get someone to design badges specifically for my community? =

Sure! Credly has professional services and you can definitely get them to create badges for you. You can do it here: [http://badgeos.org/services/badge-design/](http://badgeos.org/services/badge-design/ "Badge Design")

= Do you offer services to help us design, build or customize our BadgeOS site? =

Yes, we do. We especially enjoy working on innovative projects with forward-thinking teams extending achievement recognition into new environments and surfacing achievement in new ways. See [examples](http://badgeos.org/about/sample-sites/ "Sample pojects") and learn more at: [http://badgeos.org/services/badgeos-customization/](http://badgeos.org/services/badgeos-customization/ "BadgeOS Customization").

= Where should I report issues, bugs or suggestions? =

Please do all of the above in the designated group on our site: [PeepSo Community](https://peepso.com/community/ "PeepSo Community"). Register and go to Community > Groups > PeepSo - BadgeOS Integration Plugin group.


== Changelog ==

= ALL VERSIONS =
* For changelog please go to: [Changelog](https://peepso.com/changelog/ "Changelog")
