<?php PeepSoAdmin::admin_header(__('Getting Started', 'peepso-core'));?>
<div id="peepso" class="wrap">

	<div class='row'>
		<div class='col-xs-12 col-sm-6'>
				<?php echo $peepso_ws_mailchimp;?>
				<?php echo $peepso_ws_video;?>
		</div>
		<div class='col-xs-12 col-sm-6'>
				<?php echo $peepso_ws_pages;?>
				<?php echo $peepso_ws_bundles;?>
				<?php echo $peepso_ws_plugins;?>
		</div>
	</div>
</div>
