<?php echo $content; ?>
