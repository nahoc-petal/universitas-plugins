<div>
	<button class="ps-btn ps-btn-small ps-btn-full ps-btn-primary"><?php echo __('Load more', 'peepso-core'); ?></button>
</div>
