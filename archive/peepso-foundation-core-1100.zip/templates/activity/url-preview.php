<div class="url-preview">
	<div class="close"><a href="javascript:void(0);" class="remove-preview"><i class="ps-icon-remove"></i></a></div>
	<?php PeepSoTemplate::exec_template('activity', 'content-media', $media); ?>
</div>