<div class="ps-focus-profile-options ps-js-dropdown">
	<button type="button" class="ps-btn ps-btn-small ps-dropdown__toggle ps-js-dropdown-toggle" data-value="">
		<span class="ps-icon-cog"></span>
	</button>
	<div class="ps-dropdown__menu ps-js-dropdown-menu">
		<?php echo $profile_options; ?>
	</div>
</div>
