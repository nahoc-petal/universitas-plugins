<div class="reset-gap ps-clearfix">
	<form id="recoverpasswordform" name="recoverpasswordform" action="<?php PeepSo::get_page('recover'); ?>?submit" method="post" class="ps-form">
		<p><?php _e('We have sent you an email with password recovery instructions. Follow the link in the email to finish the process of resetting your password.', 'peepso-core'); ?></p>
	</form>
</div>
