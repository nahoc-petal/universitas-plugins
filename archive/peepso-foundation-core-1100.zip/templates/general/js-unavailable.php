<noscript>
<div class="alert alert-error pstd-important">
	<span style="color: #ff0000;">Please Note:</span> PeepSo requires the use of Javascript
	for proper operation. Please enable Javascript in order to experience the full capabilities
	of the application. You may also visit our website for
	<a href="http://peepso.com/enabling-javascript">more information about enabling Javascript.</a>
	Thank you!
</div>
</noscript>
