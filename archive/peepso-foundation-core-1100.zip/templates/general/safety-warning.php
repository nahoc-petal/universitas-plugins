<div role="tooltip" tabindex="0" aria-labelledby="field-<?php echo $id; ?>" class="ps-fieldbubble__wrapper ps-js-safety-warning">
	<div class="ps-fieldbubble">
		<div class="ps-fieldbubble__message" id="field-<?php echo $id; ?>"><?php echo $message; ?></div>
		<a href="javascript:" aria-label="<?php _e('Close message', 'peepso-core'); ?>" class="ps-fieldbubble__close ps-icon-remove ps-js-close"></a>
	</div>
</div>
