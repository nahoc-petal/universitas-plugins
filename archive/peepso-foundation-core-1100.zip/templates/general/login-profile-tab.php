<h4 class="ps-page-title-single"><?php echo __('Please login', 'peepso-core');?></h4>
<?php PeepSoTemplate::exec_template('general','login');?>