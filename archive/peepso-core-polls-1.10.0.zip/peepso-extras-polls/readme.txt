=== PeepSo Polls ===
Contributors: peepso, JaworskiMatt, rsusanto
Donate link: http://www.peepso.com
Tags: PeepSo, polls, polling, Stream, Social, Sharing, facebook, social network, private social network
Requires at least: 4.6
Tested up to: 4.9
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==

PeepSo polls


== Changelog ==
= ALL VERSIONS =
* See full changelog here: [PeepSo Changelog](https://www.peepso.com/changelog/ "PeepSo Changelog")

