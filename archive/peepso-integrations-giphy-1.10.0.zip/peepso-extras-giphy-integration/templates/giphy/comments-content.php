<div class="cstream-attachment giphy-attachment">
	<div class="ps-media--giphy ps-clearfix ps-js-giphy">
		<img src="<?php echo $giphy;?>">
		<!-- <div class="ps-media-loading ps-js-loading">
			<div class="ps-spinner">
				<div class="ps-spinner-bounce1"></div>
				<div class="ps-spinner-bounce2"></div>
				<div class="ps-spinner-bounce3"></div>
			</div>
		</div> -->
	</div>
</div>
