<div class="ps-commentbox__addon ps-js-addon-giphy" style="display:none">
	<div class="ps-popover__arrow ps-popover__arrow--up"></div>
	<img class="ps-js-img" alt="photo" src="<?php echo isset($src) ? $src : ''; ?>" />
	<div class="ps-commentbox__addon-remove ps-js-remove">
		<i class="ps-icon-remove"></i>
	</div>
</div>
