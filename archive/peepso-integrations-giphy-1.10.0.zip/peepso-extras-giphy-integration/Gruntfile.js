module.exports = function( grunt ) {

	grunt.initConfig({

		browserify: {
			dist: {
				src: [ 'assets/js/*.js' ],
				dest: 'assets/js/dist/bundle.js'
			}
		},

		uglify: {
			dist: {
				options: {
					report: 'none',
					sourceMap: true
				},
				files: [{
					src: [ 'assets/js/dist/bundle.js' ],
					expand: true,
					ext: '.min.js'
				}]
			}
		}

	});

	grunt.loadNpmTasks('grunt-browserify');
	grunt.loadNpmTasks('grunt-contrib-uglify');

	grunt.registerTask('default', [ 'browserify', 'uglify' ]);

};
