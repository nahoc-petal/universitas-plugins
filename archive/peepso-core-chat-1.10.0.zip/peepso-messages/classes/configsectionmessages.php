<?php

class PeepSoConfigSectionMessages extends PeepSoConfigSectionAbstract
{
	// Builds the groups array
	public function register_config_groups()
	{
		$this->context='left';
		$this->group_messages();

		$this->context='right';
		$this->group_chat();
	}


	/**
	 * General Settings Box
	 */
	private function group_messages()
	{
		$section = 'messages_';

		// # Enable "read" notifications
		$this->set_field(
			'messages_read_notification',
			__('Enable "read" notifications', 'msgso'),
			'yesno_switch'
		);

		// # Message length limit
		$this->args('int', TRUE);
		$this->args('validation', array('required','numeric'));

		$this->set_field(
			'messages_limit',
			__('Character limit per message', 'peepso-hello-world'),
			'text'
		);

		$this->set_group(
			'peepso_messages',
			__('Messages', 'msgso')
		);
	}

	/**
	 * Custom Greeting Box
	 */
	private function group_chat()
	{
		// # Use Custom Greeting
		$this->args('default', 1);

		$this->set_field(
			'messages_chat_enable',
			__('Enable Chat', 'msgso'),
			'yesno_switch'
		);

		$this->set_field(
			'messages_get_chats_longpoll',
			__('Forced Long Poll', 'msgso'),
			'yesno_switch'
		);


		$this->set_field(
			'messages_get_chats_longpoll_desc',
			__('Send an extra ajax call every 30 seconds to make sure that messages and chat is synchronized between multiple open browser windows or devices.', 'msgso'),
			'message'
		);

		$this->set_group(
			'peepso_messages_chat',
			__('Chat', 'msgso')
		);
	}
}