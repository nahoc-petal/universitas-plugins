<?php
$PeepSoMessages = PeepSoMessages::get_instance();
?>
<form action="" class="ps-form ps-form-search ps-form-search-messages" role="form" onsubmit="return false;">
	<input type="text" class="ps-input search-query" name="query" aria-describedby="queryStatus" value="<?php echo esc_attr($query);?>" placeholder="<?php echo esc_attr(__('Search by content, or user', 'msgso')); ?>" />
	<button type="submit" class="ps-btn"><i class="ps-icon-search"></i></button>
	<div class="ps-list-loader" style="display: none;">
		<img src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>" alt="" />
	</div>
</form>

<?php if ($total <= 0) { ?>
<div id="ps-no-posts" class="app-box-footer"><?php _e('No messages found.' ,'msgso'); ?></div>
<?php } else { ?>
<form class="ps-form" action="<?php PeepSo::get_page('messages');?>" method="post">
	<?php wp_nonce_field('messages-bulk-action', '_messages_nonce'); ?>
	<div class="ps-messages">
		<div class="ps-messages-actions">
			<div class="ps-messages-check">
				<input type="checkbox" id="messages-check" onclick="ps_messages.toggle_checkboxes(this)" value="" />
				<label for="messages-check"></label>
			</div>
			<div class="ps-messages-options">
				<?php $PeepSoMessages->display_bulk_actions($type); ?>
				<button type="button" class="ps-btn ps-btn-small bulk-action-button"><?php _e('Apply', 'msgso')?></button>
			</div>
		</div>
		<div class="ps-messages-wrapper">
			<?php
				while ($message = $PeepSoMessages->get_next_message()) {
					$PeepSoMessages->show_message($message);
				}
			?>
		</div>
	</div>
</form>

<div class="ps-pagination">
	<ul class="ps-list">
		<li class="ps-pagination-prev">
			<a href="#" class="ps-load-prev"><i class="ps-icon-caret-left"></i></a>
		</li>
		<li class="ps-pagination-total">
			<span><?php $PeepSoMessages->display_totals();?></span>
		</li>
		<li class="ps-pagination-next">
			<a href="#" class="ps-load-next"><i class="ps-icon-caret-right"></i></a>
		</li>
	</ul>
</div>
<?php } ?>
