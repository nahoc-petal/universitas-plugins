<?php
$PeepSoActivity = PeepSoActivity::get_instance();
$PeepSoMessages = PeepSoMessages::get_instance();
$PeepSoUser = PeepSoUser::get_instance($post_author);
?>
<div class="ps-messages-item <?php echo ($mrec_viewed) ? '' : 'unread'; ?>">
	<div class="ps-comment-item">
		<div class="ps-messages-check">
			<input name="messages[]" type="checkbox" id="<?php echo $ID; ?>" value="<?php echo $ID; ?>" />
			<label for="<?php echo $ID; ?>"></label>
		</div>
		<div class="ps-avatar-comment">
			<a href="<?php echo $PeepSoMessages->get_message_url();?>">
				<?php echo $PeepSoMessages->get_message_avatar(array('post_author' => $post_author, 'post_id' => $ID)); ?>
			</a>
		</div>
		<div class="ps-comment-body" onclick="window.location = '<?php echo $PeepSoMessages->get_message_url(); ?>'">
			<span class="ps-comment-user">
				<!--<a href="<?php echo $PeepSoUser->get_profileurl(); ?>">-->
					<?php
					$args = array(
						'post_author' => $post_author, 'post_id' => $ID
					);
					$PeepSoMessages->get_recipient_name($args);
					?>
				<!--</a>-->
			</span>
			<span class="ps-comment-time date" data-timestamp="<?php $PeepSoActivity->post_timestamp(); ?>">
				<small><?php $PeepSoActivity->post_age(); ?></small>
			</span>
			<div class="ps-messages-title">
				<?php
				$PeepSoMessages->get_last_author_name($args);
				echo $PeepSoMessages->get_conversation_title(); ?>
			</div>
		</div>
	</div>
</div>
