<a class="ps-conversation-photo-item" href="javascript:" onclick="return ps_messages.open_image('<?php echo $location; ?>');">
	<img src="<?php echo $pho_thumbs['s_s']; ?>" />
</a>