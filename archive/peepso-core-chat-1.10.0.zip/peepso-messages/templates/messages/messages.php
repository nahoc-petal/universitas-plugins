<div class="peepso">
  <?php PeepSoTemplate::exec_template('general','navbar'); ?>
  <section id="mainbody" class="ps-page-unstyled">
    <h4 class="ps-page-title"><?php _e('My Messages', 'msgso'); ?></h4>
    <section id="component" role="article" class="ps-clearfix">      
            <?php wp_nonce_field('load-messages', '_messages_nonce'); ?>
            <div class="ps-page-actions">
              <?php do_action('peepso_messages_list_header'); ?>
            </div>
            <div class="tab-content">
        <div class="tab-pane active" id="inbox">
        </div>

        <div class="tab-pane ps-messages-sent" id="sent">
        </div>
      </div>
    </section><!--end component-->
  </section><!--end mainbody-->
</div><!--end row-->
<script type="text/javascript">
    jQuery(document).ready(function() {
        ps_messages.load_messages('inbox', 1);
    });
</script>
<?php PeepSoTemplate::exec_template('activity', 'dialogs'); ?>