<div class="ps-comment-item">
	<div class="ps-avatar-comment">
		<a href="javacript:">
			<img src="<?php echo $user->get_avatar();?>"
				 alt="<?php echo $user->get_fullname();?>"
				 title="<?php echo $user->get_fullname();?>"
				 class="ps-name-tips ps-messages-currently-typing">
		</a>
	</div>
	<div class="ps-comment-body">
		<a href="javascript:"><?php echo $user->get_fullname();?></a>
		<div class="ps-comment-content">
			<!-- CSS typing indicator -->
			<div class="ps-typing-indicator">
				<span></span>
				<span></span>
				<span></span>
			</div>
		</div>
	</div>
</div>