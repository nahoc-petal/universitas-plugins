<?php
$PeepSoPostbox = PeepSoPostbox::get_instance();
$PeepSoMessages= PeepSoMessages::get_instance();
$PeepSoGeneral = PeepSoGeneral::get_instance();

// Conversation flags.
$muted = isset($muted) && $muted;
$read_notification = isset($read_notification) && $read_notification;
#$notif = isset($notif) && $notif;

?>
<div class="peepso">
	<?php PeepSoTemplate::exec_template('general', 'navbar'); ?>
	<section id="mainbody" class="ps-page-messages">
		<section id="component" role="article" class="ps-clearfix">

			<div id="add-recipients-button-container" class="ps-messages-header">
				<div class="ps-messages-participants">
					<span id="participant-summary">
						<span class="ps-messages-status"><span class="ps-icon-clock"></span></span>
						<?php $PeepSoMessages->display_participant_summary();?>
					</span>
				</div>
				<div class="ps-messages-add-users">
					<a id="add-recipients-toggle" title="<?php _e('Add People to the conversation', 'msgso');?>" href="javascript:void(0);"><i class="ps-icon-user-add"></i></a>
					<?php if ($read_notification) { ?>
					<a class="ps-js-btn-toggle-checkmark" title="<?php $notif ? _e("Don't send read receipt", 'msgso') : _e('Send read receipt', 'msgso'); ?>"
						href="javascript:void(0);"
						onclick="return ps_messages.toggle_checkmark(<?php echo $parent->ID;?>, <?php echo $notif ? 0 : 1 ?>);"
					>
						<i class="ps-icon-ok<?php echo $notif ? '' : ' disable-checkmark' ?>"></i>
					</a>
					<?php } ?>
					<a class="ps-js-btn-mute-conversation" title="<?php $muted ? _e('Unmute conversation', 'msgso') : _e('Mute conversation', 'msgso'); ?>"
						href="javascript:void(0);"
						onclick="return ps_messages.<?php echo $muted ? 'unmute' : 'mute'; ?>_conversation(<?php echo $parent->ID;?>, <?php echo $muted ? 0 : 1; ?>);"
					>
						<i class="<?php echo $muted ? 'ps-icon-bell-off' : 'ps-icon-bell-alt'; ?>"></i>
					</a>
					<a title="<?php _e('Leave this conversation', 'msgso');?>"
						href="<?php echo $PeepSoMessages->get_leave_conversation_url();?>"
						onclick="return ps_messages.leave_conversation('<?php _e('Are you sure you want to leave this conversation?', 'msgso'); ?>', this)"
					>
						<i class="ps-icon-minus-sign"></i>
					</a>
				</div>
			</div>

			<div id="add-recipients-div" class="ps-messages-recipients" style="display:none;position:relative">
				<select name="recipients" id="recipients-search"
					data-placeholder="<?php _e('Add People to the conversation', 'msgso');?>"
					data-loading="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>"
					multiple></select>
				<?php wp_nonce_field('add-participant', 'add-participant-nonce'); ?>
				<button class="ps-btn ps-btn-success ps-btn-small" onclick="ps_messages.add_recipients(<?php echo $parent->ID;?>);">
					<?php _e('Done', 'msgso'); ?>
					<img src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>" style="display:none;margin-left:5px">
				</button>
				<div id="recipients-disabler" style="position:absolute;top:0;right:0;left:0;bottom:0;display:none;background:#FFF;opacity:.7"></div>
			</div>

			<div class="ps-messages-chat">
				<div class="ps-comment-loading" style="display:block">
					<img src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>">
				</div>
				<div class="ps-js-currently-typing"></div>
			</div>

			<div class="ps-messages-postbox">
				<div id="postbox-message" class="ps-postbox ps-postbox--messages ps-clearfix" style="">
					<?php $PeepSoPostbox->before_postbox(); ?>
					<div id="ps-postbox-status" class="ps-postbox-content">
						<div class="ps-postbox-tabs">
							<?php $PeepSoPostbox->postbox_tabs(); ?>
						</div>
						<?php PeepSoTemplate::exec_template('general', 'postbox-status'); ?>
					</div>
					<nav class="ps-postbox-tab ps-postbox-tab-root ps-clearfix">
						<div class="ps-postbox__menu">
							<?php $PeepSoGeneral->post_types(); ?>
						</div>
					</nav>
					<nav class="ps-postbox-tab selected interactions" style="display: none;">
						<div class="ps-postbox__menu">
							<?php $PeepSoPostbox->post_interactions(); ?>
						</div>
						<div class="ps-postbox__action ps-postbox-action">
							<span class="ps-checkbox ps-checkbox--enter">
								<input type="checkbox" id="enter-to-send" class="ps-js-checkbox-entertosend">
								<label for="enter-to-send"><?php _e('Press "Enter" to send', 'msgso'); ?></label>
							</span>
							<span>
								<button type="button" class="ps-btn ps-btn--postbox ps-button-cancel"><?php _e('Cancel', 'msgso'); ?></button>
								<button type="button" class="ps-btn ps-btn--postbox ps-button-action postbox-submit" style="display: none;"><?php _e('Send', 'msgso'); ?></button>
							</span>
						</div>
						<div class="ps-edit-loading" style="display: none;">
							<img src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>">
							<div> </div>
						</div>
					</nav>
					<?php $PeepSoPostbox->after_postbox(); ?>
				</div>
			</div>
		</section>
	</section>
</div>
<script>
	jQuery(document).ready(function() {
		ps_messages.init_conversation_view(<?php echo $parent->ID; ?>);
	});
</script>
<?php PeepSoTemplate::exec_template('activity', 'dialogs'); ?>
