<div class="ps-chat-sidebar">
	<div class="ps-chat-sidebar-box">
		<div class="ps-chat-sidebar-items"></div>
		<div class="ps-chat-sidebar-label">
			<div class="ps-chat-sidebar-notif">0</div>
			<span></span> <?php echo __('more', 'msgso') ?>
		</div>
	</div>
</div>
