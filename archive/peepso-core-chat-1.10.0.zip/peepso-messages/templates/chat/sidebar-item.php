<div class="ps-chat-sidebar-item ps-chat-sidebar-item-{id} ps-clearfix" data-id="{id}">
	<div class="ps-chat-sidebar-notif">&nbsp;</div>
	<span class="ps-chat-sidebar-caption"><?php echo __('Loading', 'msgso');?>&hellip;</span>
	<div class="ps-chat-icons ps-clearfix">
		<div class="ps-chat-icon ps-chat-close icon-cancel-squared" data-id="{id}"></div>
	</div>
</div>
