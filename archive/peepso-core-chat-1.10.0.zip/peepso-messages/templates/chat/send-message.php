<div class="ps-conversation-item my-message">
    <div class="ps-conversation-body">
        <div class="ps-conversation-content"><p>{content}</p></div>
        <div class="ps-conversation-attachment"></div>
        <div class="ps-conversation-time">
            <small>
                <span><?php echo __('just now', 'msgso'); ?></span>
                <span class="ps-icon-ok"></span>
            </small>
        </div>
    </div>
</div>
