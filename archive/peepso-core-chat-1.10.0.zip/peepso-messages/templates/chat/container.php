<div id="ps-chat-root" class="ps-chat-root">
	<div class="ps-chat-wrapper ps-clearfix">
		<div class="ps-chat-windows"></div>
	</div>
</div>
