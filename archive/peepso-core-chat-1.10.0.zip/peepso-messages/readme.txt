=== Plugin Messages ===
Contributors: peepso, JaworskiMatt, rsusanto
Donate link: http://www.peepso.com
Tags: PeepSo, social network, social media, community, stream, pages, acl, activity, profile, notifications, social, networking, messages, messaging, message
Requires at least: 4.6
Tested up to: 4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
MsgSo adds private messaging between members of a community. With the appropriate plugins those messages can also display photos, moods, videos and location attachments. A message icon on the toolbar displays alerts when new messages are received.

Users can compose new messages by clicking the ‘New Message’ button on the Messages page, search for messages, take bulk actions like “mark as read,” “mark as unread” or delete, and browse lists of both personal and group discussions.

Other users can click an envelope icon on their profiles to send a direct message.

== Frequently Asked Questions ==

= What's the automated upgrade procedure? =

First you need to update the ChatSo plugin. Then all the other supporting plugins. PeepSo Core plugin must be updated last.

= Can I just use MsgSo on my website? =

For MsgSo to work, you need to have PeepSo installed and activated. MsgSo is not a standalone plugin for WordPress.


== Changelog ==
= ALL VERSIONS =
* See full changelog here: [PeepSo Changelog](https://www.peepso.com/changelog/ "PeepSo Changelog")

= 1.7.0 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.7.0
* Fix User keeps receiving new message notification when setting is off 

= 1.6.3 =
* Impr Compatibility with PeepSo 1.6.3.
* Impr Generated new .POT file.

= 1.6.2 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.6.2
* Impr Notifications improvements.
* Impr Rendering of Location and Mood.

= 1.6.1 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.6.1

= 1.6.0 =
* New 'Send Read Receipts' notifications in Chat and Messages. 
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.6.0

= 1.5.7 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.5.7

= 1.5.6 =
* Impr Compatibility with PeepSo 1.5.6
* Impr Updated Language file.
* Fix The unread message notification still shows when new message is deleted 

= 1.5.5 =
* Impr Compatibility with PeepSo 1.5.5
* Impr Updated Language file.
* Impr Renamed the plugin from PeepSo [X] to PeepSo Core [X] 

= 1.5.4 =
* Impr Compatibility with PeepSo 1.5.4
* Impr Updated Language file.

= 1.5.3 =
* Impr Compatibility with PeepSo 1.5.3
* Impr Updated Language file.
* Fix Styling issue on postbox in mobile view.

= 1.5.2 =
* Impr Compatibility with PeepSo 1.5.2
* Impr Updated Language file.

= 1.5.1 =
* Impr Compatibility with PeepSo 1.5.1
* Impr Updated Language file.

= 1.5.0 =
* Impr Compatibility with PeepSo 1.5.0
* Impr Updated Language file.

= 1.4.2 =
* Impr Compatibility with PeepSo 1.4.2
* Impr Updated Language file.

= 1.4.1 =
* Impr Compatibility with PeepSo 1.4.1
* Impr Updated Language file.
* Impr Email notifications for messages (and chat).
* Fix After sending a 'long message' the postbox doesn't reset the size to the default size. 

= 1.4.0 =
* New Support for ChatSo plugin
* Impr Compatibility with PeepSo 1.4.0
* Impr Updated Language file.
* Impr Group conversations handling.

= 1.3.0 =
* Impr Compatibility with PeepSo 1.3.0
* Impr Updated Language file.

= 1.2.1 =
* Impr Compatibility with PeepSo 1.2.1
* Impr Updated Language file.
* Impr Added a .gif to indicate that the messages are loading.
* Impr Enter to send change styling issues in mobile view.
* Fix Displaying duplicated messages.

= 1.2.0 =
* New Ajaxified Messages
* Impr Compatibility with PeepSo 1.2.0
* Impr Indicate when someone’s typing a message…
* Impr Improve spacing between lines in Messages.
* Impr Add loading indicator when searching members on Members Page.
* Impr Notifications layout.
* Impr Added ‘Who said what’ in Messages.
* Impr Layout of Photos in Messages
* Impr Added ‘Press “Enter” to send’ in Messages Postbox.
* Impr Improving the visual aspect of the ‘write message modal’.
* Fix Added .POT language file.

= 1.1.0 =
* Impr Compatibility with PeepSo 1.1.0

= 1.0.1 =
* Impr Compatibility with PeepSo 1.0.1

= 1.0.0 =
* Impr Compatibility with PeepSo 1.0.0
* Impr Photo attachments in messages only showing up to 5 first images.

= 1.0.0 RC4 =
* Impr Compatibility with PeepSo 1.0.0 RC4
* Fix Sending a photo in a private message puts those photos in widgets and under profiles.
* Fix Remove the privacy option from messages PostBox.
* Fix Photo attachment to messages breaks message list.

= 1.0.0 RC1 =
* New Initial release of MsgSo plugin.
