=== PeepSo Extended Profiles ===
Contributors: peepso, JaworskiMatt, rsusanto
Donate link: http://www.peepso.com
Tags: PeepSo, GeoLocation, Map, Location, Stream, Social, Localization, Sharing, Share location, facebook, social network, private social network
Requires at least: 4.6
Tested up to: 4.9
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
ProfileSo lets admins place additional fields on user profiles to create richer, more meaningful profile pages. Creation of the fields is completely Ajaxified; everything is done on the same page without the need to save and refresh. On the front end, the user can also edit their profile fields smoothly and seamlessly.

The profile field types that are currently available are:

* Multi select
* Single select
* Email
* Date
* Text
* URL
* Separators (These act like section headers, dividing fields into meaningful groups such as personal information, work, and education.)

== Installation ==

= From your WordPress dashboard =

1. Make sure you have [PeepSo](https://wordpress.org/plugins/peepso-core/ "PeepSo - Social Network Plugin for WordPress") installed and activated.
2. Visit "Plugins > Add New"
3. Search for "PeepSo Location"
4. Press install
5. Activate PeepSo from your Plugins page.


= From WordPress.org =

1. Make sure you have [PeepSo](https://wordpress.org/plugins/peepso-core/ "PeepSo - Social Network Plugin for WordPress") installed and activated.
2. Download PeepSo Location.
3. Navigate to the Admin area of your site.
4. Go to Plugins > "Add New".
5. Select "Upload Plugin".
6. Select the ZIP installation file of PeepSo Location.
7. Activate PeepSo Location from your Plugins page.


== Screenshots ==
1. 
2. 
3. 

== Try the demo ==
 
If you want to see how a **social networking** on WordPress looks live, you can visit our [demo site](http://peepso.com/demo "PeepSo Demo"). You will be able to log in as a real user (username: demo, password: demo) and take LocSo for a test drive in a real PeepSo environment. The demo includes all other premium plugins so you'll be able to see them all in action.
 
== Frequently Asked Questions ==

= What's the best order in which to upgrade? =

First you need to update the ChatSo plugin. Then all the other supporting plugins. PeepSo Core plugin must be updated last.

= Can I just use LocSo on my website? =

For ProfileSo to work, you need to have PeepSo installed and activated. ProfileSo is not a standalone plugin for WordPress.
 

== Changelog ==
= ALL VERSIONS =
* See full changelog here: [PeepSo Changelog](https://www.peepso.com/changelog/ "PeepSo Changelog")

= 1.7.0 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.7.0
* Impr Support for GroupSo plugin.
* Impr Refactor the admin tab hooks

= 1.6.3 =
* New Full Registration with Core + EP fields.
* Impr Compatibility with PeepSo 1.6.3.
* Impr Generated new .POT file.

= 1.6.2 =
* New Duplicate a custom field.
* Impr Compatibility with PeepSo 1.6.2.
* Impr Generated new .POT file.
* Impr Handling of "empty" separators.
* Fix Field validation on Edit Profile.
* Fix Cannot edit firstname and lastname.
* Fix Cannot set firstname and lastname as required fields.
* Fix Clean up usermeta when deleting field.
* Fix Class PeepSoExtendedProfiles does not have a method version_notice.
* Fix Separators not showing for non-admin users.
* Fix Trash Icon Not appearing when there’s a newly created custom field.

= 1.6.1 =
* Impr Compatibility with PeepSo 1.6.1
* Impr Generated new .POT file.

= 1.6.0 =
* Initial release