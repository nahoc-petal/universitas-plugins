<?php
if( count($fields) ) {
	foreach ($fields as $key => $field) {
		$field_can_edit = !isset($field::$user_disable_edit);
		if(1 == $field->prop('meta', 'user_registration')) {
		?>
			<div class="ps-form-group">
				<?php
				if(!isset($field::$user_hide_title)) :
				?>
				<label id="peepso_user_field_first_namemsg" for="peepso_user_field_first_name" class="form-label "><?php _e($field->title, 'profileso');

					if( 1 == $field->prop('meta','validation','required' ))
					{
					 	echo "<span class=\"required-sign\">&nbsp;*</span>";
					}
					?></label>
				<?php endif; ?>
				<div class="ps-form-field ">
					<?php
					if (TRUE == $field_can_edit) :
						//$field->render_validation();
                        do_action('peepso_action_render_profile_field_edit_before', $field);
						$field->render_input();
					endif;
					?>
					<p class="ps-form__label-desc lbl-descript"><?php $field->render(); ?></p>
					<?php

					// validation goes here
					$errors = count($field->validation_errors);
					echo '<ul class="ps-form-error"' . ($errors > 0 ? '' : ' style="display:none"') . '>';
					if( $errors > 0 ) {
						foreach ($field->validation_errors as $key => $value) {
							echo '<li>' . $value . '</li>';
						}
					}
					echo '</ul>';

					?>
				</div>
			</div>
		<?php
		}
	}
}

// EOF
