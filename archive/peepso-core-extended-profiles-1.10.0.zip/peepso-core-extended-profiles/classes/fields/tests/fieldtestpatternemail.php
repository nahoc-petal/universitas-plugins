<?php

class PeepSoFieldTestPatternEmail extends PeepSoFieldTestAbstract
{

	public function __construct($value)
	{
		parent::__construct($value);

		$this->admin_label = __('Force valid e-mail addresses', 'profileso');
		$this->admin_type = 'checkbox';
	}

	public function test()
	{

		if ( strlen($this->value) && FALSE === filter_var($this->value, FILTER_VALIDATE_EMAIL) ) {

			$this->error = __('Must be a valid E-Mail address', 'profileso');

			return FALSE;
		}

		return TRUE;
	}

}