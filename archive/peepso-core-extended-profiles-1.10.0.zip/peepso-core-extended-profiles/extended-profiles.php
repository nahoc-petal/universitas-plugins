<?php
/**
 * Plugin Name: PeepSo Core: Extended Profiles
 * Plugin URI: https://peepso.com
 * Description: Build custom user profiles
 * Author: PeepSo
 * Author URI: https://peepso.com
 * Version: 1.10.0
 * Copyright: (c) 2015 PeepSo, Inc. All Rights Reserved.
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: profileso
 * Domain Path: /language
 *
 * We are Open Source. You can redistribute and/or modify this software under the terms of the GNU General Public License (version 2 or later)
 * as published by the Free Software Foundation. See the GNU General Public License or the LICENSE file for more details.
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.
 */

class PeepSoExtendedProfiles
{
	private static $_instance = NULL;

	const PLUGIN_NAME = 'Core: Extended Profiles';
	const PLUGIN_VERSION = '1.10.0';
	const PLUGIN_RELEASE = ''; //ALPHA1, BETA1, RC1, '' for STABLE
	const PLUGIN_EDD = 43454;
	const PLUGIN_SLUG = 'profileso';
	const PEEPSOCOM_LICENSES = 'http://tiny.cc/peepso-licenses';

	public $field_types = array(
		'textemail',
		'selectmulti',
		'separator',
	);

	// Extend PeepSoField keys, as_int and as_array with extra values
	protected $field_meta_keys_extra = array(
		'user_on_cover',
	);

	protected $field_meta_keys_extra_as_int = array(
		'user_on_cover',
	);

	protected $field_meta_keys_extra_as_array = array(
	);


	private function __construct()
	{
		add_action('peepso_init', array(&$this, 'init'));
		add_filter('peepso_all_plugins', array($this, 'filter_all_plugins'));
        add_action('plugins_loaded', array(&$this, 'load_textdomain'));

		if (is_admin()) {
			add_action('admin_init', 							array(&$this, 'peepso_check'));
			add_action('peepso_config_before_save-site', 		array(&$this, 'before_save_site'));
			add_filter('peepso_license_config', 				array(&$this, 'add_license_info'), 50);
		}

		// Extend PeepSoField keys, as_int and as_array with extra values
		add_filter('peepso_user_field_meta_keys', 			array(&$this, 'filter_user_field_meta_keys'));
		add_filter('peepso_user_field_meta_keys_as_int',	array(&$this, 'filter_user_field_meta_keys_as_int'));
		add_filter('peepso_user_field_meta_keys_as_array',	array(&$this, 'filter_user_field_meta_keys_as_array'));


        add_shortcode( 'peepso_user_field',  function($a) {
            $a = shortcode_atts( array(
                'user' => get_current_user_id(),
                'field' => 'firstname',
                'height' => '',
                'width' => '',
            ), $a );

            $PeepSoUser = PeepSoUser::get_instance($a['user']);

            if('avatar' == $a['field']) {
                return "<img src=\"{$PeepSoUser->get_avatar('orig')}\" height=\"{$a['height']}\" width=\"{$a['width']}\">";
            }

            if('avatar_full' == $a['field']) {
                return "<img src=\"{$PeepSoUser->get_avatar('full')}\" height=\"{$a['height']}\" width=\"{$a['width']}\">";
            }


            $PeepSoField = PeepSoField::get_field_by_id($a['field'], $PeepSoUser->get_id());

            if(!$PeepSoUser || !$PeepSoField) {
                return '';
            }

            return $PeepSoField->render(FALSE);
        });

		register_activation_hook(__FILE__, array(&$this, 'activate'));
	}

	public static function get_instance()
	{
		if (NULL === self::$_instance) {
			self::$_instance = new self();
		}
		return (self::$_instance);
	}

	public function init()
	{
		$dir_classes = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR;
		$dir_fields = $dir_classes . 'fields' . DIRECTORY_SEPARATOR;
		$dir_fields_tests = $dir_fields . 'tests' . DIRECTORY_SEPARATOR;

		PeepSo::add_autoload_directory($dir_classes);
		PeepSo::add_autoload_directory($dir_fields);
		PeepSo::add_autoload_directory($dir_fields_tests);

		PeepSoTemplate::add_template_directory(plugin_dir_path(__FILE__));

		# ACTIONS - ADMIN

		if (is_admin()) {
			add_action('admin_init', array(&$this, 'peepso_check'));
			add_action('admin_enqueue_scripts', array(&$this, 'admin_enqueue_scripts'));
			add_action('peepso_admin_profiles_list_before',array(&$this,'action_admin_profiles_list_before'));
			add_action('peepso_admin_dashboard_demographic_data',array(&$this,'filter_admin_dashboard_demographic_data'));
		} else {
			add_action('wp_enqueue_scripts', array(&$this, 'enqueue_scripts'));
			add_action('peepso_action_render_member_search_fields', array(&$this, 'action_render_member_search_fields'));

			add_filter('peepso_member_search_args', array(&$this, 'filter_member_search_args'), 10, 2);
		}

		# ACTIONS - ADMIN AJAX
		# These must fire outside the is_admin() context, otherwise will not work inside AJAX calls
        add_action('update_postmeta', function($meta_type, $post_id, $meta_key, $meta_value) {
            if('searchable' == $meta_key && 1==$meta_value) {
                $post = get_post($post_id);

                if('peepso_user_field' == $post->post_type) {
                    global $wpdb;
                    $wpdb->update($wpdb->usermeta, array('meta_value'=>PeepSo::ACCESS_MEMBERS), array('meta_key'=> 'peepso_user_field_'.$post_id.'_acc'));
                }
            }

        }, 10, 4);

		## ALL CLASSES - Tab additions
		// Additional options after Default Privacy
		add_action('peepso_admin_profiles_field_options_default_privacy',array(&$this,'action_admin_profiles_field_options_default_privacy'),1);
		// Additional options on the bottom of Appearance Tab
		add_action('peepsofield_admin_appearance',array(&$this,'action_admin_profiles_field_tab_appearance'),1);

		## SELECT CLASSES - Tab additions
		// Single Select - General Tab
		add_action('peepsofieldselectsingle_admin_general', array(&$this, 'action_peepsofieldselect_select_options'));
		// Multi Select - General Tab
		add_action('peepsofieldselectmulti_admin_general', array(&$this, 'action_peepsofieldselect_select_options'));
		// URL - Appearance Tab
		add_action('peepsofieldtexturl_admin_appearance', array(&$this, 'action_peepsofieldtexturl_nofollow'));
		// ?
		add_action('peepso_admin_profiles_field_title_after',array(&$this,'action_admin_profiles_field_title_after'));

		## All CLASSES - Container additions
		// Additional field options on the bottom of the box (eg Delete)
		add_action('peepso_admin_profiles_field_options',array(&$this,'action_admin_profiles_field_options'));


		# FILTERS - GLOBAL

		## Query modifiers
		// modify limit
		add_filter('peepso_profile_fields_query_limit', array(&$this, 'filter_profile_fields_query_limit'));
		// change core flag
		add_filter('peepso_profile_fields_query_is_core', array(&$this, 'filter_profile_fields_query_is_core'));


        // adding option to profiles fields
        add_action('peepsofieldtext_admin_general',	array(&$this, 'add_fieldtext_admin_general_option'), 10, 1);
        add_action('peepsofieldtextdate_admin_general',	array(&$this, 'add_fieldtext_admin_general_option'), 10, 1);
        add_action('peepsofieldtextemail_admin_general',	array(&$this, 'add_fieldtext_admin_general_option'), 10, 1);
        add_action('peepsofieldtexturl_admin_general',	array(&$this, 'add_fieldtext_admin_general_option'), 10, 1);
        add_action('peepsofieldselectsingle_admin_general',	array(&$this, 'add_fieldtext_admin_general_option'), 10, 1);
        add_action('peepsofieldselectmulti_admin_general',	array(&$this, 'add_fieldtext_admin_general_option'), 10, 1);
        add_action('peepsofieldseparator_admin_general',	array(&$this, 'add_fieldtext_admin_general_option'), 10, 1);
        add_action('peepsofieldlocation_admin_general',	array(&$this, 'add_fieldtext_admin_general_option'), 10, 1);

        // adding option to profiles fields
        add_action('peepsofieldtext_admin_privacy',	array(&$this, 'add_fieldtext_admin_privacy_option'), 10, 1);
        add_action('peepsofieldtextdate_admin_privacy',	array(&$this, 'add_fieldtext_admin_privacy_option'), 10, 1);
        add_action('peepsofieldtextemail_admin_privacy',	array(&$this, 'add_fieldtext_admin_privacy_option'), 10, 1);
        add_action('peepsofieldtexturl_admin_privacy',	array(&$this, 'add_fieldtext_admin_privacy_option'), 10, 1);
        add_action('peepsofieldselectsingle_admin_privacy',	array(&$this, 'add_fieldtext_admin_privacy_option'), 10, 1);
        add_action('peepsofieldselectmulti_admin_privacy',	array(&$this, 'add_fieldtext_admin_privacy_option'), 10, 1);
        add_action('peepsofieldseparator_admin_privacy',	array(&$this, 'add_fieldtext_admin_privacy_option'), 10, 1);
        add_action('peepsofieldlocation_admin_privacy',	array(&$this, 'add_fieldtext_admin_privacy_option'), 10, 1);

		// add fields to register form
		add_filter('peepso_register_form_fields', array(&$this, 'register_form_fields'), 10, 1);
		add_action('peepso_register_extended_fields', array(&$this, 'register_extended_fields'), 10);

		add_filter('peepso_register_valid_extended_fields', array(&$this, 'valid_extended_fields'), 10, 2);
		add_action('peepso_register_new_user', array(&$this,'register_new_user'));

		// Grab all registered field types
		$this->field_types = apply_filters('peepso_admin_profile_field_types', $this->field_types);

		// Compare last version stored in transient with current version
		if( $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE != get_transient($trans = 'peepso_'.$this::PLUGIN_SLUG.'_version')) {
			set_transient($trans, $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE);
			$this->activate();
		}
	}

	/**
     * Loads the translation file for the plugin
     */
    public function load_textdomain()
    {
        $path = str_ireplace(WP_PLUGIN_DIR, '', dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'language' . DIRECTORY_SEPARATOR;
        load_plugin_textdomain('profileso', FALSE, $path);
	}
	
	/**
	 * todo:docblock
	 */
	public function filter_member_search_args($peepso_args, $input)
	{
		$PeepSoUser = PeepSoUser::get_instance(0);

        $PeepSoUser->profile_fields->load_fields();
        $fields = $PeepSoUser->profile_fields->get_fields();

        foreach($fields as  $field) {
            if(1 == $field->prop('published') && 1==$field->prop('meta','searchable')) {
                $param = $input->val('profile_field_' . $field->prop('id'), '');
                if (!empty($param)) {
                	$peepso_args['meta_' . $field->prop('id')] = strtolower($param);
                }
            }
        }

		return $peepso_args;
	}

	/**
	 * todo:docblock
	 */
	public function action_render_member_search_fields() {
		# find all searchable fields
        #render them

        $PeepSoUser = PeepSoUser::get_instance(0);

        $PeepSoUser->profile_fields->load_fields();
        $fields = $PeepSoUser->profile_fields->get_fields();

        foreach($fields as  $field) {
            if(1 == $field->prop('published') && 1==$field->prop('meta','searchable')) {
                $field->value=FALSE;
                ?>
                <div class="ps-filters__item ps-filters__item--custom ps-js-filter-extended">
                    <label class="ps-filters__item-label"><?php echo $field->prop('title'); ?></label>
                    <?php $field->render_input(); ?>
                </div>
                <?php
            }
        };

        echo "<br><br>";
	}

	/**
	 * todo:docblock
	 */
	public function add_fieldtext_admin_general_option($field) {
        /** SHOW IN REGISTRATION **/
        $params = array(
            'type'			=> 'checkbox',
            'data'			=> array(
                'data-prop-type' 		=> 'meta',
                'data-prop-name' 		=> 'user_registration',
                'data-disabled-value' 	=> '0',
                'value' 				=> '1',
                'admin_value'			=> $field->prop('meta', 'user_registration'),
                'id'					=> 'field-' . $field->prop('id') .'-registration',
            ),
            'field'			=> $field,
            'label'			=> __('Show in registration','profileso'),
            'label_after'	=> '',
        );

        // add "checked" manually - the value is "published" and by default checkbox looks for "1"
        if(1 == $field->prop('meta', 'user_registration')) {
            $params['data']['checked'] = 'checked';
        }

        echo PeepSoTemplate::exec_template('admin','profiles_field_config_field', $params);

        if('PeepSoFieldSelectSingle' == get_class($field) && 0 == $field->prop('meta','is_core')) {
            /** SHOW IN SEARCH **/
            $params = array(
                'type' => 'checkbox',
                'data' => array(
                    'data-prop-type' => 'meta',
                    'data-prop-name' => 'searchable',
                    'data-disabled-value' => '0',
                    'value' => '1',
                    'admin_value' => $field->prop('meta', 'searchable'),
                    'id' => 'field-' . $field->prop('id') . '-searchable',
                ),
                'field' => $field,
                'label' => __('Searchable', 'profileso'),
                'label_after' => __('Warning: searchable fields privacy will be forced as "Site Members" and will not be editable by users. The "Privacy" config tab will have no effect.', 'profileso'),
            );

            // add "checked" manually - the value is "published" and by default checkbox looks for "1"
            if (1 == $field->prop('meta', 'searchable')) {
                $params['data']['checked'] = 'checked';
            }

            echo PeepSoTemplate::exec_template('admin', 'profiles_field_config_field', $params);
        }

	}

	public function add_fieldtext_admin_privacy_option($field) {
        $params = array(
            'type'			=> 'checkbox',
            'data'			=> array(
                'data-prop-type' 		=> 'meta',
                'data-prop-name' 		=> 'privacywarning',
                'data-disabled-value' 	=> '0',
                'value' 				=> '1',
                'admin_value'			=> $field->prop('meta', 'privacywarning'),
                'id'					=> 'field-' . $field->prop('id') .'-privacywarning',
            ),
            'field'			=> $field,
            'label'			=> __('Show a privacy warning','profileso'),
            'label_after'	=> __('When enabled, users will be presented with a privacy warning after going into "edit mode" of this profile field','profileso'),
        );

        // add "checked" manually - the value is "published" and by default checkbox looks for "1"
        if(1 == $field->prop('meta', 'privacywarning')) {
            $params['data']['checked'] = 'checked';
        }

        echo PeepSoTemplate::exec_template('admin','profiles_field_config_field', $params);

        $params = array(
            'type'			=> 'text',
            'data'			=> array(
                'data-prop-type' 		=> 'meta',
                'data-prop-name' 		=> 'privacywarningtext',
                'data-disabled-value' 	=> '0',
                'value' 				=> $field->prop('meta', 'privacywarningtext'),
                'size'                  => '100',
                'admin_value'			=> $field->prop('meta', 'privacywarningtext'),
                'id'					=> 'field-' . $field->prop('id') .'-privacywarningtext',
            ),
            'field'			=> $field,
            'label'			=> __('Privacy warning text','profileso'),
            'label_after'	=> '',
        );

        echo PeepSoTemplate::exec_template('admin','profiles_field_config_field', $params);
    }

	/**
	 * todo:docblock
	 */
	public function register_form_fields($fields) {

		$args = array('post_status'=>'publish');

		$user = PeepSoUser::get_instance(0);
		$user->profile_fields->load_fields($args);
		$ext_fields = $user->profile_fields->get_fields();

		// adding field with type `extended_fields` so we can have hook `peepso_register_extended_fields`
		$fields_to_add = array(
			'extended_profile_fields' => array(
				'type' => 'extended_fields',
				)
			);

		$first_fields = array_splice ($fields, 0, 5);
  		$fields = array_merge ($first_fields, $fields_to_add, $fields);

		return $fields;
	}

	/**
	 * todo:docblock
	 */
	public function register_extended_fields() {

		$input = new PeepSoInput();
		$user = PeepSoUser::get_instance(0);

		$args = array('post_status'=>'publish');

		$user->profile_fields->load_fields($args);
		$fields = $user->profile_fields->get_fields();
		if( count($fields) ) {
			foreach ($fields as $key => &$field) {
				$field->is_registration_page = TRUE;

				// check if any post request?
				if(!isset($field::$user_disable_edit) && 1 == $field->prop('meta', 'user_registration') && ((isset($field->meta->validation) && count((array)$field->meta->validation)) && (isset($_POST) && count((array)$_POST)))) {

					// get old meta
					$meta = $field->meta;

					$value = $input->val(PeepSoField::$profile_field_prefix . $field->id);

					$field->value = $value;
					$field->validate();

					// rollback meta
					$field->meta->validation = $meta->validation;
				}
			}
		}

		echo PeepSoTemplate::exec_template('profile', 'profile-register', array('fields' => $fields));
	}

	/**
	 * todo:docblock
	 */
	public function valid_extended_fields($ret, $input) {

		$user = PeepSoUser::get_instance(0);

		$args = array('post_status'=>'publish');

		$user->profile_fields->load_fields($args);
		$fields = $user->profile_fields->get_fields();
		if( count($fields) ) {
			foreach ($fields as $key => $field) {
				$field->is_registration_page = TRUE;

				// check if any post request?
				if(!isset($field::$user_disable_edit) && 1 == $field->prop('meta', 'user_registration') && (count($field->meta->validation) && count($_POST))) {

					// get old meta
					$meta = $field->meta;

					$field->value = $input->val(PeepSoField::$profile_field_prefix . $field->id);

					// validate the value
					$success = $field->validate();
					if(FALSE === $success) {
						// just return if any field invalid
						return $success;
					}

					// rollback meta
					$field->meta->validation = $meta->validation;
				}
			}
		}

		return ($ret);
	}

	/**
	 * todo: docblock
	 */
	public function register_new_user($wp_user) {

        if(0 !== intval($wp_user)) {
            foreach ($_POST as $key => $value) {
                // check if key `peepso_field_` exist
                if ( strpos($key, PeepSoField::$profile_field_prefix) !== FALSE) {
                    $id = str_replace(PeepSoField::$profile_field_prefix, "", $key);
                    $field = PeepSoField::get_field_by_id($id, $wp_user);

                    // if not instanceod peepsofield, just continue and not update db
                    if( !($field instanceof PeepSoField)) {
                        continue;
                    }

                    // wp field returns INT, peepso field returns BOOL
                    $success = $field->save($value);
                }
            }
        }
	}

	/**
	 * Called before PeepSo saves the "site" config page
	 * Deletes the cached license in order to forcefully revalidate
	 */
	public function before_save_site()
	{
		PeepSoLicense::delete_transient(self::PLUGIN_SLUG);
	}

	/**
     * Adds the license key information to the config metabox
     * @param array $list The list of license key config items
     * @return array The modified list of license key items
     */
    public function add_license_info($list)
    {
        $data = array(
            'plugin_slug' => self::PLUGIN_SLUG,
            'plugin_name' => self::PLUGIN_NAME,
            'plugin_edd' => self::PLUGIN_EDD,
            'plugin_version' => self::PLUGIN_VERSION
        );
        $list[] = $data;
        return ($list);
    }

    public function license_notice()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG);
    }

    public function license_notice_forced()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG, true);
    }

	public static function action_peepsofieldselect_select_options( $field )
	{
		PeepSoTemplate::exec_template('admin','selectoptions', array('field'=>$field));
	}

	// Add "nofollow" to URL fields
	public static function action_peepsofieldtexturl_nofollow( $field )
	{
		PeepSoTemplate::exec_template('admin','urlnofollow', array('field'=>$field));
	}

	public function filter_user_field_meta_keys( $keys )
	{
		return array_merge($keys, $this->field_meta_keys_extra);
	}

	public function filter_user_field_meta_keys_as_int( $keys )
	{
		return array_merge($keys, $this->field_meta_keys_extra_as_int);
	}

	public function filter_user_field_meta_keys_as_array( $keys )
	{
		return array_merge($keys, $this->field_meta_keys_extra_as_array);
	}

	public function action_admin_profiles_list_before() {

		foreach($this->field_types as $field_type) {

			$class = strtolower('peepsofield'.$field_type);

			if(!class_exists($class)) {
				continue;
			}

			$field_types[$field_type] = $class::$admin_label;
		}
		asort($field_types);
		wp_localize_script('peepso-extended-profiles-admin', 'peepsofieldtypes', $field_types);
	}

	public function action_admin_profiles_field_title_after($field)
	{
		echo str_ireplace('peepso','',self::PLUGIN_NAME) . ': ' . $field::$admin_label;
	}

	public function filter_profile_fields_query_limit( $limit )
	{
		return 1000;
	}

	public function filter_profile_fields_query_is_core( $is_core )
	{
		$is_core[]= 0;
		return $is_core;
	}

	public static function action_admin_profiles_field_options($field)
	{
		if(0 === $field->prop('meta','is_core')) { ?>
			<div class="ps-settings__action">
				<a data-id="<?php echo $field->prop('id'); ?>" href="#" class="ps-js-field-duplicate"><i class="fa fa-copy"></i><?php echo __('Duplicate', 'profileso');?></a>
				<a data-id="<?php echo $field->prop('id'); ?>" href="#" class="ps-js-field-delete"><i class="fa fa-trash"></i></a>
			</div>
		<?php
		}
	}


	// Additional options after the Default Privacy
	public function action_admin_profiles_field_options_default_privacy( $field )
	{
		PeepSoTemplate::exec_template('admin','privacyoptions', array('field'=>$field));
	}

	// Additional options on the bottom of the Appearance Tab
	public function action_admin_profiles_field_tab_appearance( $field )
	{
		PeepSoTemplate::exec_template('admin','appearance', array('field'=>$field));
	}

	/**
	 * Plugin activation.
	 * Check PeepSo
	 * @return bool
	 */
	public function activate()
	{
		if (!$this->peepso_check()) {
			return (FALSE);
		}

		return (TRUE);
	}

	/**
	 * Check if PeepSo class is present (ie the PeepSo plugin is installed and activated)
	 * If there is no PeepSo, immediately disable the plugin and display a warning
	 * Run license and new version checks against PeepSo.com
	 * @return bool
	 */
	public function peepso_check()
	{
		if (!class_exists('PeepSo')) {
			add_action('admin_notices', array(&$this, 'peepso_disabled_notice'));
			unset($_GET['activate']);
			deactivate_plugins(plugin_basename(__FILE__));
			return (FALSE);
		}

		// PeepSo.com license check
		if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
			add_action('admin_notices', array(&$this, 'license_notice'));
		}

		if (isset($_GET['page']) && 'peepso_config' == $_GET['page'] && !isset($_GET['tab'])) {
			add_action('admin_notices', array(&$this, 'license_notice_forced'));
		}

        // PeepSo.com new version check
        // since 1.7.6
        if(method_exists('PeepSoLicense', 'check_updates_new')) {
            PeepSoLicense::check_updates_new(self::PLUGIN_EDD, self::PLUGIN_SLUG, self::PLUGIN_VERSION, __FILE__);
        }

		return (TRUE);
	}

	/**
	 * Display a message about PeepSo not present
	 */
	public function peepso_disabled_notice()
	{
		?>
		<div class="error peepso">
			<strong>
				<?php echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'profileso'), self::PLUGIN_NAME);?>
				<a href="<?php echo self::PEEPSOCOM_LICENSES;?>" target="_blank">
					<?php _e('Get it now!', 'profileso');?>
				</a>
			</strong>
		</div>
		<?php
	}

	/**
	 * Hooks into PeepSo for compatibility checks
	 * @param $plugins
	 * @return mixed
	 */
	public function filter_all_plugins($plugins)
	{
		$plugins[plugin_basename(__FILE__)] = get_class($this);
		return $plugins;
	}

	public function admin_enqueue_scripts()
	{
		$input = new PeepSoInput();
		if ($input->val('page') == 'peepso-profiles') {
			wp_register_script('peepso-extended-profiles-admin', plugin_dir_url(__FILE__) . 'assets/js/extended-profiles-admin.js',
				array('peepso-admin-profiles'), self::PLUGIN_VERSION, TRUE);
			wp_enqueue_script('peepso-extended-profiles-admin');
		}
	}

	public function enqueue_scripts()
	{
		wp_register_script('peepso-extended-profiles', plugin_dir_url(__FILE__) . 'assets/js/extended-profiles.js',
			array('jquery'), self::PLUGIN_VERSION, TRUE);
		wp_enqueue_script('peepso-extended-profiles');
	}

	public function filter_admin_dashboard_demographic_data($data)
	{
		$PeepSoUser = PeepSoUser::get_instance(0);
		$profile_fields = new PeepSoProfileFields($PeepSoUser);
		$fields = $profile_fields->load_fields();

		$male_gender_key = array_search(__('Male', 'peepso-core'), array_column($data, 'label'));
		$female_gender_key = array_search(__('Female', 'peepso-core'), array_column($data, 'label'));

		foreach ($fields['peepso_user_field_gender']->meta->select_options as $key => $value) {
			if (is_int($male_gender_key) && $male_gender_key >= 0 && $key == 'm') {
				$data[$male_gender_key]['label'] = $value;
			} else if (is_int($female_gender_key) && $female_gender_key >= 0 && $key == 'f') {
				$data[$female_gender_key]['label'] = $value;
			} else {
				$data[] = array(
					'label' => $value,
					'value' => $PeepSoUser->get_count_by_gender($key),
					'icon' => PeepSo::get_asset('images/avatar/user-neutral-thumb.png'),
					'color' => 'rgb(180,180,180)'
				);
			}
		}

		return $data;
	}
}

PeepSoExtendedProfiles::get_instance();
// EOF
