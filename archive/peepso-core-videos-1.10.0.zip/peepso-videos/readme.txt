=== Plugin Name ===
Contributors: peepso, JaworskiMatt, rsusanto
Donate link: http://www.peepso.com
Tags: PeepSo, social network, social media, community, stream, pages, acl, activity, profile, notifications, social, networking, video, videos, youtube, vimeo
Requires at least: 4.6
Tested up to: 4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
VidSo adds the ability to post videos on the stream. Users can preview videos before posting them and see them on their profiles.
 
The video screen is expandable and members can post their own Likes and comments.
 
When viewed from a user profile, the video opens in a modal window where the owner or the admin can edit the caption, delete, like or comment.

== Frequently Asked Questions ==

= What's the automated upgrade procedure? =

First you need to update the ChatSo plugin. Then all the other supporting plugins. PeepSo Core plugin must be updated last.

= Can I just use VidSo on my website? =

For VidSo to work, you need to have PeepSo installed and activated. VidSo is not a standalone plugin for WordPress.


== Changelog ==
= ALL VERSIONS =
* See full changelog here: [PeepSo Changelog](https://www.peepso.com/changelog/ "PeepSo Changelog")

= 1.7.0 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.7.0
* Impr Support for GroupSo plugin.
* Impr Press 'Escape' to close lightbox.

= 1.6.3 =
* Impr Compatibility with PeepSo 1.6.3.
* Impr Generated new .POT file.
* Impr The 'play' watermark is almost invisible on light video frame 
* Fix Rendering of location and mood in videos modal. 

= 1.6.2 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.6.2
* Impr Notifications improvements.

= 1.6.1 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.6.1

= 1.6.0 =
* New Latest Community Videos Widget
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.6.0
* Fix Missing loading indicators on infinite scroll in User Profile.

= 1.5.7 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.5.7

= 1.5.6 =
* Impr Compatibility with PeepSo 1.5.6
* Impr Updated Language file.

= 1.5.5 =
* Impr Compatibility with PeepSo 1.5.5
* Impr Updated Language file.
* Impr Renamed the plugin from PeepSo [X] to PeepSo Core [X] 

= 1.5.4 =
* Impr Compatibility with PeepSo 1.5.4
* Impr Updated Language file.
* Fix Videos Page broken when Messages is disabled.

= 1.5.3 =
* Impr Compatibility with PeepSo 1.5.3
* Impr Updated Language file.

= 1.5.2 =
* Impr Compatibility with PeepSo 1.5.2
* Impr Updated Language file.

= 1.5.1 =
* Impr Compatibility with PeepSo 1.5.1
* Impr Updated Language file.
* Impr styling of displaing video embeds.

= 1.5.0 =
* Impr Compatibility with PeepSo 1.5.0
* Impr Updated Language file.
* Fix Indication that it's a video is not centered in widget.

= 1.4.2 =
* Impr Compatibility with PeepSo 1.4.2
* Impr Updated Language file.

= 1.4.1 =
* Impr Compatibility with PeepSo 1.4.1
* Impr Updated Language file.

= 1.4.0 =
* Impr Compatibility with PeepSo 1.4.0
* Impr Updated Language file.

= 1.3.0 =
* Impr Compatibility with PeepSo 1.4.0
* Impr Updated Language file.

= 1.2.1 =
* Impr Compatibility with PeepSo 1.2.1
* Impr Updated Language file.

= 1.2.0 =
* Impr Compatibility with PeepSo 1.2.0
* Impr Added a ‘loading’ indicator when the postbox is fetching a link preview.
* Fix Added .POT language file.

= 1.1.0 =
* Impr Compatibility with PeepSo 1.1.0
* Impr Added visual indication to video thumbnails that they are playable videos.
* Fix Moved the characters count in Postbox to the actual message box when video is shared.

= 1.0.1 =
* Impr Compatibility with PeepSo 1.0.1

= 1.0.0 =
* Impr Compatibility with PeepSo 1.0.0
* Fix Can’t edit caption for videos in a modal window.
* Fix A ‘cached’ version of comments, likes, edits of videos is shown in modal.
* Fix Vimeo videos not playing inline on stream.

= 1.0.0 RC4 =
* Impr Compatibility with PeepSo 1.0.0 RC4
* Fix Videos don’t play in Firefox.
* Fix Remove the option to add videos from PostBox in messages.

= 1.0.0 RC1 =
* New Initial release of VidSo plugin.
