<?php

class PeepSoVideosModel
{
    public static $notices = array();				// error messages to be returned to user

    const TABLE = 'peepso_videos';

    /**
     * Return all video entries associated to a post
     * @param  int $post_id The post ID
     * @return array $videos Unmodified videos
     */
    public function get_community_videos($offset = 0, $limit = 10, $sort = 'desc')
    {
        global $wpdb;

        $clauses=array('join'=>'', 'where'=>'');                
                
        $sql = " SELECT * FROM `{$wpdb->prefix}" . PeepSoActivity::TABLE_NAME . "` `act` ";
        
        $clauses['join'] .= 
                " LEFT JOIN `" . $wpdb->posts  . "` ON `act_external_id` = `" . $wpdb->posts  . "`.`ID` ";
        
        $clauses['join'] .= 
                " LEFT JOIN `{$wpdb->prefix}" . self::TABLE . "` `vid` ON `{$wpdb->posts}`.`ID`=`vid`.`vid_post_id` ";

        $clauses['where'] .= 
            " WHERE `act_module_id` = " . PeepSoVideos::MODULE_ID . " ";
        
        $clauses['where'] .= 
            " AND `{$wpdb->posts}`.`post_status`='publish'";
        
        $clauses['where'] .=
                " AND `vid`.`vid_id` IS NOT NULL";

        $module_id = 0;
        $widgets = TRUE;
        $clauses = apply_filters('peepso_videos_post_clauses', $clauses, $module_id, $widgets);
        
        // add checks for post's access
        if (is_user_logged_in()) {
            
            //$clauses = apply_filters('peepso_activity_post_clauses', $clauses);
            
            // PRIVATE and owner by current user id  - OR -
            // MEMBERS and user is logged in - OR -
            // PUBLIC
            $access = ' ((`act_access`=' . PeepSo::ACCESS_MEMBERS . ') OR (`act_access`<=' . PeepSo::ACCESS_PUBLIC . ') ';

            // Hooked methods must wrap the string within a paranthesis
            #just view members and public privacy
            #$access = apply_filters('peepso_activity_post_filter_access', $access);

            $access .= ') ';
        } else {
            // PUBLIC
            $access = ' (`act_access`<=' . PeepSo::ACCESS_PUBLIC . ' ) ';
        }

        $sql .= $clauses['join'];

        $sql .= $clauses['where'];

        $sql .= ' AND ' . $access;

        $sql .= ' ORDER BY act_id '. $sort .' LIMIT ' . $offset .', ' . $limit;

        #echo $sql;

        $videos = $wpdb->get_results($sql);

        return ($this->set_videos($videos));
    }

    /**
     * Return all video entries associated to a post
     * @param  int $post_id The post ID
     * @return array $videos Unmodified videos
     */
    public function get_user_videos($user_id, $offset = 0, $limit = 10, $sort = 'desc', $module_id = 0, $isgdpr=false)
    {
        global $wpdb;

		$clauses=array('join'=>'', 'where'=>'');				
				
        $sql = " SELECT * FROM `{$wpdb->prefix}" . self::TABLE . "` ";
		
		$clauses['join'] .= 
				" LEFT JOIN `{$wpdb->prefix}" . PeepSoActivity::TABLE_NAME . "` `act` ON `act`.`act_external_id`=`vid_post_id` AND `act`.`act_module_id` = " . PeepSoVideos::MODULE_ID;
		
		$clauses['join'] .= 
				" LEFT JOIN `" . $wpdb->posts  . "` ON `act`.`act_external_id` = `" . $wpdb->posts  . "`.`ID` ";
		
        $clauses['where'] .=
            " WHERE `{$wpdb->posts}`.`post_status`='publish'";

        $clauses = apply_filters('peepso_videos_post_clauses', $clauses, $module_id, FALSE);

        if(intval($user_id) !== 0 && intval($module_id) == 0) {
    		$clauses['where'] .=				
                " AND `act`.`act_owner_id` = %d ";
        }

        $clauses['where'] .=
            " AND `vid_module_id` = %d ";
		
        // add checks for post's access
        if ((is_user_logged_in() && $module_id == 0 ) || $isgdpr) {
			
            if((get_current_user_id() != $user_id) && !$isgdpr) {
                $clauses = apply_filters('peepso_activity_post_clauses', $clauses, get_current_user_id());
            }
			
            // PRIVATE and owner by current user id  - OR -
            // MEMBERS and user is logged in - OR -
            // PUBLIC
            $access = ' ((`act_access`=' . PeepSo::ACCESS_PRIVATE . ' AND `act_owner_id`=' . $user_id . ') OR ' .
                ' (`act_access`=' . PeepSo::ACCESS_MEMBERS . ') OR (`act_access`<=' . PeepSo::ACCESS_PUBLIC . ') ';

            // Hooked methods must wrap the string within a paranthesis
            $access = apply_filters('peepso_activity_post_filter_access', $access);

            $access .= ') ';
        } else {
            // PUBLIC
            $access = ' (`act_access`<=' . PeepSo::ACCESS_PUBLIC . ' ) ';

            $clauses = apply_filters('peepso_videos_filter_owner_' . $module_id, $clauses);
        }

        $sql .= $clauses['join'];

        $sql .= $clauses['where'];

        $sql .= ' AND ' . $access;

        $sql .= ' ORDER BY act_id '. $sort .' LIMIT ' . $offset .', ' . $limit;

        if(intval($module_id) === 0) {
            $videos = $wpdb->get_results($wpdb->prepare($sql, $user_id, $module_id));             
        } else {
            $videos = $wpdb->get_results($wpdb->prepare($sql, $module_id));
        }

        return ($this->set_videos($videos));
    }

    public function get_num_community_videos()
    {
        global $wpdb;

        $clauses=array('join'=>'', 'where'=>'');

        $sql = "SELECT COUNT(`vid_id`) as num_videos FROM `{$wpdb->prefix}" . self::TABLE . "`";
        
        $clauses['join'] .= 
                " LEFT JOIN `{$wpdb->prefix}" . PeepSoActivity::TABLE_NAME . "` `act` ON `act`.`act_external_id`=`vid_post_id` AND `act`.`act_module_id` = " . PeepSoVideos::MODULE_ID ;

        $clauses['join'] .= 
                " LEFT JOIN `" . $wpdb->posts  . "` ON `act`.`act_external_id` = `" . $wpdb->posts  . "`.`ID` ";


        $module_id = 0;
        $widgets = TRUE;
        $clauses = apply_filters('peepso_videos_post_clauses', $clauses, $module_id, $widgets);

        // add checks for post's access
        if (is_user_logged_in()) {
            
            //$clauses = apply_filters('peepso_activity_post_clauses', $clauses, get_current_user_id());
            
            // PRIVATE and owner by current user id  - OR -
            // MEMBERS and user is logged in - OR -
            // PUBLIC
            $access = ' ((`act_access`=' . PeepSo::ACCESS_MEMBERS . ') OR (`act_access`<=' . PeepSo::ACCESS_PUBLIC . ') ';

            // Hooked methods must wrap the string within a paranthesis
            $access = apply_filters('peepso_activity_post_filter_access', $access);

            $access .= ') ';
        } else {
            // PUBLIC
            $access = ' (`act_access`<=' . PeepSo::ACCESS_PUBLIC . ' ) ';
        }

        $sql .= $clauses['join'];

        $sql .= $clauses['where'];

        $sql .= ' AND ' . $access;

        $videos = $wpdb->get_results($sql);

        return $videos[0]->num_videos;
    }    

    public function get_num_videos($user_id, $module_id = 0)
    {
        global $wpdb;

		$clauses=array('join'=>'', 'where'=>'');

        $sql = "SELECT COUNT(`vid_id`) as num_videos FROM `{$wpdb->prefix}" . self::TABLE . "`";
		
		$clauses['join'] .= 
				" LEFT JOIN `{$wpdb->prefix}" . PeepSoActivity::TABLE_NAME . "` `act` ON `act`.`act_external_id`=`vid_post_id` AND `act`.`act_module_id` = " . PeepSoVideos::MODULE_ID ;

		$clauses['join'] .= 
				" LEFT JOIN `" . $wpdb->posts  . "` ON `act`.`act_external_id` = `" . $wpdb->posts  . "`.`ID` ";

        $clauses['where'] .=
            " WHERE `{$wpdb->posts}`.`post_status`='publish'";

        $clauses['where'] .=                
            " AND `{$wpdb->prefix}" . self::TABLE . "`.`vid_module_id` = %d";

		if(intval($user_id) !== 0 && intval($module_id) == 0) {
            $clauses['where'] .=                
                " AND `act`.`act_owner_id` = %d ";
        }

        $clauses = apply_filters('peepso_videos_post_clauses', $clauses, $module_id, FALSE);

        // add checks for post's access
        if (is_user_logged_in()) {
			
            if(get_current_user_id() != $user_id) {
                $clauses = apply_filters('peepso_activity_post_clauses', $clauses, get_current_user_id());
            }			
			
            // PRIVATE and owner by current user id  - OR -
            // MEMBERS and user is logged in - OR -
            // PUBLIC
            $access = ' ((`act_access`=' . PeepSo::ACCESS_PRIVATE . ' AND `act_owner_id`=' . get_current_user_id() . ') OR ' .
                ' (`act_access`=' . PeepSo::ACCESS_MEMBERS . ') OR (`act_access`<=' . PeepSo::ACCESS_PUBLIC . ') ';

            // Hooked methods must wrap the string within a paranthesis
            $access = apply_filters('peepso_activity_post_filter_access', $access);

            $access .= ') ';
        } else {
            // PUBLIC
            $access = ' (`act_access`<=' . PeepSo::ACCESS_PUBLIC . ' ) ';
        }

        $sql .= $clauses['join'];

        $sql .= $clauses['where'];

        $sql .= ' AND ' . $access;

        if($module_id == 0) {
            $videos = $wpdb->get_results($wpdb->prepare($sql, $module_id, $user_id));
        } else {
            $videos = $wpdb->get_results($wpdb->prepare($sql, $module_id));
        }

        return $videos[0]->num_videos;
    }

    /**
     * Set video iterator
     * @param array $videos List of videos
     * @return array $videos Unmodified videos
     */
    public function set_videos($videos)
    {
        $videos_object = new ArrayObject($videos);
        $this->_iterator = $videos_object->getIterator();

        return ($videos);
    }

    /**
     * Return a row from the videos table.
     * @param  int $video_id The ID of the video to retrieve.
     * @return array
     */
    public function get_video($video_id)
    {
        global $wpdb;

        $sql = "SELECT * FROM `{$wpdb->prefix}" . self::TABLE . "`
					LEFT JOIN `{$wpdb->posts}` `posts` ON `posts`.`ID` = `vid_post_id`
					LEFT JOIN `{$wpdb->prefix}" . PeepSoActivity::TABLE_NAME . "` `act`
						ON `act`.`act_external_id`=`vid_id` AND `act`.`act_module_id`=%d
					WHERE `vid_id`=%d";

        return ($wpdb->get_row($wpdb->prepare($sql, PeepSoVideos::MODULE_ID, $video_id)));
    }

    /**
     * Get video iterator
     * @return ArrayObject list of videos in object form
     */
    public function get_iterator()
    {
        return ($this->_iterator);
    }
}

// EOF