<?php

class PeepSoVideosAjax extends PeepSoAjaxCallback
{
	private static $_peepsovideos = NULL;

	protected function __construct()
	{
		parent::__construct();
		self::$_peepsovideos = PeepSoVideos::get_instance();
	}

	/**
	 * Returns the video preview as HTML, if the url is not valid returns success false.
	 * @param  PeepSoAjaxResponse $resp
	 */
	public function get_preview(PeepSoAjaxResponse $resp)
	{
		$url = trim($this->_input->val('url', ''));

		$response = self::$_peepsovideos->parse_oembed_url($url);

		// make iframe full-width
		if (preg_match('/<iframe/i', $response['content'])) {
			$width_pattern = "/width=\"[0-9]*\"/";
			$response['content'] = preg_replace($width_pattern, "width='100%'", $response['content']);
			$response['content'] = '<div class="ps-media-iframe">' . $response['content'] . '</div>';
		}

		if (FALSE === $response) {
			$resp->success(FALSE);
			$resp->error(__('Sorry, this is not a valid video.<br><small>Please make sure you\'re using a valid URL, not and embed code.</small>', 'vidso'));
		} else {
			$resp->success(TRUE);
			$resp->set('content', PeepSoTemplate::exec_template('activity', 'content-media', $response, TRUE));

			$resp->set('title', $response['title']);
			$resp->set('host', $response['host']);
			$resp->set('url', $response['url']);
			$resp->set('description', $response['description']);
			$resp->set('target', $response['target']);

			$resp->set('html', PeepSoTemplate::exec_template('activity', 'content-media', $response, TRUE));
		}
	}

	/**
	 * Post a content with Video
	 * @param  PeepSoAjaxResponse $resp
	 */
	public function post_video(PeepSoAjaxResponse $resp)
	{
		$postbox = PeepSoPostbox::get_instance();
		add_action('peepso_activity_after_add_post', array(self::$_peepsovideos, 'after_add_post'));
		add_filter('peepso_activity_insert_data', array(self::$_peepsovideos, 'activity_insert_data'));

		$postbox->post($resp);

		remove_action('peepso_activity_after_add_post', array(self::$_peepsovideos, 'after_add_post'));
		remove_filter('peepso_activity_insert_data', array(self::$_peepsovideos, 'activity_insert_data'));

		$resp->success(TRUE);
	}


    public function get_user_videos(PeepSoAjaxResponse $resp)
    {
        $page = $this->_input->int('page', 1);
        $sort = $this->_input->val('sort', 'desc');

        $limit = $this->_input->int('limit', 1);
        $offset = ($page - 1) * $limit;

        if ($page < 1) {
            $page = 1;
            $offset = 0;
        }

        $owner = $this->_input->int('user_id');
        $module_id = $this->_input->int('module_id', 0);

        $videos_model = new PeepSoVideosModel();
        $videos = $videos_model->get_user_videos($owner, $offset, $limit, $sort, $module_id);

        ob_start();

        if (count($videos)) {
            foreach ($videos as $video) {
                echo PeepSoTemplate::exec_template('videos', 'video-item-page', (array)$video);
            }

            $resp->success(1);
            $resp->set('found_videos', count($videos));
            $resp->set('videos', ob_get_clean());
        } else {
            $resp->success(FALSE);

            $owner_name = PeepSoUser::get_instance($owner)->get_firstname();
            if ($module_id != 0) {
            	$owner_name = apply_filters('peepso_videos_filter_owner_name', $owner);
            }

            $message = (($module_id == 0) && (get_current_user_id() == $owner)) ? __('You don\'t have any videos yet', 'vidso') : sprintf(__('%s doesn\'t have any videos yet', 'vidso'), $owner_name);

            $resp->error(PeepSoTemplate::exec_template('profile','no-results-ajax', array('message'=> $message), TRUE));
        }


    }

    public function get_user_videos_count(PeepSoAjaxResponse $resp)
    {
        $videos_model = new PeepSoVideosModel();
        $resp->success(1);
        $resp->set('found_videos', $videos_model->get_num_videos($this->_input->int('user_id')));
    }
}

// EOF
