module.exports = function( grunt ) {

	// Load tasks.
	require( 'matchdep' ).filterDev( [ 'grunt-*' ] ).forEach( grunt.loadNpmTasks );

    // Register grunt tasks.
    grunt.registerTask( 'default', [ 'browserify', 'uglify' ]);

    // Set grunt task configurations.
	grunt.initConfig({

        browserify: {
            bundle: {
                files: {
                    'assets/js/bundle.js': [ 'assets/js/app.js' ]
                }
            }
        },

		uglify: {
			bundle: {
				options: {
					report: 'none',
					sourceMap: false
				},
				files: [{
					src: [ 'assets/js/bundle.js' ],
					expand: true,
					ext: '.min.js'
				}]
			}
		}

	});
};
