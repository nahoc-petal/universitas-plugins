<div class="ps-video-wrapper ps-js-video" data-post-id="<?php echo $vid_post_id; ?>">
    <div class="ps-video-item">
        <a class="video-item" href="javascript:void()" onclick="ps_comments.open('<?php echo $vid_post_id; ?>', 'video'); return false;">
            <img src="<?php echo $vid_thumbnail; ?>" />
            <i class="ps-icon-youtube-play ps-video-play"></i>
        </a>
    </div>
</div>
