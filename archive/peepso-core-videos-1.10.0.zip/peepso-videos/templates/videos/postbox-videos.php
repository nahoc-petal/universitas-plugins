<div class="ps-postbox-videos">
	<div class="ps-postbox-fetched"></div>
	<div style="position:relative">
		<div class="ps-postbox-input ps-inputbox">
			<input class="ps-textarea ps-videos-url input" placeholder="<?php _e('Enter video URL here', 'vidso'); ?>"
				style="min-height: 1.4em;"></input>
			<div class="ps-postbox-loading" style="display: none;">
				<img src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>">
				<div> </div>
			</div>
		</div>
		<div class="ps-postbox-preview" style="display: none;">
		</div>
	</div>
</div>
