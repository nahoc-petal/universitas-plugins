// TODO: can this be combined with peepsovideos.js to reduce the number of assets being loaded?

// TODO: convert this to a class rather than using global functions

var player;

function onYouTubeIframeAPIReady() {
	PsVideos.prototype.play_youtube_video = function(e)
	{
		var $el = jQuery(e);
		if ($el.closest('.ps-share-status-inner').length > 0)
			return (false);

		var video_id = $el.data('video-id');
		var player_id = "peepso-youtube-player-" + video_id + "-" + $el.data('unique-id');
		$player = jQuery("#" + player_id);

		new YT.Player(player_id, {
			height: '390',
			width: '640',
			videoId: video_id,
			events: {
				'onReady': onPlayerReady,
				'onStateChange': onPlayerStateChange
			}
		});

		jQuery("#" + player_id).parent().show();

		var $thumbnail_div = $el.parents('.video-avatar');

		$thumbnail_div.siblings('.video-description').css('display', 'block');
		$thumbnail_div.remove();

		return (false);
	};
}

// 4. The API will call this function when the video player is ready.
function onPlayerReady(event) {
	event.target.playVideo();
}

// 5. The API calls this function when the player's state changes.
//    The function indicates that when playing a video (state=1),
//    the player should play for six seconds and then stop.
var done = false;
function onPlayerStateChange(event) {
	if (event.data == YT.PlayerState.PLAYING && !done) {
		setTimeout(stopVideo, 6000);
		done = true;
	}
}

function stopVideo() {
	
}
