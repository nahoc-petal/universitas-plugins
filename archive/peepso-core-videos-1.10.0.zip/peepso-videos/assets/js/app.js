var Videos = require( './peepsovideos' ),
	VideosPage = require( './page-videos' );
