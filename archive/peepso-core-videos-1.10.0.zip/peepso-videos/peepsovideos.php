<?php
/**
 * Plugin Name: PeepSo Core: Videos
 * Plugin URI: https://peepso.com
 * Description: Link videos from supported providers
 * Author: PeepSo
 * Author URI: https://peepso.com
 * Version: 1.10.0
 * Copyright: (c) 2015 PeepSo, Inc. All Rights Reserved.
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: vidso
 * Domain Path: /language
 *
 * We are Open Source. You can redistribute and/or modify this software under the terms of the GNU General Public License (version 2 or later)
 * as published by the Free Software Foundation. See the GNU General Public License or the LICENSE file for more details.
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.
 */

class PeepSoVideos
{
    private static $_instance = NULL;
    private $_oembed_type = NULL;
    private $_oembed_title = NULL;

    private $url_segments;
    private $view_user_id;

    const PLUGIN_VERSION = '1.10.0';
    const PLUGIN_RELEASE = ''; //ALPHA1, BETA1, RC1, '' for STABLE
    const PLUGIN_NAME = 'Core: Videos';
    const PLUGIN_EDD = 245;
    const PLUGIN_SLUG = 'vidso';
    const MODULE_ID = 5;
    const TABLE = 'peepso_videos';
	const PEEPSOCOM_LICENSES = 'http://tiny.cc/peepso-licenses';

    public $widgets = array(
        'PeepSoWidgetVideos',
        'PeepSoWidgetCommunityvideos',
    );

    private $_urls = array(); // temporary storage for parsed urls

    /**
     * Initialize all variables, filters and actions
     */
    private function __construct()
    {
        add_filter('peepso_all_plugins', array($this, 'filter_all_plugins'),1);

        if (is_admin()) {
            add_action('admin_init', array(&$this, 'peepso_check'));
			add_action('peepso_config_before_save-site', array(&$this, 'before_save_site'));
            add_filter('peepso_license_config', array(&$this, 'add_license_info'), 60);
        }

        add_action('plugins_loaded', array(&$this, 'load_textdomain'));

        // You can't call register_activation_hook() inside a function hooked to the 'plugins_loaded' or 'init' hooks
        register_activation_hook(__FILE__, array(&$this, 'activate'));

        add_action('peepso_init', array(&$this, 'init'));
        add_filter('peepso_widgets', array(&$this, 'register_widgets'));
    }

    /**
     * Retrieve singleton class instance
     * @return PeepSoVideos instance
     */
    public static function get_instance()
    {
        if (NULL === self::$_instance)
            self::$_instance = new self();
        return (self::$_instance);
    }

    /**
     * Loads the translation file for the PeepSo plugin
     */
    public function load_textdomain()
    {
        $path = str_ireplace(WP_PLUGIN_DIR, '', dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'language' . DIRECTORY_SEPARATOR;
        load_plugin_textdomain('vidso', FALSE, $path);
    }

    /*
     * Initialize the PeepSoVideos plugin
     */
    public function init()
    {
        // set up autoloading
        PeepSo::add_autoload_directory(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR);
        PeepSoTemplate::add_template_directory(plugin_dir_path(__FILE__));


        if (is_admin()) {
            PeepSoVideosAdmin::get_instance();
        } else {

            if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
                return;
            }

            add_filter('peepso_post_types', array(&$this, 'post_types'), 10, 2);
            add_filter('peepso_postbox_html-videos', array(&$this, 'display_video_postbox'));
            add_filter('peepso_activity_stream_action', array(&$this, 'activity_stream_action'), 10, 2);
            add_filter('peepso_postbox_tabs', array(&$this, 'postbox_tabs'));
            add_filter('peepso_activity_allow_empty_content', array(&$this, 'activity_allow_empty_content'), 10, 1);
            add_filter('peepso_postbox_interactions', array(&$this, 'postbox_interactions'), 100, 2);
            add_filter('peepso_get_object_video', array(&$this, 'get_modal_video'), 10, 2);

            add_action('wp_enqueue_scripts', array(&$this, 'enqueue_scripts'));
            add_action('peepso_activity_post_attachment', array(&$this, 'attach_video'), 30, 1);

            add_filter('peepso_activity_insert_data', array(&$this, 'activity_insert_data'));
            add_action('peepso_activity_after_add_post', array(&$this, 'after_add_post'));
            add_action('peepso_activity_after_save_post', array(&$this, 'after_add_post'), 10, 1);

            // hide activity from groups if groupso deactivate #1760
            add_filter('peepso_action_activity_hide_before', array(&$this, 'activity_hide_before'), 10, 3);

            // needs to be initialized here otherwise scripts don't get enqueued
            PeepSoVideosYoutube::get_instance();
            PeepSoVideosVimeo::get_instance();

            add_action('peepso_delete_content', array(&$this, 'delete_content'));
            #add_filter('peepso_content_media', array(&$this, 'content_media'), 10, 2);
            add_filter('peepso_activity_post_edit', array(&$this, 'activity_post_edit'), 10, 2);

            // notifications
            add_filter('peepso_notifications_activity_type', array(&$this, 'notifications_activity_type'), 10, 2);

            // groups
            add_filter('peepso_group_segment_menu_links', array(&$this, 'filter_group_segment_menu_links'));
            add_action('peepso_group_segment_videos', array(&$this, 'peepso_group_segment_videos'), 10, 2);
        }

        add_filter('peepso_profile_alerts', array(&$this, 'profile_alerts'), 10, 1);
        add_filter('peepso_widgets', array(&$this, 'register_widgets'));

        // Hooks into profile pages and "me" widget
        add_action('peepso_profile_segment_videos', array(&$this, 'peepso_profile_segment_videos'));
        add_filter('peepso_navigation_profile', array(&$this, 'filter_peepso_navigation_profile'));
        add_filter('peepso_rewrite_profile_pages', array(&$this, 'peepso_rewrite_profile_pages'));
        add_filter('peepso_filter_opengraph_' . self::MODULE_ID, array(&$this, 'peepso_filter_opengraph'), 10, 2);

        // Hook into Groups segment menu
        add_filter('peepso_navigation_profile', array(&$this, 'filter_peepso_navigation_profile'));

		// Compare last version stored in transient with current version
		if( $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE != get_transient($trans = 'peepso_'.$this::PLUGIN_SLUG.'_version')) {
			set_transient($trans, $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE);
			global $wpdb;
			$wpdb->query('ALTER TABLE '. $wpdb->prefix.'peepso_videos MODIFY COLUMN `vid_description` TEXT');
			$this->activate();
		}
    }

	/**
	 * Called before PeepSo saves the "site" config page
	 * Deletes the cached license in order to forcefully revalidate
	 */
	public function before_save_site()
	{
		PeepSoLicense::delete_transient(self::PLUGIN_SLUG);
	}

    /**
     * Adds the license key information to the config metabox
     * @param array $list The list of license key config items
     * @return array The modified list of license key items
     */
    public function add_license_info($list)
    {
        $data = array(
            'plugin_slug' => self::PLUGIN_SLUG,
            'plugin_name' => self::PLUGIN_NAME,
            'plugin_edd' => self::PLUGIN_EDD,
            'plugin_version' => self::PLUGIN_VERSION
        );
        $list[] = $data;
        return ($list);
    }

    public function license_notice()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG);
    }

    public function license_notice_forced()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG, true);
    }

    /**
     * Plugin activation
     * Check PeepSo
     * @return bool
     */
    public function activate()
    {
        if (!$this->peepso_check()) {
            return (FALSE);
        }

        require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'activate.php');
        $install = new PeepSoVideosInstall();
        $res = $install->plugin_activation();
        if (FALSE === $res) {
            // error during installation - disable
            deactivate_plugins(plugin_basename(__FILE__));
        }

        return (TRUE);
    }

    /**
     * Check if PeepSo class is present (ie the PeepSo plugin is installed and activated)
     * If there is no PeepSo, immediately disable the plugin and display a warning
     * Run license and new version checks against PeepSo.com
     * @return bool
     */
    public function peepso_check()
    {
        if (!class_exists('PeepSo')) {
            add_action('admin_notices', array(&$this, 'peepso_disabled_notice'));
            unset($_GET['activate']);
            deactivate_plugins(plugin_basename(__FILE__));
            return (FALSE);
        }

        // PeepSo.com license check
        if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
            add_action('admin_notices', array(&$this, 'license_notice'));
        }

        if (isset($_GET['page']) && 'peepso_config' == $_GET['page'] && !isset($_GET['tab'])) {
            add_action('admin_notices', array(&$this, 'license_notice_forced'));
        }

        // PeepSo.com new version check
        // since 1.7.6
        if(method_exists('PeepSoLicense', 'check_updates_new')) {
            PeepSoLicense::check_updates_new(self::PLUGIN_EDD, self::PLUGIN_SLUG, self::PLUGIN_VERSION, __FILE__);
        }

        return (TRUE);
    }

    /**
     * Display a message about PeepSo not present
     */
    public function peepso_disabled_notice()
    {
        ?>
        <div class="error peepso">
            <strong>
                <?php echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'vidso'), self::PLUGIN_NAME);?>
                <a href="<?php echo self::PEEPSOCOM_LICENSES;?>" target="_blank">
                    <?php _e('Get it now!', 'vidso');?>
                </a>
            </strong>
        </div>
        <?php
    }

    /**
     * Hooks into PeepSo for compatibility checks
     * @param $plugins
     * @return mixed
     */
    public function filter_all_plugins($plugins)
    {
        $plugins[plugin_basename(__FILE__)] = get_class($this);
        return $plugins;
    }

    /*
     * Get the directory the plugin is installed in
     * @return string The plugin directory, including a trailing slash
     */
    public static function get_plugin_dir()
    {
        return (plugin_dir_url(__FILE__));
    }

    /**
     * Adds the Videos tab to the available post type options
     * @param  array $post_types
     * @param  array $params
     * @return array
     */
    public function post_types($post_types, $params = array())
    {
        if (isset($params['is_current_user']) && $params['is_current_user'] === FALSE) {
            return ($post_types);
        }

        if(!apply_filters('peepso_permissions_videos_upload', TRUE)) {
            return $post_types;
        }

        $post_types['videos'] = array(
            'icon' => 'youtube-play',
            'name' => __('Video', 'vidso'),
            'class' => 'ps-postbox__menu-item',
        );

        return ($post_types);
    }

    /*
     * enqueue scripts for peepsovideos
     */
    public function enqueue_scripts()
    {
        wp_register_script('peepsovideos', plugin_dir_url(__FILE__) . 'assets/js/bundle.min.js', array(
            'peepso',
            'peepso-page-autoload',
            'peepso-postbox'
        ), self::PLUGIN_VERSION, TRUE);
    }

    /**
     * Displays the UI for the video post type
     * @return string The input html
     */
    public function postbox_tabs($tabs)
    {
        wp_enqueue_script('peepsovideos');
        wp_enqueue_style('peepsovideos');
        // TODO: where are these being registered?
        // SpyDroid: enqueue_scripts() method of classes/videosyoutube.php
        // wp_enqueue_script('peepsovideosyoutubeiframeapi');
        // wp_enqueue_script('peepsovideosyoutube');

        if(!apply_filters('peepso_permissions_videos_upload', TRUE)) {
            return $tabs;
        }

        $tabs['videos'] = PeepSoTemplate::exec_template('videos', 'postbox-videos', NULL, TRUE);

        return ($tabs);
    }

    /**
     * Extract URL from a given post content
     * @param  string $content Contents of the post
     * @return array list of URLs
     */
    private function parse_urls($content)
    {
        static $urls = array(); // used for cache
        $hash = md5($content);
        if (!isset($urls[$hash])) {
            $pattern = "#\b(([\w-]+://?|www[.])[^\s()<>]+(?:\([\w\d]+\)|([^[:punct:]\s]|/)))#i";
            $content = preg_replace('/<p[^>]*>(.*)<\/p[^>]*>/i', '$1', $content);

            $this->_urls = array();
            add_filter('oembed_dataparse', array(&$this, 'oembed_dataparse'), 10, 2);
            preg_replace_callback($pattern, array(&$this, 'video_url'), $content);
            remove_filter('oembed_dataparse', array(&$this, 'oembed_dataparse'), 10, 2);

            $urls[$hash] = $this->_urls;
        }
        return ($urls[$hash]);
    }

    /**
     * Adds the post_media metadata to the post, only called when submitting from the videos tab
     * @param  int $post_id The post ID
     */
    public function after_add_post($post_id)
    {
        global $wpdb;

        $input = new PeepSoInput();
        $url = $input->val('url');
        $module_id = $input->int('module_id', 0);

        if (empty($url))
            return;

        // delete any existing video
        $wpdb->delete($wpdb->prefix . self::TABLE, array('vid_post_id' => $post_id));

        $media = $this->parse_oembed_url($url);

        if ($media) {
            $vid_data = array(
                'vid_post_id' => $post_id,
                'vid_description' => $media['description'],
                'vid_embed' => $media['content'],
                'vid_url' => $url,
                'vid_title' => $media['title'],
                'vid_module_id' => $module_id
            );

            if ( preg_match( '/facebook\.com/', $media['host'] ) ) {
                $video_id = preg_replace( '/^.+videos\/(\d+)\/?$/i', '$1', $url );
                $vid_data['vid_thumbnail'] = 'https://graph.facebook.com/' . $video_id . '/picture';
            } elseif ( isset($media['thumbnail'] ) ) {
                $vid_data['vid_thumbnail'] = $media['thumbnail'];
            }

            $wpdb->insert($wpdb->prefix . self::TABLE, $vid_data);
        }
    }

    /*
     * Callback for preg_replace_callback to extract video url
     *
     * @param array $matches The matched items
     * @return string the modified url
     */
    public function video_url($matches)
    {
        $url = strip_tags($matches[0]);

        if (FALSE === strpos($url, '://'))
            $url = 'http://' . $url;

        $embed_code = ps_oembed_get($url, array('width' => 500, 'height' => 300));
        // Get video only
        if ($embed_code && 'video' === $this->_oembed_type)
            $this->_urls[] = $url;

        return ($url);
    }


    /**
     * Sets the activity's module ID to the plugin's module ID
     * @param  array $activity
     * @return array
     */
    public function activity_insert_data($activity)
    {
        $input = new PeepSoInput();

        $type = $input->val('type');

        if ('video' === $type)
            $activity['act_module_id'] = self::MODULE_ID;

        return ($activity);
    }

    /**
     * Parse the oembed response to get the format needed to display the content
     * @param  string $url The URL to check for
     * @return array
     */
    public function parse_oembed_url($url)
    {
        if (FALSE === strpos($url, '://'))
            $url = 'http://' . $url;

        add_filter('oembed_dataparse', array(&$this, 'oembed_dataparse'), 10, 2);
        $response = ps_oembed_get($url, array('width' => 500, 'height' => 300));
        remove_filter('oembed_dataparse', array(&$this, 'oembed_dataparse'), 10, 2);

        if (FALSE === $response || 'video' !== $this->_oembed_type)
            return (FALSE);


        $media['content'] = $response;
        $media['title'] = (NULL === $this->_oembed_title) ? $url : $this->_oembed_title;
        $media['host'] = parse_url($url, PHP_URL_HOST);
        $media['url'] = $url;
        $media['description'] = $url;
        $media['target'] = PeepSo::get_option('site_activity_open_links_in_new_tab', '');
        $media['force_oembed'] = true;
        $media['oembed_type'] = 'video';

        $og_tags = PeepSoOpenGraph::fetch($url);

        if ($og_tags) {
            if ($og_tags->title)
                $media['title'] = $og_tags->title;

            if ($og_tags->description)
                $media['description'] = $og_tags->description;
        }

        if (isset($this->_oembed_data->thumbnail_url))
            $media['thumbnail'] = $this->_oembed_data->thumbnail_url;

        return ($media);
    }

    /**
     * Assigns the oemebed type
     * @param  array $return
     * @param  object $data The oembed response data
     * @return array
     */
    public function oembed_dataparse($return, $data)
    {
        $this->_oembed_data = $data;
        $this->_oembed_type = $data->type;

        // Title is an optional oembed response
        if (isset($data->title))
            $this->_oembed_title = $data->title;

        return ($return);
    }

    /**
     * Get a video associated with a post
     * @param  int $post_id
     * @return
     */
    public function get_post_video($post_id)
    {
        global $wpdb;

        $sql = "SELECT * FROM `{$wpdb->prefix}" . self::TABLE . '` WHERE `vid_post_id` = %d';

        return ($wpdb->get_results($wpdb->prepare($sql, $post_id)));
    }

    /**
     * Attach the video to the post display
     * @param  object $post The post
     */
    public function attach_video($post)
    {
        $post_videos = $this->get_post_video($post->ID);

        if (empty($post_videos))
            return;

        PeepSoVideosYoutube::get_instance(); // load only when filter peepso_videos_attachment is called/applied
        foreach ($post_videos as $post_video) {
            $video = array(
                'content' => $post_video->vid_embed,
                'title' => $post_video->vid_title,
                'host' => parse_url($post_video->vid_url, PHP_URL_HOST),
                'url' => $post_video->vid_url,
                'description' => $post_video->vid_description,
                'target' => PeepSo::get_option('site_activity_open_links_in_new_tab', ''),
                'thumbnail' => isset($post_video->vid_thumbnail) ? $post_video->vid_thumbnail : ''
            );

            if (isset($post_video->vid_thumbnail)) {
                $data = array(
                    'id' => $post_video->vid_id,
                    'content' => '',
                    'thumbnail' => $post_video->vid_thumbnail,
                    'onclick' => (ps_isempty($post->is_repost) ? 'ps_videos.play_video(this);' : "ps_comments.open({$post->ID}, 'video');")
                );
                $video['content'] = $post_video->vid_embed;#PeepSoTemplate::exec_template('videos', 'thumbnail', $data, TRUE);
            }
            #$video = apply_filters('peepso_videos_attachment', $video, $post);

            $video['force_oembed'] = TRUE;

            // make iframe full-width
            if (preg_match('/<iframe/i', $video['content'])) {
                $width_pattern = "/width=\"[0-9]*\"/";
                $video['content'] = preg_replace($width_pattern, "width='100%'", $video['content']);
                $video['content'] = '<div class="ps-media-iframe">' . $video['content'] . '</div>';
            }

            // Improve Facebook embedded content rendering.
            if (preg_match('#class="fb-(post|video)"#i', $video['content'])) {

                // Remove Facebook SDK loader code.
                $video['content'] = preg_replace('#<div[^>]+id="fb-root"[^<]+</div>#i', '', $video['content']);
                $video['content'] = preg_replace('#<script[^<]+</script>#i', '', $video['content']);

                // Remove width setting, follow container width.
                // #1931 Fix Facebook video issue.
                $video['content'] = preg_replace('#\sdata-width=["\']\d+%?["\']#i', '', $video['content']);
            }

            $video = apply_filters('peepso_videos_attach_before', $video);

            PeepSoTemplate::exec_template('activity', 'content-media', $video);
        }
    }

    /**
     * Change the activity stream item action string
     * @param  string $action The default action string
     * @param  object $post   The activity post object
     * @return string
     */
    public function activity_stream_action($action, $post)
    {
        if (self::MODULE_ID === intval($post->act_module_id))
            $action = __(' posted a video', 'vidso');

        return ($action);
    }

    /**
     * Deletes videos associated to a post when it is deleted
     * @param  int $post_id The post ID
     */
    public function delete_content($post_id)
    {
        global $wpdb;

        $wpdb->delete($wpdb->prefix . self::TABLE, array('vid_post_id' => $post_id));
    }

    /**
     * Checks if empty content is allowed
     * @param boolean $allowed
     * @return boolean always returns TRUE
     */
    public function activity_allow_empty_content($allowed)
    {
        $input = new PeepSoInput();
        $type = $input->val('type');
        if ('video' === $type)
            $allowed = TRUE;
        return ($allowed);
    }

    /**
     * Format post_media video type
     * @param array $media PeepSo media post attachment
     * @return array $media Modified peepso media post attachment
     */
    public function content_media($media, $post)
    {
        PeepSoVideosYoutube::get_instance(); // load only when filter peepso_videos_attachment is called/applied
        foreach ($media as $key => $value) {
            $post_video = (isset($value['url']) && $value['url']) ? $this->parse_oembed_url($value['url']) : NULL;
            if (!$post_video)
                continue;

            $video_id = $post->ID . '-' . $key;
            if (isset($post_video['thumbnail'])) {
                $data = array(
                    'id' => $video_id,
                    'content' => $value['content'],
                    'thumbnail' => $post_video['thumbnail'],
                );
                $post_video['content'] = PeepSoTemplate::exec_template('videos', 'thumbnail', $data, TRUE);
            }
            $media[$key] = apply_filters('peepso_videos_attachment', $post_video, $post);
        }
        return ($media);
    }

    /**
     * Append input box to edit URL
     * @param array $data Contains 'cont' and 'post_id' indexes used for rendering edit box
     * @return array $data Modified input box
     */
    public function activity_post_edit($data)
    {
        // add prefix input box
        $video = $this->get_post_video($data['post_id']);
        if (isset($video[0])) {
            $post_edit = array(
                'url' => $video[0]->vid_url,
                'post_id' => $data['post_id'],
            );
            PeepSoTemplate::exec_template('videos', 'post-edit', $post_edit, TRUE);
            $data['prefix'] = PeepSoTemplate::exec_template('videos', 'post-edit', array('url' => $video[0]->vid_url), TRUE);
        }
        return ($data);
    }

    /**
     * This function inserts the video options on the post box
     * @param array $interactions is the formated html code that get inserted in the postbox
     * @param array $params
     */
    public function postbox_interactions($interactions, $params = array())
    {
        if (isset($params['is_current_user']) && $params['is_current_user'] === FALSE) {
            return ($interactions);
        }

        if(!apply_filters('peepso_permissions_videos_upload', TRUE)) {
            return $interactions;
        }

        $interactions['videos'] = array(
            'icon' => 'youtube-play',
            'id' => 'video-post',
            'class' => 'ps-postbox__menu-item',
            'click' => 'return;',
            'label' => '',
            'title' => __('Upload videos', 'vidso')
        );

        return ($interactions);
    }

    /**
     * modal comment callback
     * Returns the embedded video.
     * @param  array $objects
     * @param  int $post_id The ID of the post.
     * @return array
     */
    public function get_modal_video($objects, $post_id)
    {
        $video = $this->get_post_video($post_id);

        if (NULL !== $video) {
            $video = $video[0];
            $activity = new PeepSoActivity();
            $post = $activity->get_post($post_id);

            $video->vid_embed = preg_replace('#\sheight=["\']\d+%?["\']#i', " height='350'", $video->vid_embed);
            $video->vid_embed = preg_replace('#\swidth=["\']\d+%?["\']#i', " width='100%'", $video->vid_embed);

            // Fix Facebook SDK loader code.
            if ( preg_match('#class="fb-(post|video)"#i', $video->vid_embed ) ) {
                $video->vid_embed = preg_replace( '#<div[^>]+id="fb-root"[^<]+</div>#i', '', $video->vid_embed );
                $video->vid_embed = preg_replace( '#data-href#i', 'data-autoplay="1" data-href', $video->vid_embed );
            }

            $objects[$post_id] = array(
                'module_id' => self::MODULE_ID,
                'content' 	=> $video->vid_embed,
                'post' 		=> $post->post
            );
        }

        return ($objects);
    }

    /**
     * Add capability for like/comment/share video
     * @param $activity_type modified activity type (default is `post`)
     * @param $post_id Post Id in notification or email
     */
    public function notifications_activity_type($activity_type, $post_id) {

        /**
         * Please note that we mus define email template for each
         * 1. like_{type}
         * 2. user_comment_{type}
         * 3. share_{type}
         */

        ## @todo: find other way to escape translation for template name

        $video = $this->get_post_video($post_id);

        if ( count( $video ) > 0 && is_array($activity_type)) {

            $type = 'video';
            if(in_array($activity_type['type'], array('user_comment', 'share'))) {
                $type = $activity_type['type'] . '_' . $type;
            }

            $activity_type = array(
                    'type' => $type,
                    'text' => __('video', 'vidso')
                );
        }

        return ($activity_type);
    }

    /**
     * Hide activity when groupso deactivate
     * @param boolean $hide
     * @return boolean always returns TRUE
     */
    public function activity_hide_before($hide, $post_id, $module_id)
    {
        $group_id = get_post_meta($post_id, 'peepso_group_id', TRUE);

        if(!empty($group_id) && !class_exists('PeepSoGroup') && self::MODULE_ID == $module_id) {
            $hide = TRUE;
        }

        return ($hide);
    }


    /**
     * Callback for the core 'peepso_widgets' filter; appends our widgets to the list
     * @param $widgets
     * @return array
     */
    public function register_widgets($widgets)
    {
        if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG, 0)) {
            return $widgets;
        }

        // register widgets
        // @TODO that's too hacky - why doesn't autoload work?
        foreach (scandir($widget_dir = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'widgets' . DIRECTORY_SEPARATOR) as $widget) {
            if(strlen($widget)>=5) require_once($widget_dir . $widget);
        }
        return array_merge($widgets, $this->widgets);
    }


    /**
     * Append profile alerts definition for peepsovideos
     */
    public function profile_alerts($alerts)
    {
        $alerts['videos'] = array(
                'title' => __('Videos', 'vidso'),
                'items' => array(
                    array(
                        'label' => __('Someone liked my Video', 'vidso'),
                        'setting' => 'like_video',
                        'loading' => TRUE,
                    ),
                    array(
                        'label' => __('Someone commented on my Video', 'vidso'),
                        'setting' => 'user_comment_video',
                        'loading' => TRUE,
                    ),
                    array(
                        'label' => __('Someone shared my Video', 'vidso'),
                        'setting' => 'share_video',
                        'loading' => TRUE,
                    )
                ),
        );
        // NOTE: when adding new items here, also add settings to /install/activate.php site_alerts_ sections
        return ($alerts);
    }

    public function filter_peepso_navigation_profile($links)
    {
        $links['videos'] = array(
            'href' => 'videos',
            'label'=> __('Videos', 'vidso'),
            'icon' => 'ps-icon-videocam'
        );

        return $links;
    }

    public function filter_group_segment_menu_links($links)
    {
        $links[30][] = array(
            'href' => 'videos',
            'title'=> __('Videos', 'vidso'),
            'icon' => 'ps-icon-videocam',
        );

        ksort($links);
        return $links;
    }

    public function peepso_profile_segment_videos()
    {
        $pro = PeepSoProfileShortcode::get_instance();
        $this->view_user_id = PeepSoUrlSegments::get_view_id($pro->get_view_user_id());

        echo PeepSoTemplate::exec_template('videos', 'videos', array('view_user_id' => $this->view_user_id), TRUE);
        wp_enqueue_script('peepsovideos');
    }

    public function peepso_rewrite_profile_pages($pages)
    {
        return array_merge($pages, array('videos'));
    }

	public function peepso_filter_opengraph($tags, $activity)
	{
		$video = PeepSoVideos::get_instance()->get_post_video($activity->ID);
		if (count($video) > 0)
		{
			$tags['image'] = $video[0]->vid_thumbnail;
		}

		return $tags;
	}

    public function peepso_group_segment_videos($args, $url_segments)
    {
        if(!$url_segments instanceof PeepSoUrlSegments) {
            $url_segments = PeepSoUrlSegments::get_instance();
        }

        $this->view_user_id = $args['group']->id;

        echo PeepSoTemplate::exec_template('videos', 'videos-group', array_merge(array('view_user_id' => $this->view_user_id), $args), TRUE);
        wp_enqueue_script('peepsovideos');
    }
}

PeepSoVideos::get_instance();

// EOF
