<?php
echo $args['before_widget'];

$PeepSoLimitUsers = PeepSoLimitUsers::get_instance();

// widget title
if (!empty( $instance['title'])) {
    echo $args['before_title'] . apply_filters( 'widget_title', $instance['title'] ). $args['after_title'];
}

// short message to the user
if( !empty($instance['message'])) {
    echo '<p>' , $instance['message'] , '</p>';
}

echo PeepSoLimitUsers::get_instance()->debug_formatted();
?>
<style type="text/css">
    .limitusers-user-description {
        font-size: 12px;
    }
</style>
<?php

echo $args['after_widget'];

// EOF
