<?php

if (isset($data['avatar']) && count($data['avatar'])) {
    echo '<p>';
    echo '<strong>', __('Upload an avatar to:', 'peepsolimitusers'), '</strong>';
    echo '<ul>';
    foreach ($data['avatar'] as $section) {
        echo '<li class="limitusers-user-description">', $sections_descriptions[$section], '</li>';
    }
    echo '</ul>';
    echo '</p>';
}

if (isset($data['profile']) && count($data['profile'])) {

    ksort($data['profile']);

    echo '<p>';
    echo '<strong>', __('Complete your profile to:', 'peepsolimitusers'), '</strong>';
    echo '<ul>';
    foreach ($data['profile'] as $limit => $sections) {
        foreach ($sections as $section) {
            echo '<li class="limitusers-user-description">', $sections_descriptions[$section], ' (', $limit, '%)</li>';
        }

    }

    echo '</ul>';
    echo '</p>';
}