<div style="width:100%;padding:20px 0px 20px 0px;text-align:center;background:white;border-bottom:dashed 1px #aaaaaa;">

    <h1 style="">Before you start, here's what you should know</h1>
    <a href="<?php echo admin_url();?>admin.php?page=peepso_config&tab=limitusers&limitusers_tutorial_hide" class="button button-secondary">I understand, do not show this message again</a>
</div>
<table style="background:white;">
    <tr>
        <td style="width:50%;padding:20px;" valign="top">

            <h3>Core</h3>

            <p>This column controls the behavior of PeepSo.</p>

        </td>
        <td style="width:50%;padding:20px;" valign="top">

            <h3>Add-Ons</h3>

            <p>Additional options for Add-Ons will show here once these plugins are installed and activated - works with Friends, Groups, Photos and Videos.</p>

        </td>
    </tr>
    <tr>
        <td>
            <p style="font-size:30px;width:100%;text-align:center;">&darr;</p>
        </td>
        <td>
            <p style="font-size:30px;width:100%;text-align:center;">&darr;</p>
    </tr>
</table>