<?php

class PeepSoConfigSectionMyCred extends PeepSoConfigSectionAbstract {

// Builds the groups array
	public function register_config_groups() {
		$this->context = 'left';
		$this->_group_general();
	}

	private function _group_general() {
		# Enable myCRED
		if (class_exists('myCRED_Core')) {
			$this->args('default', 1);
			$this->set_field(
					'mycred_enabled', __('Show myCRED Points', 'peepsocreds'), 'yesno_switch'
			);

			# Enable myCRED Description
			$this->set_field(
					'mycred_enabled_description', __("When enabled it will show user's points in their profile under their cover image.", 'peepsocreds'), 'message'
			);
		} else {

			$mycred = ' <a href="plugin-install.php?tab=plugin-information&plugin=mycred&TB_iframe=true&width=750&height=500" class="thickbox">myCRED</a> ';


			# Enable myCRED Description
			$this->set_field(
					'mycred_disabled_description', sprintf(__("Requires $mycred to be installed and properly configured. This is a third party plugin, so use at your own risk.<br/><br/><br/>"
									. "$mycred not found! Please install the plugin to see the configuration setting", 'peepsocreds'), $mycred), 'message'
			);
		}

		// Build Group
		$this->set_group(
				'general', __('General', 'peepsocreds')
		);
	}

}
