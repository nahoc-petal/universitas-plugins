<?php
/**
 * Plugin Name: PeepSo Integrations: myCRED
 * Plugin URI: https://peepso.com
 * Description: Award myCRED points for performing actions in PeepSo
 * Author: PeepSo
 * Author URI: https://peepso.com
 * Version: 1.10.0
 * Copyright: (c) 2015 PeepSo, Inc. All Rights Reserved.
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: peepsocreds
 * Domain Path: /language
 *
 * We are Open Source. You can redistribute and/or modify this software under the terms of the GNU General Public License (version 2 or later)
 * as published by the Free Software Foundation. See the GNU General Public License or the LICENSE file for more details.
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.
 */

if (!defined('ABSPATH'))
	exit; // Exit if accessed directly

if (!mycred_check()) {
	return;
}

add_filter('mycred_setup_hooks', 'my_peepsocreds_setup_hooks');  //, 10, 2 
add_action('mycred_load_hooks', 'my_peepsocreds_load_hooks');
add_action('peepso_init', 'init', 90);
add_action('plugins_loaded', 'load_textdomain_mycred');

function load_textdomain_mycred()
{
	$path = str_ireplace(WP_PLUGIN_DIR, '', dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'language' . DIRECTORY_SEPARATOR;
	load_plugin_textdomain('peepsocreds', FALSE, $path);
}

function my_peepsocreds_setup_hooks($installed) { //, $point_type ) {
	// Add a custom hook
	$installed['peepsocreds'] = array(
		'title' => 'PeepSo',
		'description' => 'Receive points for PeepSo activities.',
		'callback' => array('myCRED_Hook_PeepSo')
	);

	return $installed;
}

function my_peepsocreds_load_hooks() {
	if (!class_exists('myCRED_Hook_PeepSo')) :

		class myCRED_Hook_PeepSo extends myCRED_Hook {

			const PLUGIN_EDD	 = 69775;
			const PLUGIN_SLUG = 'peepso-mycred';
			const PLUGIN_NAME	 = 'Integrations: myCRED';
			const PLUGIN_VERSION = '1.10.0';
			const PLUGIN_RELEASE = ''; //ALPHA1, BETA1, RC1, '' for STABLE

            const ICON = 'https://www.peepso.com/wp-content/plugins/peepso.com-checkout/assets/icons/mycred_icon.svg';

			function __construct($hook_prefs, $type = 'mycred_default') {

				parent::__construct(array(
					'id' => 'peepsocreds',
					'defaults' => array(
						'new_peepso-post' => array(
							'creds' => 1,
							'log' => '%plural% for new post',
							'limit' => '0/x'
						),
						'delete_peepso-post' => array(
							'creds' => 0,
							'log' => '%singular% deduction for deleted post'
						),
						'new_peepso-message' => array(
							'creds' => 1,
							'log' => '%plural% for new message',
							'author' => 0,
							'limit' => '0/x'
						),
						'delete_peepso-message' => array(
							'creds' => 0,
							'log' => '%singular% deduction for deleted message'
						),
						'new_peepso-comment' => array(
							'creds' => 1,
							'log' => '%plural% for new comment',
							'author' => 0,
							'limit' => '0/x'
						),
						'delete_peepso-comment' => array(
							'creds' => 0,
							'log' => '%singular% deduction for deleted comment'
						),
						'add_peepso_friend' => array(
							'creds' => 1,
							'log' => '%plural% for add friend',
							'limit' => '0/x'
						),
						'delete_peepso_friend' => array(
							'creds' => 0,
							'log' => '%singular% deduction for deleted friend'
						),
						//
						// Photos
						//
						'new_peepso_stream_photo' => array(
							'creds' => 1,
							'log' => '%plural% for new stream photo',
							'limit' => '0/x'
						),
						'delete_peepso_stream_photo' => array(
							'creds' => 0,
							'log' => '%singular% deduction for deleted stream photo'
						),
						'new_peepso_profile_cover' => array(
							'creds' => 1,
							'log' => '%plural% for new profile cover',
							'limit' => '0/x'
						),
						'delete_peepso_profile_cover' => array(
							'creds' => 0,
							'log' => '%singular% deduction for deleted profile cover'
						),
						'new_peepso_profile_avatar' => array(
							'creds' => 1,
							'log' => '%plural% for new profile avatar',
							'limit' => '0/x'
						),
						'delete_peepso_profile_avatar' => array(
							'creds' => 0,
							'log' => '%singular% deduction for deleted profile avatar'
						),
					),
				), $hook_prefs, $type);
			}		


			public function run() {
				// license checking
				if (!class_exists('PeepSoLicense') || !PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
					return;
				}

				// New Post
				// New Message
				// New Comment
				add_action('transition_post_status', array($this, 'publishing_peepso_content'), 10, 3);

				// Delete Post
				// Delete Message
				// Delete Comment
				add_action('delete_post', array($this, 'deleting_peepso_content'), 10, 1);

				// Friends add/delete
				add_action('peepsofriends_after_add', array($this, 'peepsofriends_after_add'), 10, 2);
				add_action('peepsofriends_after_delete', array($this, 'peepsofriends_after_delete'), 10, 2);
				add_action('peepso_friends_after_delete', array($this, 'peepsofriends_after_delete'), 10, 2);
			}

			function peepsofriends_after_add($from_id, $to_id) {

				// Check if user is excluded
				if ($this->core->exclude_user($from_id))
					return;

				// Limit
				if ($this->over_hook_limit('add_peepso_friend', 'add_peepso_friend', $from_id))
					return;

				// Make sure this is unique event
				if ($this->has_entry('add_peepso_friend', $to_id, $from_id))
					return;

				// Execute
				$this->core->add_creds(
					'add_peepso_friend', $from_id, $this->prefs['add_peepso_friend']['creds'], $this->prefs['add_peepso_friend']['log'], $to_id, array('ref_type' => 'post'), $this->mycred_type
				);
			}

			function peepsofriends_after_delete($from_id, $to_id) {

				// Check if user is excluded
				if ($this->core->exclude_user($from_id))
					return;

				if ($this->has_entry('add_peepso_friend', $from_id, $to_id) && !$this->has_entry('add_peepso_friend', $to_id, $from_id)) {

					$tmp = $from_id;
					$from_id = $to_id;
					$to_id = $tmp;
				}

				if ($this->has_entry('delete_peepso_friend', $to_id, $from_id))
					return;

				// Execute
				$this->core->add_creds(
					'delete_peepso_friend', $from_id, $this->prefs['delete_peepso_friend']['creds'], $this->prefs['delete_peepso_friend']['log'], $to_id, array('ref_type' => 'post'), $this->mycred_type
				);
			}

			public function publishing_peepso_content($new_status, $old_status, $post) {

				$user_id = $post->post_author;

				// Check for exclusions
				if ($this->core->exclude_user($user_id) === true)
					return;

				$post_id = $post->ID;
				$post_type = $post->post_type;

				$new_post_type = 'new_' . $post_type;

				if (!in_array($post->post_type, array('peepso-post', 'peepso-message', 'peepso-comment')))
					return; // it is not peepso content

				$is_photo = false;

				if ('peepso-post' == $post->post_type) {

					//
					// May be it is photo? // pho_post_id
					//
					global $wpdb;

					// pho_album_name
					$sql = 'SELECT p.`pho_id`, a.pho_system_album 
    FROM `' . $wpdb->prefix . 'peepso_photos` p INNER JOIN `' . $wpdb->prefix . 'peepso_photos_album` a ON a.pho_album_id = p.pho_album_id
    WHERE p.pho_post_id = ' . (1 * $post_id);

					$photos = $wpdb->get_results($sql);

					if (!empty($photos)) {

						foreach ($photos as $photo) {

							if (3 == $photo->pho_system_album) {
								$new_post_type = 'new_peepso_stream_photo';
								$is_photo = true;
							} else {
								if (2 == $photo->pho_system_album) {
									$new_post_type = 'new_peepso_profile_cover';
									$is_photo = true;
								} else {
									if (1 == $photo->pho_system_album) {
										$new_post_type = 'new_peepso_profile_avatar';
										$is_photo = true;
									} else {
										// unknow album, do nothing
									}
								}
							}

							break;
						}
					}
				}

				// Make sure we award points other then zero
				if (!isset($this->prefs[$new_post_type]['creds']))
					return;
				if (empty($this->prefs[$new_post_type]['creds']) || $this->prefs[$new_post_type]['creds'] == 0)
					return;

				// We want to fire when content get published or when it gets privatly published
				$status = apply_filters('mycred_publish_hook_old', array('new', 'auto-draft', 'draft', 'private', 'pending', 'future'));
				$publish_status = apply_filters('mycred_publish_hook_new', array('publish', 'private'));

				if ((
						($is_photo && 'publish' == $new_status && 'publish' == $old_status) ||
						(in_array($old_status, $status) && in_array($new_status, $publish_status))
					) && array_key_exists($new_post_type, $this->prefs)) {

					// Prep
					$entry = $this->prefs[$new_post_type]['log'];
					$data = array('ref_type' => 'post');

					// Make sure this is unique
					if ($this->core->has_entry($new_post_type, $post_id, $user_id, $data, $this->mycred_type))
						return;

					// Check limit
					if (!$this->over_hook_limit($new_post_type, $new_post_type, $user_id)) {

						$this->core->add_creds(
							$new_post_type, $user_id, $this->prefs[$new_post_type]['creds'], $entry, $post_id, $data, $this->mycred_type
						);
					}
				}
			}

			public function deleting_peepso_content($post_id) {

				$post = get_post($post_id);

				if (!$post || !is_object($post))
					return;

				$user_id = $post->post_author;

				// Check for exclusions
				if ($this->core->exclude_user($user_id) === true)
					return;

				$post_type = $post->post_type;

				$delete_post_type = 'delete_' . $post_type;

				if (!in_array($post->post_type, array('peepso-post', 'peepso-message', 'peepso-comment')))
					return; // it is not peepso content

				$is_photo = false;

				if ('peepso-post' == $post->post_type) {

					//
					// May be it is photo? // pho_post_id
					//
					global $wpdb;

					// pho_album_name
					$sql = 'SELECT p.`pho_id`, a.pho_system_album 
    FROM `' . $wpdb->prefix . 'peepso_photos` p INNER JOIN `' . $wpdb->prefix . 'peepso_photos_album` a ON a.pho_album_id = p.pho_album_id
    WHERE p.pho_post_id = ' . (1 * $post_id);

					$photos = $wpdb->get_results($sql);

					if (!empty($photos)) {

						foreach ($photos as $photo) {

							if (3 == $photo->pho_system_album) {
								$delete_post_type = 'delete_peepso_stream_photo';
								$is_photo = true;
							} else {
								if (2 == $photo->pho_system_album) {
									$delete_post_type = 'delete_peepso_profile_cover';
									$is_photo = true;
								} else {
									if (1 == $photo->pho_system_album) {
										$delete_post_type = 'delete_peepso_profile_avatar';
										$is_photo = true;
									} else {
										// unknow album, do nothing
									}
								}
							}

							break;
						}
					}
				}

				if (array_key_exists($delete_post_type, $this->prefs)) {

					// Prep
					$entry = $this->prefs[$delete_post_type]['log'];
					$data = array('ref_type' => 'post');

					// Make sure this is unique
					if ($this->core->has_entry($delete_post_type, $post_id, $user_id, $data, $this->mycred_type))
						return;

					$this->core->add_creds(
						$delete_post_type, $user_id, $this->prefs[$delete_post_type]['creds'], $entry, $post_id, $data, $this->mycred_type
					);
				}
			}

			public function preferences() {

				$prefs = $this->prefs;

				if (!isset($prefs['new_peepso-post']['limit']))
					$prefs['new_peepso-post']['limit'] = '0/x';

				if (!isset($prefs['new_peepso-message']['limit']))
					$prefs['new_peepso-message']['limit'] = '0/x';

				if (!isset($prefs['new_peepso-comment']['limit']))
					$prefs['new_peepso-comment']['limit'] = '0/x';
				?>
				<!-- Creds for New PeepSo Post -->
				<label for="<?php echo $this->field_id(array('new_peepso-post', 'creds')); ?>"
					   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for New PeepSo Post', 'mycred')); ?></label>
				<ol>
					<li>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso-post', 'creds')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso-post', 'creds')); ?>"
											   value="<?php echo $this->core->number($prefs['new_peepso-post']['creds']); ?>" size="8" /></div>
					</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso-post', 'limit')); ?>"><?php _e('Limit', 'mycred'); ?></label>
						<?php echo $this->hook_limit_setting($this->field_name(array('new_peepso-post', 'limit')), $this->field_id(array('new_peepso-post', 'limit')), $prefs['new_peepso-post']['limit']);
						?>
					</li>
					<li class="empty">&nbsp;</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso-post', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso-post', 'log')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso-post', 'log')); ?>" value="<?php echo esc_attr($prefs['new_peepso-post']['log']); ?>"
											   class="long" /></div>
						<span class="description"><?php echo $this->available_template_tags(array('general', 'post')); ?></span>
					</li>
				</ol>
				<?php if (1) { ?>
					<!-- Creds for Deleting PeepSo Post -->
					<label for="<?php echo $this->field_id(array('delete_peepso-post', 'creds')); ?>"
						   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for PeepSo Post Deletion', 'mycred')); ?></label>
					<ol>
						<li>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso-post', 'creds')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso-post', 'creds')); ?>"
												   value="<?php echo $this->core->number($prefs['delete_peepso-post']['creds']); ?>" size="8" /></div>
						</li>
						<li class="empty">&nbsp;</li>
						<li>
							<label for="<?php echo $this->field_id(array('delete_peepso-post', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso-post', 'log')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso-post', 'log')); ?>" value="<?php echo esc_attr($prefs['delete_peepso-post']['log']); ?>"
												   class="long" /></div>
							<span class="description"><?php echo $this->available_template_tags(array('general')); ?></span>
						</li>
					</ol>
				<?php } ?>
				<!-- Creds for New PeepSo Message -->
				<label for="<?php echo $this->field_id(array('new_peepso-message', 'creds')); ?>"
					   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for New PeepSo Message', 'mycred')); ?></label>
				<ol>
					<li>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso-message', 'creds')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso-message', 'creds')); ?>"
											   value="<?php echo $this->core->number($prefs['new_peepso-message']['creds']); ?>" size="8" /></div>
					</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso-message', 'limit')); ?>"><?php _e('Limit', 'mycred'); ?></label>
						<?php echo $this->hook_limit_setting($this->field_name(array('new_peepso-message', 'limit')), $this->field_id(array('new_peepso-message', 'limit')), $prefs['new_peepso-message']['limit']);
						?>
					</li>
					<li class="empty">&nbsp;</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso-message', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso-message', 'log')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso-message', 'log')); ?>" value="<?php echo esc_attr($prefs['new_peepso-message']['log']); ?>"
											   class="long" /></div>
						<span class="description"><?php echo $this->available_template_tags(array('general', 'post')); ?></span>
					</li>
					<?php if (0) { ?>
						<li class="empty">&nbsp;</li>
						<li>
							<input type="checkbox" name="<?php echo $this->field_name(array('new_peepso-message' => 'author')); ?>"
								   id="<?php echo $this->field_id(array('new_peepso-message' => 'author')); ?>" <?php checked($prefs['new_peepso-message']['author'], 1); ?> value="1" />
							<label for="<?php echo $this->field_id(array('new_peepso-message' => 'author')); ?>"><?php echo $this->core->template_tags_general(__('PeepSo Message authors can receive %_plural% for creating new mesage.', 'mycred')); ?></label>
						</li>
					<?php } ?>
				</ol>
				<?php if (1) { ?>
					<!-- Creds for Deleting PeepSo Message -->
					<label for="<?php echo $this->field_id(array('delete_peepso-message', 'creds')); ?>" class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for PeepSo Message Deletion', 'mycred')); ?></label>
					<ol>
						<li>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso-message', 'creds')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso-message', 'creds')); ?>"
												   value="<?php echo $this->core->number($prefs['delete_peepso-message']['creds']); ?>" size="8" /></div>
						</li>
						<li class="empty">&nbsp;</li>
						<li>
							<label for="<?php echo $this->field_id(array('delete_peepso-message', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso-message', 'log')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso-message', 'log')); ?>"
												   value="<?php echo esc_attr($prefs['delete_peepso-message']['log']); ?>" class="long" /></div>
							<span class="description"><?php echo $this->available_template_tags(array('general')); ?></span>
						</li>
					</ol>
				<?php } ?>
				<!-- Creds for New PeepSo Comment -->
				<label for="<?php echo $this->field_id(array('new_peepso-comment', 'creds')); ?>" class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for New PeepSo Comment', 'mycred')); ?></label>
				<ol>
					<li>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso-comment', 'creds')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso-comment', 'creds')); ?>"
											   value="<?php echo $this->core->number($prefs['new_peepso-comment']['creds']); ?>" size="8" /></div>
					</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso-comment', 'limit')); ?>"><?php _e('Limit', 'mycred'); ?></label>
						<?php echo $this->hook_limit_setting($this->field_name(array('new_peepso-comment', 'limit')), $this->field_id(array('new_peepso-comment', 'limit')), $prefs['new_peepso-comment']['limit']);
						?>
					</li>
					<li class="empty">&nbsp;</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso-comment', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso-comment', 'log')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso-comment', 'log')); ?>"
											   value="<?php echo esc_attr($prefs['new_peepso-comment']['log']); ?>" class="long" /></div>
						<span class="description"><?php echo $this->available_template_tags(array('general', 'post')); ?></span>
					</li>
					<?php if (0) { ?>
						<li class="empty">&nbsp;</li>
						<li>
							<input type="checkbox" name="<?php echo $this->field_name(array('new_peepso-comment' => 'author')); ?>"
								   id="<?php echo $this->field_id(array('new_peepso-comment' => 'author')); ?>" <?php checked($prefs['new_peepso-comment']['author'], 1); ?> value="1" />
							<label for="<?php echo $this->field_id(array('new_peepso-comment' => 'author')); ?>"><?php echo $this->core->template_tags_general(__('PeepSo Message authors can receive %_plural% for replying to their own Message', 'mycred')); ?></label>
						</li>
					<?php } ?>
				</ol>
				<?php if (1) { ?>
					<!-- Creds for Deleting Comment -->
					<label for="<?php echo $this->field_id(array('delete_peepso-comment', 'creds')); ?>" class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for Comment Deletion', 'mycred')); ?></label>
					<ol>
						<li>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso-comment', 'creds')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso-comment', 'creds')); ?>"
												   value="<?php echo $this->core->number($prefs['delete_peepso-comment']['creds']); ?>" size="8" /></div>
						</li>
						<li class="empty">&nbsp;</li>
						<li>
							<label for="<?php echo $this->field_id(array('delete_peepso-comment', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso-comment', 'log')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso-comment', 'log')); ?>"
												   value="<?php echo esc_attr($prefs['delete_peepso-comment']['log']); ?>" class="long" /></div>
							<span class="description"><?php echo $this->available_template_tags(array('general')); ?></span>
						</li>
					</ol>
				<?php } ?>


				<!-- Creds for Add New PeepSo Freind -->
				<label for="<?php echo $this->field_id(array('add_peepso_friend', 'creds')); ?>"
					   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for Add New PeepSo Friend', 'mycred')); ?></label>
				<ol>
					<li>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('add_peepso_friend', 'creds')); ?>"
											   id="<?php echo $this->field_id(array('add_peepso_friend', 'creds')); ?>"
											   value="<?php echo $this->core->number($prefs['add_peepso_friend']['creds']); ?>" size="8" /></div>
					</li>
					<li>
						<label for="<?php echo $this->field_id(array('add_peepso_friend', 'limit')); ?>"><?php _e('Limit', 'mycred'); ?></label>
						<?php echo $this->hook_limit_setting($this->field_name(array('add_peepso_friend', 'limit')), $this->field_id(array('add_peepso_friend', 'limit')), $prefs['add_peepso_friend']['limit']);
						?>
					</li>
					<li class="empty">&nbsp;</li>
					<li>
						<label for="<?php echo $this->field_id(array('add_peepso_friend', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('add_peepso_friend', 'log')); ?>"
											   id="<?php echo $this->field_id(array('add_peepso_friend', 'log')); ?>" value="<?php echo esc_attr($prefs['add_peepso_friend']['log']); ?>"
											   class="long" /></div>
						<span class="description"><?php echo $this->available_template_tags(array('general', 'post')); ?></span>
					</li>
				</ol>
				<?php if (1) { ?>
					<!-- Creds for Deleting PeepSo Firend -->
					<label for="<?php echo $this->field_id(array('delete_peepso_friend', 'creds')); ?>"
						   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for PeepSo Friend Deletion', 'mycred')); ?></label>
					<ol>
						<li>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso_friend', 'creds')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso_friend', 'creds')); ?>"
												   value="<?php echo $this->core->number($prefs['delete_peepso_friend']['creds']); ?>" size="8" /></div>
						</li>
						<li class="empty">&nbsp;</li>
						<li>
							<label for="<?php echo $this->field_id(array('delete_peepso_friend', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso_friend', 'log')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso_friend', 'log')); ?>" value="<?php echo esc_attr($prefs['delete_peepso_friend']['log']); ?>"
												   class="long" /></div>
							<span class="description"><?php echo $this->available_template_tags(array('general')); ?></span>
						</li>
					</ol>
				<?php } ?>

				<!-- Creds for Add New PeepSo Stream Photo -->
				<label for="<?php echo $this->field_id(array('new_peepso_stream_photo', 'creds')); ?>"
					   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for Add New PeepSo Stream Photo', 'mycred')); ?></label>
				<ol>
					<li>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso_stream_photo', 'creds')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso_stream_photo', 'creds')); ?>"
											   value="<?php echo $this->core->number($prefs['new_peepso_stream_photo']['creds']); ?>" size="8" /></div>
					</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso_stream_photo', 'limit')); ?>"><?php _e('Limit', 'mycred'); ?></label>
						<?php echo $this->hook_limit_setting($this->field_name(array('new_peepso_stream_photo', 'limit')), $this->field_id(array('new_peepso_stream_photo', 'limit')), $prefs['new_peepso_stream_photo']['limit']);
						?>
					</li>
					<li class="empty">&nbsp;</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso_stream_photo', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso_stream_photo', 'log')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso_stream_photo', 'log')); ?>" value="<?php echo esc_attr($prefs['new_peepso_stream_photo']['log']); ?>"
											   class="long" /></div>
						<span class="description"><?php echo $this->available_template_tags(array('general', 'post')); ?></span>
					</li>
				</ol>
				<?php if (1) { ?>
					<!-- Creds for Deleting PeepSo Stream Photo -->
					<label for="<?php echo $this->field_id(array('delete_peepso_stream_photo', 'creds')); ?>"
						   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for deleting PeepSo Stream Photo', 'mycred')); ?></label>
					<ol>
						<li>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso_stream_photo', 'creds')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso_stream_photo', 'creds')); ?>"
												   value="<?php echo $this->core->number($prefs['delete_peepso_stream_photo']['creds']); ?>" size="8" /></div>
						</li>
						<li class="empty">&nbsp;</li>
						<li>
							<label for="<?php echo $this->field_id(array('delete_peepso_stream_photo', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso_stream_photo', 'log')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso_stream_photo', 'log')); ?>" value="<?php echo esc_attr($prefs['delete_peepso_stream_photo']['log']); ?>"
												   class="long" /></div>
							<span class="description"><?php echo $this->available_template_tags(array('general')); ?></span>
						</li>
					</ol>
				<?php } ?>

				<!-- Creds for Add New PeepSo Profile Cover -->
				<label for="<?php echo $this->field_id(array('new_peepso_profile_cover', 'creds')); ?>"
					   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for Add New PeepSo Profile Cover', 'mycred')); ?></label>
				<ol>
					<li>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso_profile_cover', 'creds')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso_profile_cover', 'creds')); ?>"
											   value="<?php echo $this->core->number($prefs['new_peepso_profile_cover']['creds']); ?>" size="8" /></div>
					</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso_profile_cover', 'limit')); ?>"><?php _e('Limit', 'mycred'); ?></label>
						<?php echo $this->hook_limit_setting($this->field_name(array('new_peepso_profile_cover', 'limit')), $this->field_id(array('new_peepso_profile_cover', 'limit')), $prefs['new_peepso_profile_cover']['limit']);
						?>
					</li>
					<li class="empty">&nbsp;</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso_profile_cover', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso_profile_cover', 'log')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso_profile_cover', 'log')); ?>" value="<?php echo esc_attr($prefs['new_peepso_profile_cover']['log']); ?>"
											   class="long" /></div>
						<span class="description"><?php echo $this->available_template_tags(array('general', 'post')); ?></span>
					</li>
				</ol>
				<?php if (1) { ?>
					<!-- Creds for Deleting PeepSo Profile Cover -->
					<label for="<?php echo $this->field_id(array('delete_peepso_profile_cover', 'creds')); ?>"
						   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for deleting PeepSo Profile Cover', 'mycred')); ?></label>
					<ol>
						<li>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso_profile_cover', 'creds')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso_profile_cover', 'creds')); ?>"
												   value="<?php echo $this->core->number($prefs['delete_peepso_profile_cover']['creds']); ?>" size="8" /></div>
						</li>
						<li class="empty">&nbsp;</li>
						<li>
							<label for="<?php echo $this->field_id(array('delete_peepso_profile_cover', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso_profile_cover', 'log')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso_profile_cover', 'log')); ?>" value="<?php echo esc_attr($prefs['delete_peepso_profile_cover']['log']); ?>"
												   class="long" /></div>
							<span class="description"><?php echo $this->available_template_tags(array('general')); ?></span>
						</li>
					</ol>
				<?php } ?>

				<!-- Creds for Add New PeepSo Profile Avatar -->
				<label for="<?php echo $this->field_id(array('new_peepso_profile_avatar', 'creds')); ?>"
					   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for Add New PeepSo Profile Avatar', 'mycred')); ?></label>
				<ol>
					<li>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso_profile_avatar', 'creds')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso_profile_avatar', 'creds')); ?>"
											   value="<?php echo $this->core->number($prefs['new_peepso_profile_avatar']['creds']); ?>" size="8" /></div>
					</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso_profile_avatar', 'limit')); ?>"><?php _e('Limit', 'mycred'); ?></label>
						<?php echo $this->hook_limit_setting($this->field_name(array('new_peepso_profile_avatar', 'limit')), $this->field_id(array('new_peepso_profile_avatar', 'limit')), $prefs['new_peepso_profile_avatar']['limit']);
						?>
					</li>
					<li class="empty">&nbsp;</li>
					<li>
						<label for="<?php echo $this->field_id(array('new_peepso_profile_avatar', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
						<div class="h2"><input type="text" name="<?php echo $this->field_name(array('new_peepso_profile_avatar', 'log')); ?>"
											   id="<?php echo $this->field_id(array('new_peepso_profile_avatar', 'log')); ?>" value="<?php echo esc_attr($prefs['new_peepso_profile_avatar']['log']); ?>"
											   class="long" /></div>
						<span class="description"><?php echo $this->available_template_tags(array('general', 'post')); ?></span>
					</li>
				</ol>
				<?php if (1) { ?>
					<!-- Creds for Deleting PeepSo Profile Avatat -->
					<label for="<?php echo $this->field_id(array('delete_peepso_profile_avatar', 'creds')); ?>"
						   class="subheader"><?php echo $this->core->template_tags_general(__('%plural% for deleting PeepSo Profile Avatar', 'mycred')); ?></label>
					<ol>
						<li>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso_profile_avatar', 'creds')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso_profile_avatar', 'creds')); ?>"
												   value="<?php echo $this->core->number($prefs['delete_peepso_profile_avatar']['creds']); ?>" size="8" /></div>
						</li>
						<li class="empty">&nbsp;</li>
						<li>
							<label for="<?php echo $this->field_id(array('delete_peepso_profile_avatar', 'log')); ?>"><?php _e('Log template', 'mycred'); ?></label>
							<div class="h2"><input type="text" name="<?php echo $this->field_name(array('delete_peepso_profile_avatar', 'log')); ?>"
												   id="<?php echo $this->field_id(array('delete_peepso_profile_avatar', 'log')); ?>" value="<?php echo esc_attr($prefs['delete_peepso_profile_avatar']['log']); ?>"
												   class="long" /></div>
							<span class="description"><?php echo $this->available_template_tags(array('general')); ?></span>
						</li>
					</ol>
				<?php } ?>

				<?php
			}

			function sanitise_preferences($data) {

				//print '<pre>';
				//print_r($data);
				//print '</pre>';
				//exit;

				if (isset($data['new_peepso-post']['limit']) && isset($data['new_peepso-post']['limit_by'])) {
					$limit = sanitize_text_field($data['new_peepso-post']['limit']);
					if ($limit == '')
						$limit = 0;
					$data['new_peepso-post']['limit'] = $limit . '/' . $data['new_peepso-post']['limit_by'];
					unset($data['new_peepso-post']['limit_by']);
				}

				if (isset($data['new_peepso-message']['limit']) && isset($data['new_peepso-message']['limit_by'])) {
					$limit = sanitize_text_field($data['new_peepso-message']['limit']);
					if ($limit == '')
						$limit = 0;
					$data['new_peepso-message']['limit'] = $limit . '/' . $data['new_peepso-message']['limit_by'];
					unset($data['new_peepso-message']['limit_by']);
				}

				if (isset($data['new_peepso-comment']['limit']) && isset($data['new_peepso-comment']['limit_by'])) {
					$limit = sanitize_text_field($data['new_peepso-comment']['limit']);
					if ($limit == '')
						$limit = 0;
					$data['new_peepso-comment']['limit'] = $limit . '/' . $data['new_peepso-comment']['limit_by'];
					unset($data['new_peepso-comment']['limit_by']);
				}

				if (isset($data['add_peepso_friend']['limit']) && isset($data['add_peepso_friend']['limit_by'])) {
					$limit = sanitize_text_field($data['add_peepso_friend']['limit']);
					if ($limit == '')
						$limit = 0;
					$data['add_peepso_friend']['limit'] = $limit . '/' . $data['add_peepso_friend']['limit_by'];
					unset($data['add_peepso_friend']['limit_by']);
				}

				//
				// Photos
				//
				if (isset($data['new_peepso_stream_photo']['limit']) && isset($data['new_peepso_stream_photo']['limit_by'])) {
					$limit = sanitize_text_field($data['new_peepso_stream_photo']['limit']);
					if ($limit == '')
						$limit = 0;
					$data['new_peepso_stream_photo']['limit'] = $limit . '/' . $data['new_peepso_stream_photo']['limit_by'];
					unset($data['new_peepso_stream_photo']['limit_by']);
				}

				if (isset($data['new_peepso_profile_cover']['limit']) && isset($data['new_peepso_profile_cover']['limit_by'])) {
					$limit = sanitize_text_field($data['new_peepso_profile_cover']['limit']);
					if ($limit == '')
						$limit = 0;
					$data['new_peepso_profile_cover']['limit'] = $limit . '/' . $data['new_peepso_profile_cover']['limit_by'];
					unset($data['new_peepso_profile_cover']['limit_by']);
				}
				if (isset($data['new_peepso_profile_avatar']['limit']) && isset($data['new_peepso_profile_avatar']['limit_by'])) {
					$limit = sanitize_text_field($data['new_peepso_profile_avatar']['limit']);
					if ($limit == '')
						$limit = 0;
					$data['new_peepso_profile_avatar']['limit'] = $limit . '/' . $data['new_peepso_profile_avatar']['limit_by'];
					unset($data['new_peepso_profile_avatar']['limit_by']);
				}

				return $data;
			}

		}

	endif;
}

function init() {
	if (is_admin()) {
		require_once dirname(__FILE__) . '/configsectionmycred.php';

		add_filter('peepso_admin_config_tabs', function($tabs){
            $tabs['mycred'] = array(
                'label' => __('myCRED', 'peepsocreds'),
                'title' => __('myCRED', 'peepsocreds'),
                'tab' => 'mycred',
                'icon' => myCRED_Hook_PeepSo    ::ICON,
                'description' => __('myCRED', 'peepsocreds'),
                'function' => 'PeepSoConfigSectionMyCred',
                'cat'   => 'integrations',
            );

            return $tabs;
        }, 90);
	} else {
		// license checking
		if (!PeepSoLicense::check_license(myCRED_Hook_PeepSo::PLUGIN_EDD, myCRED_Hook_PeepSo::PLUGIN_SLUG)) {
			return;
		}

		if (PeepSo::get_option('mycred_enabled', 1) === 1) {
			add_filter('peepso_user_activities_links', function($act_links){
                $url = PeepSoUrlSegments::get_instance();

                if ($url->get(1)) {
                    $user = get_user_by('slug', $url->get(1));

                    if (FALSE === $user) {
                        $user_id = get_current_user_id();
                    } else {
                        $user_id = $user->ID;
                    }
                } else {
                    $user_id = get_current_user_id();
                }

                $account = mycred_get_account($user_id);

                $a['mycred'] = array(
                    'label' => __('Points', 'peepsocreds'),
                    'title' => __('User Points', 'peepsocreds'),
                    'icon' => 'certificate',
                    'count' => isset($account->balance['mycred_default']->current) ? $account->balance['mycred_default']->current : 0,
                    'all_values' => TRUE,
                    'order' => 35
                );

                $act_links = array_merge($a, $act_links);
                return $act_links;
            });
		}
	}

	add_filter('mycred_ranking_row', function($layout, $template, $user, $position) {

        $layout = str_replace('/author/', '/' . PeepSo::get_option('page_profile', 'profile') . '/?', $layout);

        return $layout;
    }, 10, 4);
}

/**
 * Hooks into PeepSo for compatibility checks
 * @param $plugins
 * @return mixed
 */
add_filter('peepso_all_plugins', function($plugins){
    $plugins[plugin_basename(__FILE__)] = 'myCRED_Hook_PeepSo';
    return $plugins;
});


if(is_admin()) {
	add_action('admin_init', 'peepso_check');
	add_action('admin_init', 'mycred_check');

	// licensing
	add_action('peepso_config_before_save-site', function(){
        PeepSoLicense::delete_transient(myCRED_Hook_PeepSo::PLUGIN_SLUG);
    });
	add_filter('peepso_license_config', function($list){
        $list[] = array(
            'plugin_slug' => myCRED_Hook_PeepSo::PLUGIN_SLUG,
            'plugin_name' => myCRED_Hook_PeepSo::PLUGIN_NAME,
            'plugin_edd' => myCRED_Hook_PeepSo::PLUGIN_EDD,
            'plugin_version' => myCRED_Hook_PeepSo::PLUGIN_VERSION
        );

        return ($list);
    }, 160);
}

/**
 * Check if MyCred is available
 *
 * @since  1.8.0
 * @return bool True if myCred is available, false otherwise
 */
function mycred_check() {
	if(!function_exists('deactivate_plugins')) {
		require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
	}

    if (!class_exists('myCRED_Core') || !get_option('mycred_setup_completed')) {

        add_action('admin_notices', function() {?>
            <div class="error peepso">
                <strong>
                    <?php
                    if(!class_exists('myCRED_Core')) {
                        echo __('Please make sure myCred is installed and activated.', 'peepsocreds'),
                        ' <a href="plugin-install.php?tab=plugin-information&amp;plugin=mycred&amp;TB_iframe=true&amp;width=772&amp;height=291" class="thickbox">',
                        __('Get it now!', 'peepsocreds'),
                        '</a>';
                    }

                    if(!get_option('mycred_setup_completed')) {
                         echo __('Please make sure myCred has been set up.', 'peepsocreds');
                    }
                    ?>
                </strong>
            </div>
        <?php });

        unset($_GET['activate']);
        deactivate_plugins(plugin_basename(__FILE__));

        return (FALSE);
    }

    return (TRUE);
}

/**
 * Check if PeepSo class is present (ie the PeepSo plugin is installed and activated)
 * If there is no PeepSo, immediately disable the plugin and display a warning
 * Run license and new version checks against PeepSo.com
 * @return bool
 */
function peepso_check()
{
    if(!function_exists('deactivate_plugins')) {
        require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
    }

    if (!class_exists('PeepSo')) {
        add_action('admin_notices', function() {?>
            <div class="error peepso">
                <strong>
                    <?php
                    echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'peepsocreds'), myCRED_Hook_PeepSo::PLUGIN_NAME),
                    ' <a href="plugin-install.php?tab=plugin-information&amp;plugin=peepso-core&amp;TB_iframe=true&amp;width=772&amp;height=291" class="thickbox">',
                    __('Get it now!', 'peepso-giphy'),
                    '</a>';
                    ?>
                </strong>
            </div>
            <?php
        });
        unset($_GET['activate']);
        deactivate_plugins(plugin_basename(__FILE__));
        return (FALSE);
    }

    // PeepSo.com license check
    if (!PeepSoLicense::check_license(myCRED_Hook_PeepSo::PLUGIN_EDD, myCRED_Hook_PeepSo::PLUGIN_SLUG)) {
         add_action('admin_notices', function(){
             PeepSo::license_notice(myCRED_Hook_PeepSo::PLUGIN_NAME, myCRED_Hook_PeepSo::PLUGIN_SLUG);
         });
    }

    if (isset($_GET['page']) && 'peepso_config' == $_GET['page'] && !isset($_GET['tab'])) {
         add_action('admin_notices', function(){
             PeepSo::license_notice(myCRED_Hook_PeepSo::PLUGIN_NAME, myCRED_Hook_PeepSo::PLUGIN_SLUG, true);
         });
    }

    PeepSoLicense::check_updates_new(myCRED_Hook_PeepSo::PLUGIN_EDD, myCRED_Hook_PeepSo::PLUGIN_SLUG, myCRED_Hook_PeepSo::PLUGIN_VERSION, __FILE__);

    return (TRUE);
}