<!--<div class="ps-stream ps-stream--advads">-->

	<?php echo $content; ?>

<!--</div>-->
