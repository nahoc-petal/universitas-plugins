jQuery(function( $ ) {
	var template = peepso.template( peepsovipdata.template ),
		cache = {},
		$popover, timer;

	function getData( user_id ) {
		return $.Deferred(function( defer ) {
			if ( cache[ user_id ] ) {
				defer.resolve( cache[ user_id ] );
			} else {
				$.get({
					url: peepsodata.ajaxurl,
					dataType: 'json',
					data: {
						action: 'peepso_vip_user_icons',
						user_id: user_id
					}
				}).done(function( json ) {
					cache[ user_id ] = json;
					defer.resolve( cache[ user_id ] );
				});
			}
		});
	}

	function show( e ) {
		var $el = $( e.target ),
			user_id = $el.data( 'id' );

		// Remove title attribute.
		$el.removeAttr( 'title' );

		clearTimeout( timer );
		timer = setTimeout(function() {
			if ( ! $popover ) {
				$popover = $( '<div />' );
				$popover.addClass('ps-vip-dropdown__wrapper');
				$popover.css({ display: 'none', position: 'absolute' });
				$popover.appendTo( document.body );
			}

			getData( user_id ).done(function( data ) {
				var html = template( data ),
					offset = $el.offset();

				$popover.html( html ).show().css({
					left: offset.left + $el.width(),
					top: offset.top
				});
			});
		}, 500 );
	}

	function hide() {
		clearTimeout( timer );
		if ( $popover ) {
			$popover.hide();
		}
	}

	$( document )
		.on( 'mouseenter', '.ps-js-vip-badge', show )
		.on( 'mouseleave', '.ps-js-vip-badge', hide );

});
