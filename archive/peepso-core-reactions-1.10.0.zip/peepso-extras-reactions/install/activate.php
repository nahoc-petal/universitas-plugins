<?php
require_once(PeepSo::get_plugin_dir() . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'install.php');

class PeepSoReactionsInstall extends PeepSoInstall
{
	public function plugin_activation( $is_core = FALSE)
	{
		// Set some default settings
		#$settings = PeepSoConfigSettings::get_instance();
		#$settings->set_option('peepso_reactions_use_custom_message', 0);

		parent::plugin_activation();

		$defaults = array(

			0 => array(
				'post_title' 		=> __('Like','peepsoreactions'),
				'post_content' 		=> __('liked','peepsoreactions'),
				'post_excerpt'		=> 'like_blue.svg',
				'post_status'		=> 'publish',
			),

			1 => array(
				'post_title'		=> __('Love','peepsoreactions'),
				'post_content'		=> __('loved','peepsoreactions'),
				'post_excerpt'		=> 'heart_2764.svg',
				'post_status'		=> 'publish',

			),

			2 => array(
				'post_title'		=> __('Haha','peepsoreactions'),
				'post_content'		=> __('laughed at','peepsoreactions'),
				'post_excerpt'		=> 'face_1f606.svg',
				'post_status'		=> 'publish',

			),

			3 => array(
				'post_title'		=> __('Wink','peepsoreactions'),
				'post_content'		=> __('winked at','peepsoreactions'),
				'post_excerpt'		=> 'face_1f609.svg',
				'post_status'		=> 'publish',
			),

			4 => array(
				'post_title'		=> __('Wow','peepsoreactions'),
				'post_content'		=> __('gasped at','peepsoreactions'),
				'post_excerpt'		=> 'face_1f62e.svg',
				'post_status'		=> 'publish',
			),

			5 => array(
				'post_title'		=> __('Sad','peepsoreactions'),
				'post_content'		=> __('is sad about','peepsoreactions'),
				'post_excerpt'		=> 'face_1f62d.svg',
				'post_status'		=> 'publish',
			),

			6 => array(
				'post_title'		=> __('Angry','peepsoreactions'),
				'post_content'		=> __('is angry about','peepsoreactions'),
				'post_excerpt'		=> 'face_1f620.svg',
				'post_status'		=> 'publish',
			),

			// Since 2.0.0
			7 => array(
				'post_title'		=> __('Crazy','peepsoreactions'),
				'post_content'		=> __('feels crazy about','peepsoreactions'),
				'post_excerpt'		=> 'face_1f60b.svg',
				'post_status'		=> 'publish',
			),

			8 => array(
				'post_title'		=> __('Speechless','peepsoreactions'),
				'post_content'		=> __('is speechless about','peepsoreactions'),
				'post_excerpt'		=> 'face_1f636.svg',
				'post_status'		=> 'publish',
			),

			9 => array(
				'post_title'		=> __('Grateful','peepsoreactions'),
				'post_content'		=> __('is grateful for','peepsoreactions'),
				'post_excerpt'		=> 'rest_1f64f.svg',
				'post_status'		=> 'publish',
			),

			10 => array(
				'post_title'		=> __('Celebrate','peepsoreactions'),
				'post_content'		=> __('celebrates','peepsoreactions'),
				'post_excerpt'		=> 'occa_1f389.svg',
				'post_status'		=> 'publish',
			),
		);

		$default_args = array(
			'post_type' => 'peepso_reaction',
		);



		$order = 0;

		foreach($defaults as $id=>$args) {

			$search = array_merge($default_args,array('post_parent' => $id));

			$posts = new WP_Query($search);

			if(!count($posts->posts)) {
				$args = array_merge($args, $search);
				$args['menu_order'] = $order;
				$order += 1;
				wp_insert_post($args);
			}
		}

		return (TRUE);
	}

	// optional DB table creation
	public static function get_table_data()
	{
		$aRet = array(
			'reactions' => "
				CREATE TABLE `reactions` (
					`reaction_id` int(11) unsigned NOT NULL AUTO_INCREMENT,
					  `reaction_user_id` bigint(20) unsigned NOT NULL,
					  `reaction_act_id` bigint(20) unsigned NOT NULL,
					  `reaction_type` bigint(20) unsigned NOT NULL DEFAULT '1',
					  `reaction_timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
					  PRIMARY KEY (`reaction_id`),
					  UNIQUE KEY `module` (`reaction_user_id`,`reaction_act_id`),
					  KEY `external` (`reaction_act_id`),
					  KEY `user` (`reaction_user_id`)
				) ENGINE=InnoDB",
		);

		return $aRet;
	}
}