<?php

class PeepSoAdminReactions
{
	public static function administration()
	{
		self::enqueue_scripts();

		$PeepSoReactionsModel = new PeepSoReactionsModel();

		PeepSoTemplate::exec_template('reactions','admin_reactions', $PeepSoReactionsModel->reactions);
	}

	public static function enqueue_scripts()
	{
		wp_register_script('bootstrap', PeepSo::get_asset('aceadmin/js/bootstrap.min.js'),
			array('jquery'), PeepSo::PLUGIN_VERSION, TRUE);
		wp_register_script('peepso-admin-reactions', plugin_dir_url(dirname(__FILE__)) . 'assets/js/admin.js',
			array('jquery', 'jquery-ui-sortable', 'underscore', 'peepso'), PeepSo::PLUGIN_VERSION, TRUE);

		wp_register_script('peepso-admin-reactions', PeepSo::get_asset('js/admin-profiles.min.js'),
			array('jquery', 'jquery-ui-sortable', 'underscore', 'peepso'), PeepSo::PLUGIN_VERSION, TRUE);

		wp_enqueue_script('bootstrap');
		wp_enqueue_script('peepso-admin-reactions');

		wp_enqueue_style('peepso-reactions-admin', plugin_dir_url(dirname(__FILE__)) . 'assets/css/admin.css');
	}
}