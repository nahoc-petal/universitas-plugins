<?php
/**
 * Plugin Name: PeepSo Core: Reactions
 * Plugin URI: https://peepso.com
 * Description: Say more than a thousand likes
 * Author: PeepSo
 * Author URI: https://peepso.com
 * Version: 1.10.0
 * Copyright: (c) 2016 PeepSo, Inc. All Rights Reserved.
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: peepsoreactions
 * Domain Path: /languages
 *
 * We are Open Source. You can redistribute and/or modify this software under the terms of the GNU General Public License (version 2 or later)
 * as published by the Free Software Foundation. See the GNU General Public License or the LICENSE file for more details.
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.
 */

class PeepSoReactions2
{
    private static $_instance = NULL;

    public $model;

    const PLUGIN_NAME	 = 'Core: Reactions';
    const PLUGIN_SLUG 	 = 'reactions2';
    const PLUGIN_EDD 	 = 72278;
    const PLUGIN_VERSION = '1.10.0';
    const PLUGIN_RELEASE = ''; //ALPHA1, BETA1, RC1, '' for STABLE

    private function __construct()
    {
        add_action('peepso_init', array(&$this, 'init'));
        add_action('plugins_loaded', array(&$this, 'load_textdomain'));

        add_filter('peepso_all_plugins', function($plugins) {
            $plugins[plugin_basename(__FILE__)] = get_class($this);
            return $plugins;
        });

        if (is_admin()) {
            add_action('admin_init', array(&$this, 'peepso_check'));
            add_filter('peepso_license_config', function($list){
                $list[] = array(
                    'plugin_slug' => self::PLUGIN_SLUG,
                    'plugin_name' => self::PLUGIN_NAME,
                    'plugin_edd' => self::PLUGIN_EDD,
                    'plugin_version' => self::PLUGIN_VERSION
                );
                return ($list);
            }, 666);
            add_action('peepso_config_before_save-site', function() {
                PeepSoLicense::delete_transient(self::PLUGIN_SLUG);
            });
        }

        register_activation_hook(__FILE__, array(&$this, 'activate'));
    }

    /**
     * Singleton instance
     * @return null|PeepSoReactions2
     */
    public static function get_instance()
    {
        if (NULL === self::$_instance) {
            self::$_instance = new self();
        }
        return (self::$_instance);
    }

    /**
     * Init hooks
     */
    public function init()
    {
        // Run activatuon in case of version number change
        if( $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE != get_transient($trans = 'peepso_'.$this::PLUGIN_SLUG.'_version')) {
            // activate returns false in case of missing license
            if($this->activate()) {
                set_transient($trans, $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE);
            }
        }

        // Autoload
        PeepSo::add_autoload_directory(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR);
        PeepSoTemplate::add_template_directory(plugin_dir_path(__FILE__));

        // Hooks
        if (is_admin()) {

            // Admin hooks
            add_action('admin_enqueue_scripts', array(&$this, 'enqueue_scripts'));
            add_action('admin_init', array(&$this, 'peepso_check'));
            add_filter('peepso_admin_dashboard_tabs', function($tabs){
                $tabs['red']['reactions'] = array(
                    'slug' => 'peepso-reactions',
                    'menu' => __('Reactions', 'peepsoreactions'),
                    'icon' => 'id-alt',
                    'count' => '',
                    'function' => array('PeepSoAdminReactions', 'administration'),
                );
                return $tabs;
            });

        } else {

            // Check license
            if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
                return false;
            }

            // Front-end hooks
            add_action('wp_enqueue_scripts', array(&$this, 'enqueue_scripts'));
            add_filter('peepso_post_before_comments', array(&$this, 'action_peepso_post_before_comments'));
            add_filter('peepso_modal_before_comments', array(&$this, 'action_peepso_post_before_comments'));
            add_action('peepso_activity_post_actions', array(&$this, 'filter_peepso_activity_post_actions'), 1);
        }
    }

    /**
     * Init the model when needed
     */
    public function init_model()
    {
        // Global model instance
        if(!$this->model instanceof PeepSoReactionsModel) {
            $this->model = new PeepSoReactionsModel();
        }

        return $this->model;
    }

    /**
     * Load translations
     * @return void
     */
    public function load_textdomain()
    {
        $path = str_ireplace(WP_PLUGIN_DIR, '', dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'languages' . DIRECTORY_SEPARATOR;
        load_plugin_textdomain('peepsoreactions', FALSE, $path);
    }

    /**
     * Load scripts and styles
     */
    public function enqueue_scripts()
    {
        $min = '.min';
        //$min = ''; // dev mode - don't load minified assets

        wp_enqueue_script('peepsoreactions', plugin_dir_url(__FILE__) . 'assets/js/reactions'.$min.'.js', array('peepso'), self::PLUGIN_VERSION, TRUE);

        $data = array(
            'ajaxloader' => PeepSo::get_asset('images/ajax-loader.gif'),
        );

        wp_localize_script('peepsoreactions', 'peepsoreactionsdata', $data);

        // dynamic CSS
        $css = 'plugins'.DIRECTORY_SEPARATOR.'reactions'.DIRECTORY_SEPARATOR.'reactions-'.get_transient('peepso_reactions_css').'.css';
        if(!file_exists(PeepSo::get_peepso_dir().$css)) {
            $this->rebuild_cache();
        }
		$css_url = 'plugins/reactions/reactions-'.get_transient('peepso_reactions_css').'.css';

        wp_enqueue_style('peepsoreactions-dynamic', PeepSo::get_peepso_uri().$css_url, array(), self::PLUGIN_VERSION, 'all');
    }

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * PEEPSO CONFIG, PEEPSO COMPATIBILITY, PLUGIN ACTIVATION */

    /**
     * Plugin activation
     * Check PeepSo
     * @return bool
     */
    public function activate()
    {
        if (!$this->peepso_check()) {
            return ( FALSE );
        }

        require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'activate.php');
        $install = new PeepSoReactionsInstall();
        $res = $install->plugin_activation();
        if (FALSE === $res) {
            deactivate_plugins(plugin_basename(__FILE__));
            return( FALSE );
        }

        return ( TRUE );
    }

    /**
     * Check if PeepSo class is present (ie the PeepSo plugin is installed and activated)
     * If there is no PeepSo, immediately disable the plugin and display a warning
     * @return bool
     */
    public function peepso_check()
    {
        if (!class_exists('PeepSo')) {
            add_action('admin_notices', array(&$this, 'peepso_disabled_notice'));
            unset($_GET['activate']);
            deactivate_plugins(plugin_basename(__FILE__));
            return (FALSE);
        }

        // Disable self in case old Reactions plugin is around
        if(class_exists('PeepSoReactions')) {
            deactivate_plugins(plugin_basename(__FILE__));
        }

        // PeepSo.com license check
        if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
            add_action('admin_notices', function () {
                PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG);
            });
        }

        if (isset($_GET['page']) && 'peepso_config' == $_GET['page'] && !isset($_GET['tab'])) {
            add_action('admin_notices', function () {
                PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG, true);
            });
        }


        PeepSoLicense::check_updates_new(self::PLUGIN_EDD, self::PLUGIN_SLUG, self::PLUGIN_VERSION, __FILE__);

        return (TRUE);
    }

    /**
     * Display a message about PeepSo not present
     */
    public function peepso_disabled_notice()
    {
        ?>
        <div class="error peepso">
            <strong>
                <?php echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'peepsoreactions'), self::PLUGIN_NAME);?>
            </strong>
        </div>
        <?php
    }

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * FRONTEND HOOKS */

    /**
     * Replace "like" in post_actions with "react" with appropriate icon & label
     * @param array $args
     * @return array
     */
    public function filter_peepso_activity_post_actions( $args )
    {
        $this->init_model();
        $this->model->init($args['post']->act_id);

        // label and class default to "like"
        $reaction = (FALSE == $this->model->my_reaction) ? $this->model->reaction(0) : $this->model->my_reaction;

        $acts = array(
            'like' => array(
                'href' => 'javascript:',
                'label' => $reaction->title,
                'class' => "ps-reaction-toggle--{$this->model->act_id} {$reaction->class} ps-js-reaction-toggle",
                'icon' => 'reaction',
                'click' => 'return reactions.action_reactions(this, ' . $this->model->act_id . ');',
                'count' => 0, // probably not important
            ),
        );

        unset($args['acts']['like']);
        $args['acts'] = array_merge($acts, $args['acts']);

        return $args;
    }

    /**
     * Inject "react" interface
     * @return void
     */
    public function action_peepso_post_before_comments()
    {
        global $post;
        $this->init_model();

        $this->model->init($post->act_id);
        echo $this->model->html_before_comments();
    }

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  CSS CACHE */
    public function rebuild_cache()
    {
        // Directory where CSS files are stored
        $path = PeepSo::get_peepso_dir().'plugins'.DIRECTORY_SEPARATOR.'reactions'.DIRECTORY_SEPARATOR;

        if (!file_exists($path) ) {
            @mkdir($path, 0755, TRUE);
        }

        // Try to remove the old file
        $old_file = $path.'reactions-'.get_transient('peepso_reactions_css').'.css';
        @unlink($old_file);

        // New cache
        delete_option('peepso_reactions_css');
        set_transient('peepso_reactions_css', time());

        $css ='';

        $this->init_model();

        foreach ($this->model->reactions as $id => $reaction) {

            $contain = '';

            if('svg' != strtolower(substr($reaction->icon_url, -3, 3))) {
                $contain = "background-size:contain;background-repeat:no-repeat;";
            }

            $css .= ".ps-reaction-emoticon-$id {background-image:url('" . $reaction->icon_url . "');$contain}";
        }

        update_option('peepso_reactions_css', $css);



        $file = $path.'reactions-'.get_transient('peepso_reactions_css').'.css';
        $h = fopen( $file, "a" );
        fputs( $h, $css );
        fclose( $h );
    }
}

PeepSoReactions2::get_instance();
// EOF
