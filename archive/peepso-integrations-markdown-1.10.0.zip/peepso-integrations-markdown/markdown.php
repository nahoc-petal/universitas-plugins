<?php
/**
 * Plugin Name: PeepSo Integrations: Markdown
 * Plugin URI: https://peepso.com
 * Description: Markdown formatting for PeepSo
 * Author: PeepSo
 * Author URI: https://peepso.com
 * Version: 1.10.0
 * Copyright: (c) 2017 PeepSo, Inc. All Rights Reserved.
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: peepsomd
 * Domain Path: /language
 *
 * We are Open Source. You can redistribute and/or modify this software under the terms of the GNU General Public License (version 2 or later)
 * as published by the Free Software Foundation. See the GNU General Public License or the LICENSE file for more details.
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.
 */

class PeepSoMarkdownPlugin
{
    private static $_instance = NULL;

    const PLUGIN_NAME	 = 'Integrations: Markdown';
    const PLUGIN_EDD     = 2676480;
    const PLUGIN_SLUG    = 'markdown';
    const PLUGIN_VERSION = '1.10.0';
    const PLUGIN_RELEASE = ''; //ALPHA1, BETA1, RC1, '' for STABLE

    private function __construct()
    {
        add_action('peepso_init', array(&$this, 'init'));
        add_action('plugins_loaded', array(&$this, 'load_textdomain'));

        if (is_admin()) {
            add_action('admin_init', array(&$this, 'peepso_check'));

            // licensing
            add_action('peepso_config_before_save-site', array(&$this, 'before_save_site'));
            add_filter('peepso_license_config', array(&$this, 'add_license_info'), 160);

        } else {
            //
        }

        add_filter('peepso_all_plugins', array($this, 'filter_all_plugins'));

        // Run our activation
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
    }

    public static function get_instance()
    {
        if (NULL === self::$_instance) {
            self::$_instance = new self();
        }
        return (self::$_instance);
    }

    public function init()
    {
        PeepSo::add_autoload_directory(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR);
        PeepSoTemplate::add_template_directory(plugin_dir_path(__FILE__));

        // Hooks: common
        // (chirp chirp chirp)

        // Hooks: backend
        if (is_admin()) {
            add_action('admin_init', array(&$this, 'peepso_check'));

            add_filter('peepso_admin_config_tabs', array(&$this, 'admin_config_tabs'));
        }

        // Hooks: frontend
        if(!is_admin()) {
            add_action('wp_enqueue_scripts', array(&$this, 'enqueue_scripts'));
        }

        // Formatting hooks, only if license valid
        if (PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {

            add_filter('peepso_activity_content_before', function ($content) {
                global $post;

                switch ($post->post_type) {

                    case 'peepso-post':
                        if (PeepSo::get_option('md_post', 0)) {
                            $content = self::do_parsedown($content);
                        }
                        break;

                    case 'peepso-comment':
                        if (PeepSo::get_option('md_comment', 0)) {
                            $content = self::do_parsedown($content);
                        }
                        break;

                    case 'peepso-message':
                        if (PeepSo::get_option('md_chat', 0)) {
                            #$content = self::do_parsedown($content);
                        }
                        break;
                }
                return $content;
            });

        }
    }

    /**
     * Activation hook for the plugin.
     *
     * @since 1.0.0
     */
    public function activate() 
    {
        if (!$this->peepso_check()) {
            return (FALSE);
        }

        require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes'. DIRECTORY_SEPARATOR .'tools' . DIRECTORY_SEPARATOR . 'activate.php');

        if (new PeepSoMarkdownInstall()) {
            return TRUE;
        }

        deactivate_plugins(plugin_basename(__FILE__));
        return FALSE;
    }

    /**
     * Called before PeepSo saves the "site" config page
     * Deletes the cached license in order to forcefully revalidate
     */
    public function before_save_site()
    {
        PeepSoLicense::delete_transient(self::PLUGIN_SLUG);
    }

    /**
     * Adds the license key information to the config metabox
     * @param array $list The list of license key config items
     * @return array The modified list of license key items
     */
    public function add_license_info($list)
    {
        $data = array(
            'plugin_slug' => self::PLUGIN_SLUG,
            'plugin_name' => self::PLUGIN_NAME,
            'plugin_edd' => self::PLUGIN_EDD,
            'plugin_version' => self::PLUGIN_VERSION
        );
        $list[] = $data;
        return ($list);
    }

    public function license_notice()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG);
    }

    public function license_notice_forced()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG, true);
    }

    /**
     * Loads the translation file for the PeepSo plugin
     */
    public function load_textdomain()
    {
        $path = str_ireplace(WP_PLUGIN_DIR, '', dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'language' . DIRECTORY_SEPARATOR;
        load_plugin_textdomain('peepsomd', FALSE, $path);
    }

    /**
     * Hooks into PeepSo for compatibility checks
     * @param $plugins
     * @return mixed
     */
    public function filter_all_plugins($plugins)
    {
        $plugins[plugin_basename(__FILE__)] = get_class($this);
        return $plugins;
    }

    /**
     * Registers a tab in the PeepSo Config Toolbar
     * PS_FILTER
     *
     * @param $tabs array
     * @return array
     */
    public function admin_config_tabs( $tabs )
    {
        $tabs['markdown'] = array(
            'label' => __('Markdown', 'peepsomd'),
            'icon' => 'https://www.peepso.com/wp-content/plugins/peepso.com-checkout/assets/icons/'.self::PLUGIN_EDD.'.svg',
            'tab' => 'markdown',
            'description' => __('Markdown', 'peepsomd'),
            'function' => 'PeepSoConfigSectionMarkdown',
            'cat' => 'extras',
        );

        return $tabs;
    }

    public static function do_parsedown($content) {

        $content = str_replace(array('<p>','</p>'), "\n", $content);

        require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'thirdparty' . DIRECTORY_SEPARATOR . 'parsedown' . DIRECTORY_SEPARATOR . 'Parsedown.php');
        $content =  Parsedown::instance()->setUrlsLinked(FALSE)->setBreaksEnabled(TRUE)->text($content);

        $content = '<div class="peepso-markdown">' . html_entity_decode($content) .'</div>';

        return $content;
    }

    public function peepso_check()
    {
        if (!class_exists('PeepSo')) {
            add_action('admin_notices', function(){
                ?>
                <div class="error peepso">
                    <strong>
                        <?php echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'peepsomd'), self::PLUGIN_NAME);?>
                    </strong>
                </div>
                <?php
            });
            unset($_GET['activate']);
            deactivate_plugins(plugin_basename(__FILE__));
            return (FALSE);
        }

        // PeepSo.com license check
        if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
             add_action('admin_notices', array(&$this, 'license_notice'));
        }

        if (isset($_GET['page']) && 'peepso_config' == $_GET['page'] && !isset($_GET['tab'])) {
             add_action('admin_notices', array(&$this, 'license_notice_forced'));
        }

        // PeepSo.com new version check
        // since 1.7.6
        if(method_exists('PeepSoLicense', 'check_updates_new')) {
            PeepSoLicense::check_updates_new(self::PLUGIN_EDD, self::PLUGIN_SLUG, self::PLUGIN_VERSION, __FILE__);
        }

        return (TRUE);
    }

    public function enqueue_scripts()
    {
        // Stylesheets.
        wp_register_style('peepso-markdown-highlight', plugin_dir_url(__FILE__) . 'assets/css/highlight.min.css',
            NULL, self::PLUGIN_VERSION, 'all');
        wp_register_style('peepso-markdown', plugin_dir_url(__FILE__) . 'assets/css/markdown.css',
            array('peepso-markdown-highlight'), self::PLUGIN_VERSION, 'all');
        wp_enqueue_style('peepso-markdown');

        // Scripts.
        wp_register_script('peepso-markdown-highlight', plugin_dir_url(__FILE__) . 'assets/js/highlight.min.js',
            NULL, self::PLUGIN_VERSION, TRUE);
        wp_register_script('peepso-markdown', plugin_dir_url(__FILE__) . 'assets/js/bundle.min.js',
            array('peepso-markdown-highlight'), self::PLUGIN_VERSION, TRUE);
        wp_enqueue_script('peepso-markdown');
    }
}

PeepSoMarkdownPlugin::get_instance();

// EOF
