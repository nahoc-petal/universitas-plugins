import $ from 'jquery';
import { observer } from 'peepso';

observer.addFilter( 'peepso_activity_content', ( html ) => {
    let $wrapper = $( '<div />' );
    $wrapper.html( html );
    $wrapper.find( 'code' ).each(( i, code ) => {
        hljs.highlightBlock( code );
        if ( ! $( code ).parent( 'pre' ).length ) {
            $( code ).css( 'display', 'inline' );
        }
    });
    return $wrapper.html();
}, 10, 1 );
