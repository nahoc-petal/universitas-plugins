<?php
require_once(PeepSo::get_plugin_dir() . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'install.php');

class PeepSoMarkdownInstall extends PeepSoInstall
{

    public function __construct() {
        return $this->plugin_activation(TRUE);
    }

	// optional default settings
	protected $default_config = array();

	public function plugin_activation( $is_core = FALSE )
	{
		parent::plugin_activation($is_core);

		return (TRUE);
	}
}