<?php

class PeepSoConfigSectionWordFilter extends PeepSoConfigSectionAbstract
{
// Builds the groups array
	public function register_config_groups()
	{
		$this->context='left';
		$this->_wordfilter_general();
	}

	private function _wordfilter_general()
	{

		# General description
		$this->set_field(
			'wordfilter_general_description',
			__('Configure the use of PeepSo - WordFilter','wordfilter-peepso'),
			'message'
		);

		# Enable WordFilter
		$this->args('default', 1);
		$this->set_field(
			'wordfilter_enable',
			__('Enable WordFilter', 'wordfilter-peepso'),
			'yesno_switch'
		);

		// Keywords to remove
		$this->args('validation', array('required', 'custom'));
		$this->args('validation_options',
			array(
			'error_message' => __('Keywords cannot be empty and separated by comma.', 'wordfilter-peepso'),
			'function' => array($this, 'check_keywords')
			)
		);
		$this->set_field(
			'wordfilter_keywords',
			__('Keywords to remove', 'wordfilter-peepso'),
			'textarea'
		);

		// # Message Keywords to remove description
		$this->set_field(
			'wordfilter_keywords_description',
			__('Separate words or phrases with a comma. For example: <br> word, this is a phrase, another, more words', 'wordfilter-peepso'),
			'message'
		);

		// what to filter
		$this->args('descript', __('Posts', 'wordfilter-peepso'));
		$this->args('default', 'on');
		$this->set_field(
			'wordfilter_type_' . PeepSoActivityStream::CPT_POST,
			__('What to filter', 'wordfilter-peepso'),
			'checkbox'
		);

		$this->args('descript', __('Comments', 'wordfilter-peepso'));
		$this->args('default', 'on');
		$this->set_field(
			'wordfilter_type_' . PeepSoActivityStream::CPT_COMMENT,
			'',
			'checkbox'
		);

		// How to render
		$options = array(
			PeepSoWordFilterPlugin::WORDFILTER_FULL => '****',
			PeepSoWordFilterPlugin::WORDFILTER_MIDDLE => 'W**d'
		);
		$this->args('options', $options);
		$this->args('default', 'on');
		$this->set_field(
			'wordfilter_how_to_render',
			__('How to render', 'wordfilter-peepso'),
			'select'
		);

		// Filter character
		$options = array(
			'*' => '****',
			'#' => '####'
		);
		$this->args('options', $options);
		$this->set_field(
			'wordfilter_character',
			__('Filter character', 'wordfilter-peepso'),
			'select'
		);

		$general_config = apply_filters('peepso_wordfilter_general_config', array());

		if(count($general_config) > 0 ) {

			foreach ($general_config as $option) {
				if(isset($option['descript'])) {
					$this->args('descript', $option['descript']);
				}
				if(isset($option['int'])) {
					$this->args('int', $option['int']);
				}
				if(isset($option['default'])) {
					$this->args('default', $option['default']);
				}

				$this->set_field($option['name'], $option['label'], $option['type']);
			}
		}


		// Build Group
		$this->set_group(
			'general',
			__('General', 'wordfilter-peepso')
		);
	}

	/**
	 * Checks if the keywords value is valid.
	 * @param  string $value keywords to filter
	 * @return boolean
	 */
	public function check_keywords($value)
	{
		$keywords = explode(',', $value);
		$ret = TRUE;
		foreach ($keywords as $word) {
			$word = trim($word);
			if(empty($word)) {
				$ret = FALSE;
			}
		}

		return $ret;
	}
}