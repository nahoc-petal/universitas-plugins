=== PeepSo - WordFilter Plugin ===
Contributors: Septiyan, Eric
Donate link: https://peepso.com
Tags: sticker
Requires at least: 4.6
Tested up to: 4.9
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Cencorship Word for PeepSo.

== Description ==

Cencorship Word for PeepSo.


== Installation ==


1. Install and activate and configure the free [PeepSo plugin](http://wordpress.org/plugins/peepso-core/ "PeepSo") to your WordPress site.
2. Install PeepSo - WordFilter Plugin.
4. Activate the plugin through the 'Plugins' menu in WordPress
5. You're done.

== Frequently Asked Questions ==

= Where should I report issues, bugs or suggestions? =

Please do all of the above in the designated group on our site: [PeepSo Community](https://peepso.com/community/ "PeepSo Community"). Register and go to Community > Groups > PeepSo - WordFilter Plugin group.


== Changelog ==

= ALL VERSIONS =
* For changelog please go to: [Changelog](https://peepso.com/changelog/ "Changelog")
