<div class="ps-lightbox ps-lightbox-simple" style="z-index:100000"
	><div class="ps-lightbox-padding"
		><div class="ps-lightbox-wrapper"
			><div class="ps-lightbox-content"
				><div class="ps-lightbox-object"
					><div class="ps-js-img" style="display:inline-block"></div
					><div class="ps-icon-play ps-lightbox-play" style="display:none"></div
				></div
				><div class="ps-lightbox-spinner" style="display:none"></div
			></div
			><div class="ps-lightbox-close">&times;</div
		></div
	></div
></div>
