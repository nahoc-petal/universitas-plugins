<div class="ps-photos__item-wrapper">
	<div class="ps-photos__item">
		<a data-id="<?php echo $act_id; ?>" href="javascript:"
				onclick="<?php echo $onclick;?>" rel="post-<?php echo $pho_post_id;?>">
			<img class="ps-js-beforeloaded" src="<?php echo $pho_thumbs['m_s']; ?>" title="<?php echo $pho_orig_name;?>" alt="" />
			<div class="ps-photos__item-overlay">
				<span><i class="ps-icon-zoom-in"></i></span>
			</div>
		</a>
	</div>
</div>
