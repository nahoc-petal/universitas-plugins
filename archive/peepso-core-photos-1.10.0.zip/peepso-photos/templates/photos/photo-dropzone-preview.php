<li class="ps-postbox-photo-item ps-js-preview">
	<div class="img-wrapper ps-js-img"></div>
	<div class="ps-postbox-photo-action ps-js-remove" style="display:none">
		<span class="ps-postbox-photo-remove"><i class="ps-icon-remove"></i></span>
	</div>
	<div class="ps-postbox-photo-progressbar ps-js-progressbar">
		<div class="ps-postbox-photo-progress ps-js-progress"></div>
	</div>
</li>
