<i class="ps-icon-camera" style="position:relative; top:auto; right:auto;"></i>
<input class="ps-chat-window-input-uploader fileupload" type="file" name="filedata[]" accept="image/*" multiple style="display:none" />
