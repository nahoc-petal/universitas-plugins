(function( $ ) {

var $aws = $('#photos_enable_aws_s3');
var $awsId = $('#field_photos_aws_access_key_id');
var $awsKey = $('#field_photos_aws_secret_access_key');
var $awsBucket = $('#field_photos_aws_s3_bucket');

$aws.on('change', function() {
	if ( this.checked ) {
		$awsId.show();
		$awsKey.show();
		$awsBucket.show();
	} else {
		$awsId.hide();
		$awsKey.hide();
		$awsBucket.hide();
	}
}).triggerHandler('change');

})( jQuery );
