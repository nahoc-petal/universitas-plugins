module.exports = function( grunt ) {

	grunt.initConfig({

		uglify: {
			dist: {
				options: {
					report: 'none',
					sourceMap: true
				},
				files: [{
					src: [
						'assets/js/*.js',
						'!assets/js/*.min.js',
					],
					expand: true,
					ext: '.min.js'
				}]
			}
		}

	});

	grunt.loadNpmTasks( 'grunt-contrib-uglify' );

	grunt.registerTask( 'default', [ 'uglify' ]);

};
