=== Plugin Photos ===
Contributors: peepso, JaworskiMatt, rsusanto
Donate link: http://www.peepso.com
Tags: PeepSo, social network, social media, community, stream, pages, acl, activity, profile, notifications, social, networking, photos, photo
Requires at least: 4.6
Tested up to: 4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
PicSo adds the ability to post photos on the content stream—and it does it in a beautiful and organized way! Members can like and comment on the photos. Once clicked, the images are shown in a modal window where the owner or admin can edit the caption as well as delete, like or comment on them. Arrows on each side of the image let members click to see the next or previous photo for that post.

PicSo also adds photo functionalities to messages.

== Frequently Asked Questions ==

= What's the automated upgrade procedure? =

First you need to update the ChatSo plugin. Then all the other supporting plugins. PeepSo Core plugin must be updated last.

= Can I just use PicSo on my website? =

For PicSo to work, you need to have PeepSo installed and activated. PicSo is not a standalone plugin for WordPress.


== Changelog ==
= ALL VERSIONS =
* See full changelog here: [PeepSo Changelog](https://www.peepso.com/changelog/ "PeepSo Changelog")

= 1.7.0 =
* New Add location to albums.
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.7.0
* Impr Support for GroupSo plugin.
* Impr Press 'Escape' to close lightbox.
* Fix Issue with Url Segments in Divi Themes. 
* Fix After editing Album Post on activity stream there are badly escaped characters.
* Fix activity page not reloaded when upload photo using AWS.
* Fix Album descriptions not fully synced.
* Fix Show X more comments doesn't work in album view.


= 1.6.3 =
* Impr Compatibility with PeepSo 1.6.3.
* Impr Generated new .POT file.
* Impr Revamp albums - remove frame, add overlay.
* Impr Photos and albums should use 256px thumbs.
* Impr Truncate album names.
* Fix NOT album owner sees an option to delete album on activity stream post.
* Fix limit of characters in photo albums names isn't known to end user. 
* Fix Rendering of location and mood in photos modal. 

= 1.6.2 =
* New Users can create own Photo Albums
* New Add 'View full image' link under 'options' in modal window when viewing a photo.
* New Photos loading indicator on Activity Stream
* Impr Compatibility with PeepSo 1.6.2
* Impr Generated new .POT file.
* Impr Instead of square, use the actual proportions of the image used in comments.
* Impr Refactor repeated template code.
* Fix "Show X more comments" doesn't load photos in those hidden comments.
* Fix Hide post(change avatar/cover) caused error in modal.
* Fix Delete photos on stream didn’t delete thumbnails.
* Fix The add photo to comment icon is overlapping text.
* Fix Editing a post with a photo attaches same photo to all comments.

= 1.6.1 =
* Impr Compatibility with PeepSo 1.6.1
* Impr Generated new .POT file.

= 1.6.0 =
* New Latest Community Photos Widget
* New Core Photo Albums. 
* New Adding a photo to comments.
* New When viewing own photos, new options for user to set profile cover/avatar from that photo.
* New Profile covers and avatars stream posts upon user changing avatar/cover.
* Impr Styling improvements. 
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.6.0
* Impr Widgets 'yes/no' switch styling. 
* Impr Add "Hide when empty" option to Photos widget.
* Fix Styling issues in modal window.
* Fix Error notice caused by 'privacy_access_levels'.
* Fix Remove 'GET' and use 'POST' in the entire plugin. 

= 1.5.7 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.5.7

= 1.5.6 =
* Impr Compatibility with PeepSo 1.5.6
* Impr Updated Language file.

= 1.5.5 =
* Impr Compatibility with PeepSo 1.5.5
* Impr Updated Language file.
* Impr Renamed the plugin from PeepSo [X] to PeepSo Core [X] 
* Impr PNG alpha channel defaults to black upon conversion.

= 1.5.4 =
* Impr Compatibility with PeepSo 1.5.4
* Impr Updated Language file.
* Impr Hide the outline of selected elements.

= 1.5.3 =
* Impr Compatibility with PeepSo 1.5.3
* Impr Updated Language file.

= 1.5.2 =
* Impr Compatibility with PeepSo 1.5.2
* Impr Updated Language file.
* Fix Uploading photos on WP 4.4

= 1.5.1 =
* New Rearranging photos in postbox in order user wants.
* Impr Compatibility with PeepSo 1.5.1
* Impr Updated Language file.
* Impr Compatibility with ChatSo.
* Impr Navigation in modal window.

== Changelog ==
= 1.5.0 =
* Impr Compatibility with PeepSo 1.5.0
* Impr Updated Language file.
* Impr Compatibility with ChatSo.
* Impr 'view full image' link in lightbox images in messages and chat.

= 1.4.2 =
* Impr Compatibility with PeepSo 1.4.2
* Impr Updated Language file.
* Impr Removed unused /_sql/ directory.

= 1.4.1 =
* Impr Compatibility with PeepSo 1.4.1
* Impr Updated Language file.
* Impr Adjust how the photos are displayed on stream on wide themes.

= 1.4.0 =
* Impr Compatibility with PeepSo 1.4.0
* Impr Updated Language file.

= 1.3.0 =
* Impr Compatibility with PeepSo 1.3.0
* Impr Updated Language file.
* Fix Photos with public privacy not opening in modal for guests.

= 1.2.1 =
* Impr Compatibility with PeepSo 1.2.1
* Impr Updated Language file.

= 1.2.0 =
* Impr Compatibility with PeepSo 1.2.0
* Impr Updated Language file.
* Impr Layout of Photos in Messages
* Impr Postbox photo loading improvements.
* Fix Added .POT language file.

= 1.1.0 =
* Impr Compatibility with PeepSo 1.1.0
* Impr Add an overlay to show how many pictures are there more to see.
* Fix Moved the characters count in Postbox to the actual message box when photos are uploaded.

= 1.0.1 =
* Impr Compatibility with PeepSo 1.0.1

= 1.0.0 =
* Impr Compatibility with PeepSo 1.0.0
* New Uploaded images quality control settings.
* Impr Photo attachments in messages only showing up to 5 first images.
* FixCan’t edit caption for photos in a modal window.
* FixBad quality of thumbnails in postbox.
* FixA ‘cached’ version of comments, likes, edits of photos is shown in modal.

= 1.0.0 RC4 =
* Impr Compatibility with PeepSo 1.0.0 RC4
* Fix Can’t like an individual photo from a batch upload in modal.
* Fix Can’t report a picture from modal, when uploaded in a batch
* Fix Can’t repost a picture from modal, when uploaded in a batch
* Fix Sending a photo in a private message puts those photos in widgets and under profiles.
* Fix Photo attachment to messages breaks message list.
* FixPhoto thumbnails improvements and optimisation on the Activity Stream.
* FixCan’t tag people in comments in modal in photos.

= 1.0.0 RC1 =
* New Initial release of PicSo plugin.
