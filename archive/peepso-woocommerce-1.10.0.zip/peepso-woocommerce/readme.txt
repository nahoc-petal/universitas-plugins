=== Wbcom PeepSo Woo Integration ===
Contributor: wbcomdesigns
Tags: woocommerce-integration, peepso-woocommerce-integration, peepso, woocommerce
Donate link: https://wbcomdesigns.com/donate/
Requires at least: 4.6
Tested up to: 4.9
Stable tag: 1.9.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

It will help to integrate WooCommerce with PeepSo.

== Description ==
1) Admin can set activity settings and activity content.
It will also allow users to enable their WooCommerce activity.
2) Admin can enable or disable WooCommerce tabs and also add custom CSS for WooCommerce enabled tabs in PeepSo User Profile section.

If you need additional help you can contact us for [Custom Development](https://wbcomdesigns.com/contact/).


== Installation ==

1. Upload the plugin files to the '/wp-content/plugins/peepso-woocommerce' directory.
2. Activate the plugin through the \'Plugins\' screen in WordPress.


== Frequently Asked Questions ==
= Compatible PeepSo Version =
Greater than 1.8.10+
= Compatible WooCommerce Version =
Greater than 3.2.5+

== Screenshots ==

1. The screenshot shows the admin settings of Wbcom PeepSo Woo Integration plugin and corresponds to screenshot-1.
2. The screenshot shows the front-end activity settings related to WooCommerce activity and corresponds to screenshot-2.
3. The screenshot shows the WooCommerce cart in PeepSo User Profile section and corresponds to screenshot-3.
4. The screenshot shows the WooCommerce checkout in PeepSo User Profile section and corresponds to screenshot-4.
5. The screenshot shows the WooCommerce orders in PeepSo User Profile section and corresponds to screenshot-5.
6. The screenshot shows the WooCommerce addresses in PeepSo User Profile section and corresponds to screenshot-6.
7. The screenshot shows the WooCommerce account details in PeepSo User Profile section and corresponds to screenshot-7.
8. The screenshot shows the WooCommerce track order in PeepSo User Profile section and corresponds to screenshot-8.

== Changelog ==
= 1.0.0 =
Initial Release
