=== PeepSo - AutoFriends Plugin ===
Contributors: Septiyan, Eric
Donate link: https://peepso.com
Tags: friends, connections, friendso, engagement, nomination, peepso, community, badgeos
Requires at least: 4.6
Tested up to: 4.9
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/agpl-3.0.html


Adds ability to create friendship connections for PeepSo and FriendSo plugins.

== Description ==

Adds ability to create friendship connections for PeepSo and FriendSo plugins.


== Installation ==


1. Install and activate and configure the free [PeepSo plugin](http://wordpress.org/plugins/peepso-core/ "PeepSo") to your WordPress site.
2. Install and activate and configure the free [FriendSo plugin](https://peepso.com/download/friendso/ "FriendSo") to your WordPress site.
3. Install and PeepSo - AutoFriends Plugin.
4. Activate the plugin through the 'Plugins' menu in WordPress
5. You're done :)

== Frequently Asked Questions ==

= Does it create friendships with the already existing users? =

Yes, just add a user to the list and click 'Befriend All Users' button.

= Can I remove friendship connections? =

Sorry, but no. This plugin is for creating friend connections.

= Can I exclude some users from being befriended? =

Not at this time, but perhaps in the future it'll be added as a feature.

= Does it automatically create friendship connections with newly registered users? =

Yes it can do that :)

= Where should I report issues, bugs or suggestions? =

Please do all of the above in the designated group on our site: [PeepSo Community](https://peepso.com/community/ "PeepSo Community"). Register and go to Community > Groups > PeepSo - BadgeOS Integration Plugin group.


== Changelog ==

= ALL VERSIONS =
* For changelog please go to: [Changelog](https://peepso.com/changelog/ "Changelog")
