<div class="ps-members-item-options ps-js-dropdown">
	<button type="button" class="ps-btn ps-dropdown__toggle ps-js-dropdown-toggle" data-value="">
		<span class="dropdown-caret ps-icon-cog"></span>
	</button>
	<div class="ps-dropdown__menu ps-js-dropdown-menu">
		<?php echo $request_options; ?>
	</div>
</div>
