<button type="button" onclick="ps_messages.new_message(undefined, 'is_friend')" class="ps-btn ps-btn-small">
	<?php _e('New message', 'friendso'); ?>
</button>
