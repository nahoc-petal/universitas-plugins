=== Plugin Friends ===
Contributors: peepso, JaworskiMatt, rsusanto
Donate link: http://www.peepso.com
Tags: PeepSo, social network, social media, community, stream, pages, acl, activity, profile, notifications, social, networking, facebook, twitter, chat, like, likes, comments, alerts, privacy, cover photos, avatars, sharing, friends
Requires at least: 4.6
Tested up to: 4.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
FriendSo places an “Add as Friend” button on other members’ cover photos, and displays links to all the member’s friends under the cover image.

FriendSo also adds an important privacy capability. To limit your posts so that they can only be seen by your friends, you can create a community that’s only for people you know.


== Frequently Asked Questions ==

= What's the automated upgrade procedure? =

First you need to update the ChatSo plugin. Then all the other supporting plugins. PeepSo Core plugin must be updated last.

= Can I just use FriendSo on my website? =

For FriendSo to work, you need to have PeepSo installed and activated. FriendSo is not a standalone plugin for WordPress.


== Changelog ==
= 1.7.3 =
* See full changelog here: [PeepSo Changelog](https://www.peepso.com/changelog/ "PeepSo Changelog")

= 1.7.2 =
* See full changelog here: https://www.peepso.com/changelog/

= 1.7.1 =
* See full changelog here: https://www.peepso.com/changelog/

= 1.7.0 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.7.0
* Impr Support for GroupSo plugin.

= 1.6.3 =
* Impr Compatibility with PeepSo 1.6.3.
* Impr Generated new .POT file.
* Fix If there are no notifications, it should say so in the popover. 
* Fix "accepted request" notification - wrong link

= 1.6.2 =
* Impr Compatibility with PeepSo 1.6.2
* Impr Generated new .POT file.
* Impr Notification Improvements.

= 1.6.1 =
* Impr Compatibility with PeepSo 1.6.1
* Impr Generated new .POT file.

= 1.6.0 =
* New Friends' Birthdays Widget
* New Mutual Friends Widget
* New When 'X mutual friends' is clicked, a modal will display those mutual friends. 
* New Introduced tabbed and categorized community Activity Stream.
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.6.0
* Impr Add "Hide when empty" option to Friends widget.
* Impr Widgets 'yes/no' switch styling. 
* Fix Reject and approve friend request on stream items context menu.
* Fix Missing loading indicators on infinite scroll in User Profile.

= 1.5.7 =
* Impr Generated new .POT file.
* Impr Compatibility with PeepSo 1.5.7

= 1.5.6 =
* Impr Compatibility with PeepSo 1.5.6
* Impr Updated Language file.

= 1.5.5 =
* Impr Compatibility with PeepSo 1.5.5
* Impr Updated Language file.
* Impr Renamed the plugin from PeepSo [X] to PeepSo Core [X] 

= 1.5.4 =
* Impr Compatibility with PeepSo 1.5.4
* Impr Updated Language file.
* Fix Friend Request Acceptance notification - wrong url in email notification.

= 1.5.3 =
* Impr Compatibility with PeepSo 1.5.3
* Impr Updated Language file.

= 1.5.2 =
* Impr Compatibility with PeepSo 1.5.2
* Impr Updated Language file.

= 1.5.1 =
* Impr Compatibility with PeepSo 1.5.1
* Impr Updated Language file.
* Impr 3-state buttons on all user listings.

= 1.5.0 =
* Impr Compatibility with PeepSo 1.5.0
* Impr Updated Language file.

= 1.4.2 =
* Impr Compatibility with PeepSo 1.4.2
* Impr Updated Language file.

= 1.4.1 =
* Impr Compatibility with PeepSo 1.4.1
* Impr Updated Language file.
* Impr Remove the 'Days to keep pending Friend Request' setting
* 

= 1.4.0 =
* Impr Compatibility with PeepSo 1.4.0
* Impr Updated Language file.
* Impr Action buttons styling

= 1.3.0 =
* Impr Compatibility with PeepSo 1.3.0
* Impr Updated Language file.
* Impr Friend related action buttons on profiles and user listings.

= 1.2.1 =
* Impr Compatibility with PeepSo 1.2.1
* Impr Updated Language file.

= 1.2.0 =
* Impr Compatibility with PeepSo 1.2.0
* Fix Added .POT language file.

= 1.1.0 =
* Impr Compatibility with PeepSo 1.1.0
* Impr Friends, users search improvements.

= 1.0.1 =
* Impr Compatibility with PeepSo 1.0.1

= 1.0.0 =
* Impr Compatibility with PeepSo 1.0.1

= 1.0.0 RC4 =
* Impr Compatibility with PeepSo 1.0.0 RC4

= 1.0.0 RC1 =
* New Initial release of FriendSo plugin.
