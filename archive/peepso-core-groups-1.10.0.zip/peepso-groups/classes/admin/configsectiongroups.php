<?php

class PeepSoConfigSectionGroups extends PeepSoConfigSectionAbstract
{
// Builds the groups array
	public function register_config_groups()
	{
		$this->context='left';
        $this->_group_general();
        $this->_group_listing();

		$this->context='right';
        $this->_group_categories();
        $this->_group_seo();
        $this->_group_advanced();
	}

    private function _group_seo()
    {
        $this->args('default', 1);
        $this->args('descript', __('Enabled: /groups/my-amazing-group/','groupso') . '<br>'. __('Disabled: /groups/1234/','groupso'));
        $this->set_field(
            'groups_urls_slugs_enable',
            __('Use slugs in group URLs', 'groupso'),
            'yesno_switch'
        );

        $options = array(
            0 => __('never','groupso'),
            1 => __('when group name is changed','groupso'),
            2 => __('by the group owner','groupso'),
        );
        $this->args('options', $options);
        $this->args('default', 'on');
        $this->args('descript', __('Option 1: group slug will stay the same as the original group name.','groupso') .'<br>'.__('Option 2: new group slug will be generated upon group name change.','groupso') . '<br>' . __('Option 3: the group owner can change the slug manually.','groupso'));
        $this->set_field(
            'groups_slug_edit',
            __('Group slug changes', 'wordfilter-peepso'),
            'select'
        );

        $this->set_group(
            'opengraph',
            __('SEO', 'groupso')
        );
    }

    private function _group_listing(){
        # Show Group Owner on Groups listing
        $this->args('default', 1);
        $this->args('descript', __('Show or hide the groups owner(s) in the groups listing','groupso'));
        $this->set_field(
            'groups_listing_show_group_owner',
            __('Show owner(s)','groupso'),
            'yesno_switch'
        );

        # Show Group Creation date on Groups listing
        $this->args('default', 1);
        $this->args('descript', __('Show or hide the groups creation dates in the groups listing','groupso'));
        $this->set_field(
            'groups_listing_show_group_creation_date',
            __('Show creation date','groupso'),
            'yesno_switch'
        );

        # Allow guest access to Groups listing
        $this->args('descript', __('Show or hide the groups listing from visitors who are not logged in','groupso'));
        $this->set_field(
            'groups_allow_guest_access_to_groups_listing',
            __('Allow guest access','groupso'),
            'yesno_switch'
        );

        $this->set_group(
            'opengraph',
            __('Group listings', 'groupso')
        );
    }
	private function _group_general()
	{
		# Enable Group Creation
		$this->args('default', 1);
		$this->args('descript', __('Enabled: all site members can create groups','groupso') .'<br>' .__('Disabled: only site admins can create groups','groupso'));
		$this->set_field(
			'groups_creation_enabled',
			__('Enable group creation', 'groupso'),
			'yesno_switch'
		);


		$general_config = apply_filters('peepso_groups_general_config', array());

		if(count($general_config) > 0 ) {

			foreach ($general_config as $option) {
				if(isset($option['descript'])) {
					$this->args('descript', $option['descript']);
				}
				if(isset($option['int'])) {
					$this->args('int', $option['int']);
				}
				if(isset($option['default'])) {
					$this->args('default', $option['default']);
				}

				$this->set_field($option['name'], $option['label'], $option['type']);
			}
		}

        // Build Group
		$this->set_group(
			'general',
			__('General', 'groupso')
		);
	}

	private function _group_categories()
	{
		# Enable Group Categories
		$this->args('default', 0);
		$this->args('descript', __('Users will be able to assign groups to categories.','groupso'));
		$this->set_field(
			'groups_categories_enabled',
			__('Enable group categories', 'groupso'),
			'yesno_switch'
		);


        # Enable Multiple Categories Per Group
        $this->args('default', 0);
        $this->args('descript', __('Users will be able to assign a group to multiple categories','groupso'));
        $this->set_field(
            'groups_categories_multiple_enabled',
            __('Allow multiple categories per group', 'groupso'),
            'yesno_switch'
        );

        # Hide Empty Categories
        $this->args('default', 0);
        $this->args('descript', __('Hide categories which don\'t have any groups assigned to them.','groupso'));
        $this->set_field(
            'groups_categories_hide_empty',
            __('Hide empty categories', 'groupso'),
            'yesno_switch'
        );

        # Show Group Count
        $this->args('default', 0);
        $this->args('descript', __('The count will not be accurate if a category contains unpublished or secret groups.','groupso'));
        $this->set_field(
            'groups_categories_show_count',
            __('Show group count', 'groupso'),
            'yesno_switch'
        );

		// Build Group
		$this->set_group(
			'categories',
			__('Categories', 'groupso')
		);
	}

    private function _group_advanced()
    {
        # Default onsite subscription status
        $this->args('default', 1);
        $this->args('descript', __('Enabled: new group members will automatically be subscribed to receive new posts notifications (on-site)','groupso'));
        $this->set_field(
            'groups_notify_default',
            __('Automatically subscribe new members to notifications', 'groupso'),
            'yesno_switch'
        );

        # Default e-mail subscription status
        $this->args('default', 1);
        $this->args('descript', __('Enabled: new group members will automatically be subscribed to receive new posts e-mail notifications','groupso'));
        $this->set_field(
            'groups_notify_email_default',
            __('Automatically subscribe new members to e-mails', 'groupso'),
            'yesno_switch'
        );

        # Replace "invite" with "add" for admins
        $this->args('default', 0);
        $this->args('descript', __('Site and Community Administrators will add users to group without the need to confirm.','groupso'));
        $this->set_field(
            'groups_add_by_admin_directly',
            __('Replace "invite" with "add" for Admins', 'groupso'),
            'yesno_switch'
        );

        # Email admins about new groups
        $this->args('default', 0);
        $this->args('descript', __('Users with Administrator role will receive an e-mail when a new group is created','groupso'));
        $this->set_field(
            'groups_create_notify_admin',
            __('E-mail Admins when a new group is created', 'groupso'),
            'yesno_switch'
        );

        # Group Meta in Stream items
        $this->args('default', 0);
        $this->args('descript', __('When enabled, hovering over group names on stream will display membership and following summary. This feature is likely to slow down stream performance.','groupso'));
        $this->set_field(
            'groups_meta_in_stream',
            __('Show membership summary for group names on stream', 'groupso'),
            'yesno_switch'
        );

        // Build Group
        $this->set_group(
            'advanced',
            __('Advanced', 'groupso')
        );
    }

}