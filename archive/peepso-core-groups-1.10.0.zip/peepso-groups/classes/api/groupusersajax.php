<?php

class PeepSoGroupUsersAjax extends PeepSoAjaxCallback
{
	private $_group_id;
	private $_model;

	protected function __construct()
	{
		parent::__construct();

		$this->_group_id = $this->_input->val('group_id');

		if(0 == $this->_group_id) {
			return;
		}

		$this->_model = new PeepSoGroupUsers($this->_group_id);
	}

	public function init($group_id)
	{
		$this->_group_id = $group_id;
		$this->_model = new PeepSoGroupUsers($this->_group_id);
	}

    /**
     * GET
     * @param PeepSoAjaxResponse|NULL $resp
     * @param null $role
     * @param null $keys
     * @return array
     */
	public function search(PeepSoAjaxResponse $resp = NULL, $role = NULL, $keys = NULL)
	{
		$members_response = array();

		if(NULL == $role) {
			$role = $this->_input->val('role', 'member');
		}

		$page 		= $this->_input->int('page', 1);
		$order_by 	= $this->_input->val('order_by', 'gm_joined');
		$order 		= strtoupper($this->_input->val('order', 'ASC'));

		if (NULL !== $order_by && strlen($order_by)) {
			if ('ASC' !== $order && 'DESC' !== $order) {
				$order = 'ASC';
			}
		}

        // default limit is 1 (NewScroll)
        $limit = $this->_input->int('limit', 1);

		$offset = ($page - 1) * $limit;

		switch($role) {
            case 'management':
                $users = $this->_model->get_management($order_by, $order, $offset, $limit);
                break;
			case 'owner':
				$users = $this->_model->get_owners($order_by, $order, $offset, $limit);
				break;
			case 'manager':
				$users = $this->_model->get_managers($order_by, $order, $offset, $limit);
				break;
			case 'moderator':
				$users = $this->_model->get_moderators($order_by, $order, $offset, $limit);
				break;
            case 'pending_admin':
                $users = $this->_model->get_pending_admin($order_by, $order, $offset, $limit);
                break;
            case 'banned':
                $users = $this->_model->get_banned($order_by, $order, $offset, $limit);
                break;
			default:
				$users = $this->_model->get_members($order_by, $order, $offset, $limit);
		}

		if(count($users)) {

			if(NULL == $keys) {
				$keys = $this->_input->val('keys', 'id');
			}

			foreach ($users as $user) {
			    $member = PeepSoGroupAjaxAbstract::format_response($user, PeepSoGroupAjaxAbstract::parse_keys('groupuser', $keys), $this->_group_id);

			    ob_start();
                do_action('peepso_action_render_user_name_before', $user->user_id);
                $before_fullname = ob_get_clean();

                ob_start();
                do_action('peepso_action_render_user_name_after', $user->user_id);
                $after_fullname = ob_get_clean();

                $member['fullname_before'] = $before_fullname;
                $member['fullname_after'] = $after_fullname;

				$members_response[] = $member;
			}
		}

		if(NULL == $resp) {
			return $members_response;
		}

		$resp->success(1);
		$resp->set('members', $members_response);
	}

	public function search_to_invite(PeepSoAjaxResponse $resp, $keys = NULL)
	{
		$users = array();
 		$group_user = new PeepSoGroupUser($this->_group_id);

		// Find site users who do not have a record inside group_members for this group ID
		if ($group_user->can('invite')) {

			$args = array();
			$args_pagination = array();
			$page = $this->_input->int('page', 1);

			// Sorting
			$column = (PeepSo::get_option('system_display_name_style', 'real_name') == 'real_name' ? 'display_name' : 'username');

			$order_by	= $this->_input->val('order_by', $column);
			$order		= $this->_input->val('order', ($order_by == $column ? 'ASC' : NULL));

			if( NULL !== $order_by && strlen($order_by) ) {
				if('ASC' !== $order && 'DESC' !== $order) {
					$order = 'DESC';
				}

				$args['orderby']= $order_by;
				$args['order']	= $order;
			}

			$limit = 20;
			$limit = $this->_input->int('limit', $limit);
			$resp->set('page', $page);
			$args_pagination['offset'] = ($page-1)*$limit;
			$args_pagination['number'] = $limit;

			// Merge pagination args and run the query to grab paged results
			$args = array_merge($args, $args_pagination);
			$query = stripslashes_deep($this->_input->val('query', ''));

			$users = $this->_model->search_to_invite($args, $query);

			$members_page = count($users->results);
			$members_found = $users->total;

			if (count($users->results) > 0) {

				if(NULL == $keys) {
					$keys = $this->_input->val('keys', 'id');
				}

				foreach ($users->results as $user_id) {
					$user = new PeepSoGroupUser($this->_group_id, $user_id);
					$members[] = PeepSoGroupAjaxAbstract::format_response($user, PeepSoGroupAjaxAbstract::parse_keys('groupuser', $keys), $this->_group_id);
				}

				if($members_found > 0)
				{
					$resp->success(TRUE);
					$resp->set('users', $members);
				}
				else
				{
					$resp->success(FALSE);
					$resp->error(__('No users found.', 'groupso'));
				}

			} else {
				$resp->success(FALSE);
				$resp->error(__('No users found.', 'groupso'));
			}
		}
	}

	/*
	 * Chainable methods
	 * These methods should only be directly called from other PeepSo(*)Ajax classes
	 * peepsogroupsuseajax.method(key1|key2|key3)
	 */

	public function owners($keys)
	{
		return $this->search_members(NULL, 'owner', $keys);
	}

	public function admins($keys)
	{
		return $this->search_members(NULL, 'admin', $keys);
	}

	public function moderators($keys)
	{
		return $this->search_members(NULL, 'owner', $keys);
	}


}
