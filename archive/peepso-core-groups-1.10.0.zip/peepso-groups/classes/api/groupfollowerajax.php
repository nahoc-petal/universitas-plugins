<?php

class PeepSoGroupFollowerAjax extends PeepSoGroupAjaxAbstract
{

    protected function __construct()
    {
        parent::__construct();

        if($this->_group_id > 0) {
            $this->_model= new PeepSoGroupFollower($this->_group_id, $this->_user_id);
        }
    }

    public function init($group_id)
    {
        $this->_group_id = $group_id;
        $this->_model = new PeepSoGroupFollower($this->_group_id, $this->_user_id);
    }

    public function follower_actions(PeepSoAjaxResponse $resp = NULL) {
        $response = $this->_model->get('follower_actions');

        if(NULL == $resp) {
            return($response);
        }

        $resp->set('follower_actions', $response);
    }

    public function set(PeepSoAjaxResponse $resp) {

        // it's basically impossible to set invalid prop/val, so no validation required

        $success = $this->_model->set( $this->_input->val('prop'), $this->_input->int('value') );

        if(NULL != $success) {
            $resp->success(TRUE);
        } else {
            $resp->error('Save failed');
        }

        $resp->set('follower_actions', $this->_model->get('follower_actions'));
    }
}