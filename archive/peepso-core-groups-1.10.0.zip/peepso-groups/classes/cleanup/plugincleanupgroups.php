<?php

class PeepSoPluginCleanupGroups
{
    public static $instance;

    public static function get_instance() {

        if(!isset(self::$instance)) {
            self::$instance = new self();
        }

        return self::$instance;
    }

    public function __construct() {
        add_action('deleted_user', array('PeepSoPluginCleanupGroups','cleanup_basic'));
        add_action(PeepSo::CRON_CLEANUP_BASIC, array('PeepSoPluginCleanupGroups','cleanup_basic'));
    }

    public static function cleanup_basic()
    {
        global $wpdb;
        $PeepSoGroupCategories = new PeepSoGroupCategories();


        // Orphaned group_categories entries for deleted groups
        $t1 = $wpdb->prefix.PeepSoGroupCategoriesGroups::TABLE;
        $t2 = $wpdb->posts;
        $query = "DELETE FROM $t1 WHERE NOT EXISTS(SELECT `ID` FROM $t2 WHERE $t2.ID=$t1.gm_group_id)";
        $wpdb->query($query);


        // Orphaned group_categories entries for deleted categories
        $t1 = $wpdb->prefix.PeepSoGroupCategoriesGroups::TABLE;
        $t2 = $wpdb->posts;
        $query = "DELETE FROM $t1 WHERE NOT EXISTS(SELECT `ID` FROM $t2 WHERE $t2.ID=$t1.gm_cat_id)";
        $wpdb->query($query);


        // Orphaned notifications for deleted groups
        #$t1 = $wpdb->prefix.PeepSoNotifications::TABLE;
        #$t2 = $wpdb->posts;
        #$query = "DELETE FROM $t1 WHERE $t1.not_module_id=".PeepSoGroupsPlugin::MODULE_ID." AND NOT EXISTS(SELECT `ID` FROM $t2 WHERE $t2.ID=$t1.not_external_id)";
        #$wpdb->query($query);


        // Orphaned group_members entries for deleted groups
        $t1 = $wpdb->prefix.PeepSoGroupUsers::TABLE;
        $t2 = $wpdb->posts;
        $query = "DELETE FROM $t1 WHERE NOT EXISTS(SELECT `ID` FROM $t2 WHERE $t2.ID=$t1.gm_group_id)";
        $wpdb->query($query);


        // Orphaned group_members entries for deleted users
        $t1 = $wpdb->prefix.PeepSoGroupUsers::TABLE;
        $t2 = $wpdb->users;
        $query = "DELETE FROM $t1 WHERE NOT EXISTS(SELECT `ID` FROM $t2 WHERE $t2.ID=$t1.gm_user_id)";
        $wpdb->query($query);

        // Update group count for all categories
        foreach($PeepSoGroupCategories->categories as $id => $category) {
            PeepSoGroupCategoriesGroups::update_stats_for_category($id);
        }
    }

    public static function cleanup_full()
    {
        self::cleanup_basic();

        // TBA
    }
}