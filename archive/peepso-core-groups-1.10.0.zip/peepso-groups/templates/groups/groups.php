<?php

$categories_enabled = FALSE;
$categories_tab  = FALSE;

if(PeepSo::get_option('groups_categories_enabled', FALSE)) {

	$categories_enabled = TRUE;

	$PeepSoGroupCategories = new PeepSoGroupCategories(FALSE, NULL);
	$categories = $PeepSoGroupCategories->categories;

	if (!isset($_GET['category'])) {
		$categories_tab = TRUE;
	}
}
?>
<div class="peepso">
	<?php PeepSoTemplate::exec_template('general','navbar'); ?>
	<?php PeepSoTemplate::exec_template('general', 'register-panel'); ?>
	<?php if(get_current_user_id() || (get_current_user_id() == 0 && $allow_guest_access)) { ?>
		<section id="mainbody" class="ps-page-unstyled">
			<section id="component" role="article" class="ps-clearfix">
				<div class="ps-page-actions">
					<?php if(PeepSoGroupUser::can_create()) { ?>
					<a class="ps-btn ps-btn-small" href="javascript:void(0);" onclick="peepso.groups.dlgCreate();">
						<?php _e('Create Group', 'groupso');?>
					</a>
					<?php } ?>
				</div>

				<h4 class="ps-page-title"><?php _e('Groups', 'groupso'); ?></h4>

				<?php if(!$categories_tab) { ?>

				<form class="ps-form ps-form-search" role="form" name="form-peepso-search" onsubmit="return false;">
					<div class="ps-form-row">
						<input placeholder="<?php _e('Start typing to search...', 'groupso');?>" type="text" class="ps-input full ps-js-groups-query" name="query" value="<?php echo esc_attr($search); ?>" />
					</div>
					<a href="javascript:" class="ps-form-search-opt">
						<span class="ps-icon-cog"></span>
					</a>
				</form>
				<?php
				$default_sorting = '';
				if(!strlen(esc_attr($search)))
				{
					$default_sorting = PeepSo::get_option('groups_default_sorting','id');
				}

				?>
				<div class="ps-js-page-filters" style="<?php echo ($categories_enabled && !$categories_tab) ? "" : "display:none";?>">
					<div class="ps-page-filters">
						<div class="ps-filters-row">
							<label><?php _e('Sort', 'groupso'); ?></label>
							<select class="ps-select ps-js-groups-sortby" style="margin-bottom:5px">
								<option value="id|desc"><?php _e('Recently added', 'groupso'); ?></option>
								<option <?php echo ('post_title' == $default_sorting) ? ' selected="selected" ' : '';?> value="post_title|asc"><?php _e('Alphabetical', 'groupso'); ?></option>
								<option <?php echo ('meta_members_count' == $default_sorting) ? ' selected="selected" ' : '';?>value="meta_members_count|desc"><?php _e('Members count', 'groupso'); ?></option>
							</select>
						</div>


						<?php if($categories_enabled) { ?>

							<div class="ps-filters-row">
								<label><?php _e('Category', 'groupso'); ?></label>
								<select class="ps-select ps-js-groups-category" style="margin-bottom:5px">
									<option value="0"><?php _e('No filter', 'groupso'); ?></option>
									<?php
									if(count($categories)) {
										foreach($categories as $id=>$cat) {
										    $count = PeepSoGroupCategoriesGroups::update_stats_for_category($id);
											$selected = "";
											if($id==$category) {
												$selected = ' selected="selected"';
											}
											echo "<option value=\"$id\"{$selected}>{$cat->name} ($count)</option>";
										}
									}
									?>
									<option value="-1" <?php if(-1 == $category) { echo 'selected="selected"';}?>><?php _e('Uncategorized', 'groupso'); ?></option>
								</select>
							</div>

						<?php } // ENDIF ?>

					</div>
				</div>
				<?php } ?>

				<?php if($categories_enabled) { ?>
				<div class="ps-tabs__wrapper">
					<div class="ps-tabs ps-tabs--arrows">
						<div class="ps-tabs__item <?php if(!$categories_tab) echo "current";?>"><a href="<?php echo PeepSo::get_page('groups').'/?category=0';?>"><?php _e('Groups', 'groupso'); ?></a></div>
						<div class="ps-tabs__item <?php if($categories_tab) echo "current";?>"><a href="<?php echo PeepSo::get_page('groups');?>"><?php _e('Group Categories', 'groupso'); ?></a></div>
					</div>
				</div>
				<?php } ?>


				<?php  if($categories_tab) { ?>

				<!-- Categories -->
				<div class="ps-clearfix mb-20"></div>
				<div class="ps-accordion ps-js-group-cats" style="margin-bottom:10px"></div>
				<div class="ps-scroll ps-clearfix ps-js-group-cats-triggerscroll">
					<img class="post-ajax-loader ps-js-group-cats-loading" src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>" alt="loading" style="display:none" />
				</div>

				<?php } else { ?>

				<div class="ps-clearfix mb-20"></div>
				<div class="ps-groups ps-clearfix ps-js-groups"></div>
				<div class="ps-scroll ps-clearfix ps-js-groups-triggerscroll">
					<img class="post-ajax-loader ps-js-groups-loading" src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>" alt="" style="display:none" />
				</div>

				<?php } ?>

			</section>
		</section>
	<?php } ?>
</div><!--end row-->

<?php

if(get_current_user_id()) {
	PeepSoTemplate::exec_template('activity', 'dialogs');
}
