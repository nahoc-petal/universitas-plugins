<?php
$PeepSoGroupUsers = new PeepSoGroupUsers($group->id);
$PeepSoGroupUsers->update_members_count('banned');
$PeepSoGroupUsers->update_members_count('pending_admin');
?>
<div class="ps-tabs__wrapper">
        <div class="ps-tabs ps-tabs--arrows">

            <div class="ps-tabs__item <?php if (!$tab) echo "current"; ?>"><a
                        href="<?php echo $group->get_url() . 'members/'; ?>"><?php _e('All Members', 'groupso'); ?></a>
            </div>

            <div class="ps-tabs__item <?php if ('management'==$tab) echo "current"; ?>"><a
                        href="<?php echo $group->get_url() . 'members/management'; ?>"><?php _e('Management', 'groupso'); ?></a>
            </div>

            <?php if($PeepSoGroupUser->can('manage_users')) { ?>


                <div class="ps-tabs__item <?php if ('pending' == $tab) echo "current"; ?>"><a
                        href="<?php echo $group->get_url() . 'members/pending'; ?>"><?php echo sprintf(__('Pending (%s)', 'groupso'), $group->pending_admin_members_count); ?></a>
                </div>

                <div class="ps-tabs__item <?php if ('banned' == $tab) echo "current"; ?>"><a
                            href="<?php echo $group->get_url() . 'members/banned'; ?>"><?php echo sprintf(__('Banned (%s)', 'groupso'), $group->banned_members_count); ?></a>
                </div>

            <?php } ?>
        </div>
</div>
