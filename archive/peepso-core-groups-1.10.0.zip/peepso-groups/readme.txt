=== PeepSo Location ===
Contributors: peepso, JaworskiMatt, rsusanto
Donate link: http://www.peepso.com
Tags: PeepSo, Email, Map, Location, Stream, Social, Localization, Sharing, Share location, facebook, social network, private social network
Requires at least: 4.6
Tested up to: 4.9
Stable tag: trunk
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Description ==
GroupSo Plugin adds possibility to create groups within your PeepSo community.

== Installation ==


= From a Zip file =

1. Make sure you have [PeepSo](https://wordpress.org/plugins/peepso-core/ "PeepSo - Social Network Plugin for WordPress") installed and activated.
2. Download PeepSo Groups.
3. Navigate to the Admin area of your site.
4. Go to Plugins > "Add New".
5. Select "Upload Plugin".
6. Select the ZIP installation file of GroupSo plugin.
7. Activate GroupSo from your Plugins page.


== Screenshots ==
1. 
2. 
3. 

== Try the demo ==
 
If you want to see how a **social networking** on WordPress looks live, you can visit our [demo site](http://peepso.com/demo "PeepSo Demo"). You will be able to log in as a real user (username: demo, password: demo) and take LocSo for a test drive in a real PeepSo environment. The demo includes all other premium plugins so you'll be able to see them all in action.
 
== Frequently Asked Questions ==

= What's the best order in which to upgrade? =

First you need to update the ChatSo plugin. Then all the other supporting plugins. PeepSo Core plugin must be updated last.

= Can I just use PeepSo Groups on my website? =

For PeepSo Groups to work, you need to have PeepSo installed and activated. PeepSo Groups is not a standalone plugin for WordPress.
 

== Changelog ==
= ALL VERSIONS =
* See full changelog here: [PeepSo Changelog](https://www.peepso.com/changelog/ "PeepSo Changelog")

= 1.7.0 =
* Initial release