var GroupActions = require( './group-actions' ).default;

(function( $, factory ) {

	var PsPageGroups = factory( $ );
	var ps_page_groups = new PsPageGroups('.ps-js-groups');

})( jQuery, function( $ ) {

function PsPageGroups() {
	if ( PsPageGroups.super_.apply( this, arguments ) ) {
		$( $.proxy( this.init_page, this ) );
	}
}

// inherit from `PsPageAutoload`
peepso.npm.inherits( PsPageGroups, PsPageAutoload );

peepso.npm.objectAssign( PsPageGroups.prototype, {

	init_page: function() {
		this._search_$query = $('.ps-js-groups-query').on('input', $.proxy( this._filter, this ));
		this._search_$order = $('.ps-js-groups-sortby').on('change', $.proxy( this._filter, this ));
		this._search_$category = $('.ps-js-groups-category').on('change', $.proxy( this._filter_category, this ));

		// toggle search filter form
		$('.ps-form-search-opt').on('click', $.proxy( this._toggle, this ));

		this._search_params.user_id = +peepsodata.userid || undefined;
		this._search_params.category = this._search_$category.val() || 0;
		this._filter();
	},

	_search_url: 'groupsajax.search',

	_search_params: {
		uid: peepsodata.currentuserid,
		user_id: undefined,
		query: '',
		category: 0,
		order_by: undefined,
		order: undefined,
		admin: undefined,
		keys: 'id,name,description,date_created_formatted,members_count,url,published,avatar_url_full,privacy,groupuserajax.member_actions,groupfollowerajax.follower_actions',
		limit: 2,
		page: 1
	},

	_search_render_html: function( data ) {
		var itemTemplate = peepso.template( peepsogroupsdata.listItemTemplate ),
			actionsTemplate = peepso.template( peepsogroupsdata.listItemMemberActionsTemplate ),
			query = this._search_params.query,
			html = '',
			groupData, reQuery, highlight, actions, i;

		if ( data.groups && data.groups.length ) {
			for ( i = 0; i < data.groups.length; i++ ) {
				groupData = data.groups[ i ];
				groupData.nameHighlight = groupData.name || '';

				// Decode html entities on description.
				groupData.description = $('<div/>').html( groupData.description || '' ).text();

				// Highlight keyword found in title and description.
				if ( query ) {
					reQuery = _.filter( query.split(' '), function( str ) { return str !== '' });
					reQuery = _.map( reQuery, function( str ) {
						return str.replace( /[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, '\\$&' );
					});

					reQuery = RegExp('(' + reQuery.join('|') + ')', 'ig');
					highlight = '<span style="background:' + peepso.getLinkColor(0.3) +  '">$1</span>';
					groupData.nameHighlight = groupData.nameHighlight.replace( reQuery, highlight );
					groupData.description = ( groupData.description || '' ).replace( reQuery, highlight );
				}

				html += itemTemplate( $.extend({}, groupData, { member_actions: '' }) );

				// Render group actions.
				_.defer(function( data ) {
					var $card = $( '.ps-js-group-item--' + data.id ),
						$actions = $card.find( '.ps-js-member-actions' ),
						actions;

					actions = new GroupActions({
						id: data.id,
						member_actions: data.groupuserajax.member_actions,
						follower_actions: data.groupfollowerajax.follower_actions,
					});

					$actions.html( actions.$el );
				}, groupData );
			}
		}

		return html;
	},

	_search_get_items: function() {
		return this._search_$ct.children('.ps-group__item-wrapper');
	},

	/**
	 * @param {object} params
	 * @returns jQuery.Deferred
	 */
	_fetch: function( params ) {
		return $.Deferred( $.proxy(function( defer ) {

			// Multiply limit value by 2 which translate to 2 rows each call.
			params = $.extend({}, params );
			if ( ! _.isUndefined( params.limit ) ) {
				params.limit *= 2;
			}

			this._fetch_xhr && this._fetch_xhr.abort();
			this._fetch_xhr = peepso.disableAuth().disableError().getJson( this._search_url, params, $.proxy(function( response ) {
				if ( response.success ) {
					defer.resolveWith( this, [ response.data ]);
				} else {
					defer.rejectWith( this, [ response.errors ]);
				}
			}, this ));
		}, this ));
	},

	/**
	 * Filter search based on selected elements.
	 */
	_filter: function() {
		var order = ( this._search_$order.val() || '' ).split('|');

		// abort current request
		this._fetch_xhr && this._fetch_xhr.abort();

		this._search_params.query = $.trim( this._search_$query.val() );
		this._search_params.category = this._search_$category.val();
		this._search_params.order_by = order[0] || undefined;
		this._search_params.order = order[1] || undefined;
		this._search_params.page = 1;
		this._search();
	},

	/**
	 * Filter by category.
	 */
	_filter_category: function( e ) {
		var url = window.location.href,
			val = e.target.value || 0,
			reg = /(category=)-?\d+/;

		this._filter();

		// update url
		if ( url.match( reg ) ) {
			url = url.replace( reg, '$1' + val );
			if ( window.history && history.pushState ) {
				history.pushState( null, '', url );
			}
		}
	},

	/**
	 * Toggle search filter form.
	 */
	_toggle: function() {
		$('.ps-js-page-filters').stop().slideToggle();
	}
});

return PsPageGroups;

});
