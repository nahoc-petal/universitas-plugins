(function( $, factory ) {

	var PsPageGroupMembers = factory( $ );
	var ps_page_group_members = new PsPageGroupMembers('.ps-js-group-members');

})( jQuery, function( $ ) {

function PsPageGroupMembers() {
	PsPageGroupMembers.super_.apply( this, arguments );
	$( $.proxy( this.init_page, this ) );
}

// inherit from `PsPageAutoload`
peepso.npm.inherits( PsPageGroupMembers, PsPageAutoload );

peepso.npm.objectAssign( PsPageGroupMembers.prototype, {

	init_page: function() {
		var url = window.location.href,
			matches = url.match( /members\/(pending|management|banned)/ ),
			roleMapper;

		roleMapper = {
			pending: 'pending_admin',
			management: 'management',
			banned: 'banned'
		};

		// check role
		this._search_params.role = matches ? roleMapper[ matches[1] ] : '';
		this._filter();
	},

	_search_url: 'groupusersajax.search',

	_search_params: {
		group_id: peepsogroupsdata.group_id,
		keys: 'id,avatar,fullname,profileurl,role',
		limit: 2,
		page: 1
	},

	_search_render_html: function( data ) {
		var template = peepso.template( peepsogroupsdata.memberItemTemplate ),
			html = '',
			i;

		if ( data.members && data.members.length ) {
			for ( i = 0; i < data.members.length; i++ ) {
				html += template( $.extend({}, data.members[ i ] ));
			}
		}

		this._get_passive_actions();

		return html;
	},

	_search_get_items: function() {
		return this._search_$ct.children('.ps-members-item-wrapper');
	},

	/**
	 * Filter search based on selected elements.
	 */
	_filter: function() {

		// abort current request
		this._fetch_xhr && this._fetch_xhr.abort();

		this._search_params.page = 1;
		this._search();
	},

	/**
	 * Get passive action for each group member
	 */
	_get_passive_actions: _.debounce(function() {
		var className = 'ps-js-actions-placeholder',
			$actions = this._search_$ct.find('.' + className ),
			template = peepso.template( peepsogroupsdata.memberItemActionsTemplate );

		$actions.each( $.proxy(function( index, elem ) {
			var $action = $( elem ).removeClass( className ),
				user_id = +$action.data('id');

			$action.show();

			this._fetch_passive_actions( user_id ).done(function( data ) {
				data = $.extend( data, {
					id: this._search_params.group_id,
					passive_user_id: user_id
				});
				$action.html( template( data ) );
			}).fail(function() {
				$action.remove();
			});
		}, this ));
	}, 100 ),

	/**
	 * @param {number} user_id
	 * @returns jQuery.Deferred
	 */
	_fetch_passive_actions: function( user_id ) {
		var params = {
			group_id: this._search_params.group_id,
			passive_user_id: user_id
		};

		return $.Deferred( $.proxy(function( defer ) {
			peepso.getJson('groupuserajax.member_passive_actions', params, $.proxy(function( response ) {
				var data = response.data || {};
				if ( data.member_passive_actions && data.member_passive_actions.length ) {
					defer.resolveWith( this, [ data ]);
				} else {
					defer.rejectWith( this );
				}
			}, this ));
		}, this ));
	}

});

return PsPageGroupMembers;

});
