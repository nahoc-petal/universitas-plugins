<?php

class PeepSoConfigSectionBlogposts extends PeepSoConfigSectionAbstract
{
	// Builds the groups array
	public function register_config_groups()
	{
		if(isset($_GET['admin_tutorial_reset'])) {
			delete_user_meta(get_current_user_id(), 'peepso_blogposts_admin_tutorial_hide');
			PeepSo::redirect(admin_url().'admin.php?page=peepso_config&tab=blogposts');
		}

		if(isset($_GET['admin_tutorial_hide'])) {
			add_user_meta(get_current_user_id(), 'peepso_blogposts_admin_tutorial_hide', 1, TRUE);
			PeepSo::redirect(admin_url().'admin.php?page=peepso_config&tab=blogposts');
		}

		// display the admin tutorial unless this user has already hidden it
		if(1 != get_user_meta(get_current_user_id(), 'peepso_blogposts_admin_tutorial_hide', TRUE)) {
			ob_start();
			PeepSoTemplate::exec_template('blogposts', 'admin_tutorial');

			$peepso_admin = PeepSoAdmin::get_instance();
			$peepso_admin->add_notice(ob_get_clean(), '');
		}

		$this->context='left';
        $this->group_profile();
        $this->group_profile_two_column();
        $this->group_text();
		$this->group_profile_featured_images();

		$this->context='right';
        $this->group_activity();
        // @todo #2157
	}

	/**
	 * General Settings Box
	 */
	private function group_profile()
	{
        $this->args('descript', __('Show "Blog Posts" tab in user profiles','peepsoblogposts'));
        $this->set_field(
            'blogposts_profile_enable',
            __('Enabled', 'peepsoblogposts'),
            'yesno_switch'
        );

        $this->args('descript', __('The profile tab will not appear if the user has no blog posts','peepsoblogposts'));
        $this->set_field(
            'blogposts_profile_hideempty',
            __('Hide when empty', 'peepsoblogposts'),
            'yesno_switch'
        );

        // Author Box
        $this->args('descript', __('Adds a small "about the author" box under blog posts','peepsoblogposts'));

        $this->set_field(
            'blogposts_authorbox_enable',
            __('Enable Author Box', 'peepsoblogposts'),
            'yesno_switch'
        );

        $this->set_field(
            'blogposts_authorbox_author_name_pre_text',
            __('Text before author name', 'peepsoblogposts'),
            'text'
        );

        // CM Frontend Submissions
        $this->set_field(
            'blogposts_submissions_header',
            __('Frontend Submissions', 'peepsoblogposts'),
            'separator'
        );

        if ( !class_exists( 'CMUserSubmittedPosts' ) ) {
            $url = '<a href="https://www.cminds.com/wordpress-plugins-library/cm-user-submitted-posts/?af=7789" target="_blank">CMinds User Submitted Posts</a>';
            $this->set_field(
                'blogposts_submissions_enable_descript',
                sprintf(__('This feature requires the %s plugin.', 'peepsoblogposts'), $url),
                'message'
            );
        } else {
            $this->set_field(
                'blogposts_submissions_enable',
                __('Enable Frontend Submissions', 'peepsoblogposts'),
                'yesno_switch'
            );
        }



		$this->set_group(
			'blogposts_general',
			__('Author Profiles', 'peepsoblogposts')
		);
	}

    /**
     * Text Parsing
     */
    private function group_text()
    {
        $this->args('int', TRUE);
        $this->args('default', 50);

        // Once again the args will be included automatically. Note that args set before previous field are gone
        $this->args('descript', __('0 for no content', 'peepsoblogposts'));
        $this->set_field(
            'blogposts_profile_content_length',
            __('Length limit (words)', 'peepsoblogposts'),
            'text'
        );

        $this->args('descript', __('Forced removal of some shortcodes immune to native WP methods (eg Divi Builder and similar). This is an experimental feature, we recommend using plain-text excerpts instead.' ,'peepsoblogposts'));
        $this->set_field(
            'blogposts_profile_content_force_strip_shortcodes',
            __('Aggressive shortcode removal', 'peepsoblogposts'),
            'yesno_switch'
        );

        $this->set_group(
            'blogposts_text',
            __('Text', 'peepsoblogposts')
        );
    }

	private function group_profile_featured_images()
	{
		$this->set_field(
			'blogposts_profile_featured_image_enable',
			__('Show featured images', 'peepsoblogposts'),
			'yesno_switch'
		);

		$this->args('descript', __('Display an empty box if an image is not found (to maintain the layout)', 'peepsoblogposts'));
		$this->set_field(
			'blogposts_profile_featured_image_enable_if_empty',
			__('Placeholder', 'peepsoblogposts'),
			'yesno_switch'
		);

		$options = array(
            'top'   => __('Top (rectangle)', 'peepsoblogposts'),
            'left'  => __('Left (square)', 'peepsoblogposts'),
            'right' => __('Right (square)', 'peepsoblogposts'),
        );

		$this->args('options', $options);

        $this->set_field(
            'blogposts_profile_featured_image_position',
            __('Position', 'peepsoblogposts'),
            'select'
        );

		$this->args('int', TRUE);
		$this->args('default', 150);

		// Once again the args will be included automatically. Note that args set before previous field are gone
		$this->set_field(
			'blogposts_profile_featured_image_height',
			__('Height (px)', 'peepsoblogposts'),
			'text'
		);


		$this->set_group(
			'blogposts_featured_image',
			__('Featured Images', 'peepsoblogposts')
		);

	}

	private function group_profile_two_column()
	{
		$this->set_field(
			'blogposts_profile_two_column_enable',
			__('Enable two column layout', 'peepsoblogposts'),
			'yesno_switch'
		);

		$this->args('int', TRUE);
		$this->args('default', 350);

		$this->set_field(
			'blogposts_profile_two_column_height',
			__('Box height (px)', 'peepsoblogposts'),
			'text'
		);


		$this->set_group(
			'blogposts_two_column',
			__('Two column layout', 'peepsoblogposts')
		);

	}
    
	/**
	 * General Settings Box
	 */
	private function group_activity()
	{
		$this->set_field(
			'blogposts_activity_enable',
			__('Post to Activity Stream', 'peepsoblogposts'),
			'yesno_switch'
		);


        // Action text
        $this->args('default', PeepSo::get_option('blogposts_activity_type_post_text_default',''));
        $this->set_field(
            'blogposts_activity_type_post_text',
            'Action text',
            'text'
        );

        $this->args('descript', __('The title of  the post will be displayed after the action text as a link','peepsoblogposts'));
        $this->set_field(
            'blogposts_activity_title_after_action_text',
            __('Append title after action text', 'peepsoblogposts'),
            'yesno_switch'
        );

		$privacy = PeepSoPrivacy::get_instance();
		$privacy_settings = apply_filters('peepso_privacy_access_levels', $privacy->get_access_settings());

		$options = array();

		foreach($privacy_settings as $key => $value) {
		    if(in_array($key, array(30,40))) { continue; }
			$options[$key] = $value['label'];
		}

		$this->args('options', $options);

		$this->set_field(
			'blogposts_activity_privacy',
			__('Default privacy', 'peepsoblogposts'),
			'select'
		);

        // Comment integration

		$this->args('descript', __('Replaces WordPress comments with PeepSo comments and likes/reactions.','peepsoblogposts'));

        $this->set_field(
            'blogposts_comments_enable',
            __('Comments integration', 'peepsoblogposts'),
            'yesno_switch'
        );


        // Header - call to action
        $this->set_field(
            'blogposts_comments_header_call_to_action',
            'Call to action',
            'text'
        );


        // Header - likes or reactions

        if(class_exists('PeepSoReactions2')) {
            $this->set_field(
                'blogposts_comments_header_reactions',
                'Header (reactions)',
                'text'
            );
        } else {
            $this->set_field(
                'blogposts_comments_header_likes',
                'Header (likes)',
                'text'
            );
        }

        // Header - comments


        $this->set_field(
            'blogposts_comments_header_comments',
            'Header (comments)',
            'text'
        );


        $this->set_group(
			'blogposts_general',
			__('Activity Stream', 'peepsoblogposts')
		);
	}
}