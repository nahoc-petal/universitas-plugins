<?php
/**
 * Plugin Name: PeepSo Extras: BlogPosts
 * Plugin URI: https://peepso.com
 * Description: Display a list of user Blog Posts in their profile and post to Activity when a new post is published
 * Author: PeepSo
 * Author URI: https://peepso.com
 * Version: 1.10.0
 * Copyright: (c) 2016 PeepSo, Inc. All Rights Reserved.
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: peepsoblogposts
 * Domain Path: /language
 *
 * We are Open Source. You can redistribute and/or modify this software under the terms of the GNU General Public License (version 2 or later)
 * as published by the Free Software Foundation. See the GNU General Public License or the LICENSE file for more details.
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.
 */

class PeepSoBlogPosts
{
	private static $_instance = NULL;

	const PLUGIN_NAME	 = 'Extras: Blog Posts';
	const PLUGIN_SLUG 	 = 'blogposts';
	const PLUGIN_EDD 	 = 79603;
	const PLUGIN_VERSION = '1.10.0';
	const PLUGIN_RELEASE = ''; //ALPHA1, BETA1, RC1, '' for STABLE

	// DO NOT rename these - this is how our wp_post entries are recognized
	const MODULE_ID = 6661;
	const SHORTCODE = 'peepso_postnotify';

    const ICON = 'https://www.peepso.com/wp-content/plugins/peepso.com-checkout/assets/icons/blogposts_icon.svg';

	// post types that are known to wreck havoc when enabled
	private static $post_types_blacklist = array(
		'peepso-post',
		'peepso-message',
		'peepso-comment',
		'peepso_user_field',
	);

	private function __construct()
	{
		add_action('peepso_init', array(&$this, 'init'));
		add_filter('peepso_all_plugins', array($this, 'peepso_filter_all_plugins'));
        add_action('plugins_loaded', array(&$this, 'load_textdomain'));

		if (is_admin()) {
			add_action('admin_init', array(&$this, 'peepso_check'));
			add_filter('peepso_license_config', array(&$this, 'peepso_filter_license_config'), 666);
			add_action('peepso_config_before_save-site', array(&$this, 'peepso_filter_before_save_site'));
            add_action('peepso_config_after_save-blogposts', array(&$this, 'rebuild_cache'));
		}

		add_action( 'wp_ajax_peepsoblogposts_user_posts', array(&$this,'ajax_user_posts') );
		add_action( 'wp_ajax_nopriv_peepsoblogposts_user_posts', array(&$this,'ajax_user_posts') );

		register_activation_hook(__FILE__, array(&$this, 'activate'));
	}

	/**
	 * Singleton instance
	 * @return null|PeepSoBlogPosts
	 */
	public static function get_instance()
	{
		if (NULL === self::$_instance) {
			self::$_instance = new self();
		}
		return (self::$_instance);
	}

    /**
     * Loads the translation file for the plugin
     */
    public function load_textdomain()
    {
        $path = str_ireplace(WP_PLUGIN_DIR, '', dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'language' . DIRECTORY_SEPARATOR;
        load_plugin_textdomain('peepsoblogposts', FALSE, $path);
    }
    
	/**
	 * Init hooks
	 */
	public function init()
	{
		// Run activation in case of version number change
		if( $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE != get_transient($trans = 'peepso_'.$this::PLUGIN_SLUG.'_version')) {
			// activate returns false in case of missing license
			if($this->activate()) {
				set_transient($trans, $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE);
			}
		}

		// Autoload
		PeepSo::add_autoload_directory(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR);

        PeepSoTemplate::add_template_directory(PeepSo::get_peepso_dir().'overrides/');
        PeepSoTemplate::add_template_directory(plugin_dir_path(__FILE__));

        // Hooks
        if (is_admin()) {
            add_action('admin_init', array(&$this, 'peepso_check'));
            add_action('admin_enqueue_scripts', array(&$this, 'enqueue_scripts_admin'));
            add_filter('peepso_admin_config_tabs', array(&$this, 'admin_config_tabs'));
        } else {

            // Check license
            if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
                return false;
            }

            // Enqueue frontend JS & CSS
            add_action('wp_enqueue_scripts', array(&$this, 'enqueue_scripts'));

            // Activity Stream item - User X "wrote a Z" text
            add_filter('peepso_activity_stream_action', array(&$this, 'activity_stream_action'), 10, 2);

            // Activity Item parser - include the embed
            add_filter('peepso_activity_content', array(&$this, 'filter_the_content_activity'),1,2);


            // "Blog Posts" profile section
            if(PeepSo::get_option('blogposts_profile_enable', 0)) {
                // Profile segment renderer
                add_action('peepso_profile_segment_blogposts', array(&$this, 'peepso_profile_segment_blogposts'));

                // @todo what is this
                add_filter('peepso_rewrite_profile_pages', array(&$this, 'peepso_rewrite_profile_pages'));

                // limit privacy settings
                add_filter('peepso_privacy_access_levels', array(&$this, 'filter_privacy_access_levels'), 100);

            }

            // attach comments and likes to WP posts
            if(PeepSo::get_option('blogposts_authorbox_enable', FALSE) && PeepSo::get_option('blogposts_profile_enable', FALSE)) {
                add_filter('the_content', array($this, 'filter_the_content_blogpost_authorbox'));
            }

            if(PeepSo::get_option('blogposts_comments_enable', FALSE)) {
                add_filter('comments_template', function($theme_template) {
                    global $wp_query;
                    $wp_query->comments = array();
                    $wp_query->comment_count = 0;

                    remove_post_type_support('post', 'comments');
                    add_filter('comments_array', function () { return array(); });
                    add_filter('pings_open', function () { return FALSE; });
                    return $theme_template;
                });
                add_filter('comments_open', function($open, $post_id) {
                    global $post;
                    if (!in_array($post->post_type, array('post', 'page'))) {
                        return $open;
                    }
                    // if called from comment_form() function
                    foreach (debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS) as $caller) {
                        if ($caller['function'] == 'comment_form') {
                            return FALSE;
                        }
                    }

                    return TRUE;
                }, 10, 2);
                add_action('comment_form_comments_closed',array($this, 'filter_the_content_blogpost'));

                add_filter('get_the_excerpt', array(&$this, 'filter_the_excerpt_blogpost'));
                add_filter('get_comments_number', function($count, $post_id) {

                    $post = get_post($post_id);

                    // This step REQUIRES an existing activity entry
                    if(FALSE !== $this->publish_post($post->ID, $post)) {
                        $count = $this->comment_count($post_id);
                    }

                    return $count;
                },1,2);
            }


            add_filter('peepso_post_filters', array(&$this, 'post_filters'), 10,1);
        }

        if(PeepSo::get_option('blogposts_profile_enable', 0)) {
            // Profile segment menu item
            add_filter('peepso_navigation_profile', array(&$this, 'filter_peepso_navigation_profile'));
        }

        // Make sure DB is cleaned up when our Activity Stream item is deleted
        add_filter('peepso_delete_content', function($id) {
            global $wpdb;
            $wpdb->delete($wpdb->prefix.'postmeta', array('meta_value'=>$id, 'meta_key'=>self::SHORTCODE));
            $wpdb->delete($wpdb->prefix.PeepSoActivity::TABLE_NAME, array('act_external_id'=>$id, 'act_module_id'=>self::MODULE_ID));
        });

        // Register actions for each post type
        $post_types = PeepSoBlogPosts::get_post_types();

        foreach($post_types as $post_type) {
            add_action( 'publish_'.$post_type, array(&$this, 'publish_post'), 1, 2 );
        }
    }

    private function comment_count($post_id)
    {
        if($count = get_transient($trans = 'peepso_blogposts_comments_'.$post_id)) { return $count; }

        global $wpdb;

        $r = $wpdb->get_row("SELECT `act_id`, `act_external_id`, `act_module_id` FROM ".$wpdb->prefix.PeepSoActivity::TABLE_NAME."  WHERE `act_module_id`=".$this::MODULE_ID." AND `act_external_id`=".get_post_meta($post_id, self::SHORTCODE, TRUE));

        $act_external_id = $r->act_external_id;
        $act_module_id = $r->act_module_id;

        // Comments attached to the main post
        $q = "SELECT act_external_id, act_module_id from " . $wpdb->prefix . PeepSoActivity::TABLE_NAME
            . " WHERE act_comment_object_id=$act_external_id "
            ." AND act_comment_module_id=$act_module_id";

        $r = $wpdb->get_results($q);

        $count = 0;
        if(count($r)) {
            foreach($r as $comment) {
                $count++;

                $act_external_id = $comment->act_external_id;
                $act_module_id = $comment->act_module_id;

                // Comments attached to the main post
                $q = "SELECT count(act_id) as subcomments from " . $wpdb->prefix . PeepSoActivity::TABLE_NAME
                    . " WHERE act_comment_object_id=$act_external_id "
                    ." AND act_comment_module_id=$act_module_id";

                $count += $wpdb->get_row($q)->subcomments;
            }
        }

        // cache it for post_id
        set_transient($trans, $count, 15);
        return $count;
    }

    public function filter_the_excerpt_blogpost( $content )
    {
        if(! in_the_loop()) { return $content; }
        if(! is_singular()) { return $content; }
        if(! is_single()) { return $content; }
        if(! is_main_query()) { return $content; }

        global $post;

        // This step REQUIRES an existing activity entry
        if( FALSE !== $this->publish_post($post->ID, $post)) {

            // completely disable and hide native WP comments
            remove_post_type_support('post', 'comments');
            add_filter('comments_array', function () { return array(); });
            add_filter('comments_open', function () { return FALSE; });
            add_filter('pings_open', function () { return FALSE; });
        }

        return $content;
    }

    public function filter_the_content_blogpost_authorbox($content)
    {
        if(! in_the_loop()  )   { return $content; }
        if(! is_singular()  )   { return $content; }
        if(! is_single()    )   { return $content; }
        if(! is_main_query())   { return $content; }
        if(  is_embed()     )   { return $content; }

        global $post;
        if($post->post_type != 'post') { return $content; }

        return $content . PeepSoTemplate::exec_template('blogposts','author_box', array('author' => PeepSoUser::get_instance($post->post_author)), TRUE);
    }

    public function filter_the_content_blogpost()
    {
        if(! is_single()) { return; }

        global $post;
        global $wpdb;

        $peepso_actions ='';
        $peepso_comments = '';
        $peepso_wrapper = '';

        // This step REQUIRES an existing activity entry
        if(FALSE !== $this->publish_post($post->ID, $post)) {

            // completely disable and hide native WP comments
            remove_post_type_support('post', 'comments');

            add_filter('comments_array', function () { return array(); });
            add_filter('comments_open', function () { return FALSE; });
            add_filter('pings_open', function () { return FALSE; });

            // $act_external_id - ID of post representing the stream activity
            $act_external_id = get_post_meta($post->ID, self::SHORTCODE, TRUE);

            if($act_external_id==0 || $act_external_id==1 ||  !is_numeric($act_external_id)) {

                // extract act_id from wp_posts by searching for the serialized data
                $search = '{"post_id":'.$post->ID.',';

                $q = "SELECT ID FROM {$wpdb->prefix}posts WHERE `post_content` LIKE '%$search%'";
                $r = $wpdb->get_row($q);

                $act_external_id = (int) $r->ID;

                // update postmeta with new value so we don't have to search again
                update_post_meta($post->ID, self::SHORTCODE, $act_external_id);
            }

            // don't modify content in the embed
            if(is_embed()) { return; }

            // stash the original post object
            $post_old = $post;

            // post object representing the stream item
            $post = get_post($act_external_id);

            // if post can't be found
            // probably it was deleted and there is orphan data in peepso_activities and postmeta
            if(!$post) {
                ob_start();
                echo ' <br/><br/> '.__('Can\'t load comments and likes. Try refreshing the page or contact the Administrators.','peepsoblogposts');

                $wpdb->delete($wpdb->prefix.'postmeta', array('meta_value'=>$act_external_id, 'meta_key'=>self::SHORTCODE));
                $wpdb->delete($wpdb->prefix.PeepSoActivity::TABLE_NAME, array('act_external_id'=>$act_external_id, 'act_module_id'=>self::MODULE_ID));

                return ob_get_clean();
            }

            $PeepSoActivity = new PeepSoActivity();

            // act_id - id of the item in peepso_activities representing the stream item
            $r = $wpdb->get_row("SELECT act_id FROM ".$wpdb->prefix.$PeepSoActivity::TABLE_NAME." WHERE act_module_id=".$this::MODULE_ID." and act_external_id=$act_external_id");
            $act_id = $r->act_id;

            $post->act_id = $act_id;
            $post->act_module_id = self::MODULE_ID;
            $post->act_external_id = $act_external_id;

            // PEEPSO WRAPPER
            ob_start();

            $data = array(
                'header'            => PeepSo::get_option('blogposts_comments_header_call_to_action'),
                'header_comments'   => PeepSo::get_option('blogposts_comments_header_comments'),
            );

            $data['header_actions'] = (class_exists('PeepSoReactions2')) ? PeepSo::get_option('blogposts_comments_header_reactions') : PeepSo::get_option('blogposts_comments_header_likes');

            if(is_user_logged_in()) {
                PeepSoTemplate::exec_template('blogposts','peepso_wrapper', $data);
            } else {
                PeepSoTemplate::exec_template('blogposts','peepso_wrapper_guest', $data);
            }
            $peepso_wrapper = '<div id="peepso-wrap">' . ob_get_clean() . '</div>';

            // POST ACTIONS
            ob_start();
            add_action('peepso_activity_post_actions', function( $args ){ return array('post'=>$args['post'],'acts'=>array('like'=>$args['acts']['like']));}, 20);
            ?>
            <div class="ps-stream-actions stream-actions" data-type="stream-action"><?php $PeepSoActivity->post_actions(); ?></div>

            <?php
            if(!class_exists('PeepSoReactions2')) {

                if ($likes = $PeepSoActivity->has_likes($act_id)) { ?>
                    <div id="act-like-<?php echo $act_id; ?>"
                         class="ps-stream-status cstream-likes ps-js-act-like--<?php echo $act_id; ?>"
                         data-count="<?php echo $likes ?>">
                        <?php $PeepSoActivity->show_like_count($likes); ?>
                    </div>
                <?php } else { ?>
                    <div id="act-like-<?php echo $act_id; ?>"
                         class="ps-stream-status cstream-likes ps-js-act-like--<?php echo $act_id; ?>" data-count="0"
                         style="display:none"></div>
                <?php }
            }

            do_action('peepso_post_before_comments');
            $peepso_actions = ob_get_clean();

            // POST COMMENTS
            ob_start();
            $PeepSoActivity->show_recent_comments();
            $comments = ob_get_clean();

            ob_start();

            $show_commentsbox = apply_filters('peepso_commentsbox_display', apply_filters('peepso_permissions_comment_create', is_user_logged_in()), $post->ID);

            // show "no comments yet" only if the user can't make a new one
            if(!strlen($comments) && !$show_commentsbox) {
                ?>
                <div class="ps-no-comments-container--<?php echo $act_id; ?>">
                    <?php echo __('No comments yet', 'peepsoblogposts');?>
                </div>
                <?php
            }

            ?>
            <div class="ps-comments--blogpost ps-comment-container comment-container ps-js-comment-container ps-js-comment-container--<?php echo $act_id; ?>" data-act-id="<?php echo $act_id; ?>">
                <?php echo $comments;  ?>
            </div>
            <?php
            if (is_user_logged_in() && $show_commentsbox ) {
                $PeepSoUser = PeepSoUser::get_instance();
                ?>

                <div id="act-new-comment-<?php echo $act_id; ?>" class="ps-comments--blogpost ps-comment-reply cstream-form stream-form wallform ps-js-newcomment-<?php echo $act_id; ?> ps-js-comment-new" data-type="stream-newcomment" data-formblock="true">
                    <a class="ps-avatar cstream-avatar cstream-author" href="<?php echo $PeepSoUser->get_profileurl(); ?>">
                        <img data-author="<?php echo $post->post_author; ?>" src="<?php echo $PeepSoUser->get_avatar(); ?>" alt="" />
                    </a>
                    <div class="ps-textarea-wrapper cstream-form-input">
				<textarea
                        data-act-id="<?php echo $act_id;?>"
                        class="ps-textarea cstream-form-text"
                        name="comment"
                        oninput="return activity.on_commentbox_change(this);"
                        placeholder="<?php _e('Write a comment...', 'peepsoblogposts');?>"></textarea>
                        <?php
                        // call function to add button addons for comments
                        $PeepSoActivity->show_commentsbox_addons();
                        ?>
                    </div>
                    <div class="ps-comment-send cstream-form-submit" style="display:none;">
                        <div class="ps-comment-loading" style="display:none;">
                            <img src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>" alt="" />
                            <div> </div>
                        </div>
                        <div class="ps-comment-actions" style="display:none;">
                            <button onclick="return activity.comment_cancel(<?php echo $act_id; ?>);" class="ps-btn ps-button-cancel"><?php _e('Clear', 'peepsoblogposts'); ?></button>
                            <button onclick="return activity.comment_save(<?php echo $act_id; ?>, this);" class="ps-btn ps-btn-primary ps-button-action" disabled><?php _e('Post', 'peepsoblogposts'); ?></button>
                        </div>
                    </div>
                </div>

            <?php }

            $peepso_comments = ob_get_clean();

            // restore original post object
            $post = $post_old;
        }

        $from = array(
            '{peepso_comments}',
            '{peepso_actions}',
        );

        $to = array(
            $peepso_comments,
            $peepso_actions,
        );

        echo str_ireplace($from, $to, $peepso_wrapper);
    }

    /* * * NAVIGATION & PROFILE SEGMENT * * */

    /**
     * create a menu item in the PeepSo profile segments menu
     *
     * @param $links
     * @return mixed
     */
    public function filter_peepso_navigation_profile($links)
    {
        $user_id = isset($links['_user_id']) ? $links['_user_id'] : get_current_user_id();

        if(PeepSo::get_option('blogposts_profile_hideempty', 0) && !count_user_posts($user_id)) {
            return $links;
        }

        $links['blogposts'] = array(
            'href' => 'blogposts',
            'label'=> __('Blog Posts', 'peepsoblogposts'),
            'icon' => 'ps-icon-file-text'
        );

        return $links;
    }

    /**
     * render the Blogposts profile segment
     *
     * @return void
     */
    public function peepso_profile_segment_blogposts()
    {
        // Get the currently viewed User ID from PeepSoProfileShortcode and exec template
        $pro = PeepSoProfileShortcode::get_instance();
        $this->view_user_id = PeepSoUrlSegments::get_view_id($pro->get_view_user_id());

        if($this->view_user_id == get_current_user_id()) {
            $PeepSoUser = PeepSoUser::get_instance();

            $PeepSoUrlSegments = new PeepSoUrlSegments();
            $create_tab = ('create' == $PeepSoUrlSegments->get(3));

            if($create_tab) {

                $permalink = get_permalink();
                add_filter( 'page_link', function($link, $id, $sample ) use ($PeepSoUrlSegments, $permalink) {
                    return $permalink . $PeepSoUrlSegments->get(1) . '/' . $PeepSoUrlSegments->get(2) . '/' . $PeepSoUrlSegments->get(3) . '/';
                }, 99, 3);

                echo PeepSoTemplate::exec_template('blogposts', 'blogposts_create', array('view_user_id' => $this->view_user_id, 'create_tab' => TRUE), TRUE);
                return;
            }
        }

        echo PeepSoTemplate::exec_template('blogposts', 'blogposts', array('view_user_id' => $this->view_user_id), TRUE);
    }

    /**
     * @todo not sure what this does
     *
     * @param $pages
     * @return array
     */
    public function peepso_rewrite_profile_pages($pages)
    {
        return array_merge($pages, array('posts'));
    }


    /**
     * Build AJAX response with user blog posts
     */
    public function ajax_user_posts()
    {
        ob_start();

        $input = new PeepSoInput();
        $owner = $input->int('user_id');
        $page  = $input->int('page', 1);

        $sort  = $input->val('sort', 'desc');

        $limit = 10;
        $offset = ($page - 1) * $limit;

        if ($page < 1) {
            $page = 1;
            $offset = 0;
        }

        $args = array(
            'author'        => $owner,
            'orderby'       => 'post_date',
            'post_status'	=> 'publish',
            'order'         => $sort,
            'posts_per_page'=> $limit,
            'offset'		=> $offset,
        );

        // Count published posts
        $count_posts = wp_count_posts();
        $count_blogposts = $count_posts->publish;

        // Get the posts
        $blogposts=get_posts($args);

        $force_strip_shortcodes = PeepSo::get_option('blogposts_profile_content_force_strip_shortcodes', 0);

        if (count($blogposts)) {
            // Iterate posts
            foreach ($blogposts as $post) {

                // Choose between excerpt or post_content
                // @todo is there a more elegant way?
                $post_content = get_the_excerpt($post->ID);

                if(!strlen($post_content)) {
                    $post_content = $post->post_content;
                }

                $post_content = strip_shortcodes($post_content);

                if($force_strip_shortcodes) {
                    $post_content = preg_replace('/\[.*?\]/', '', $post_content);
                }

                $limit = intval(PeepSo::get_option('blogposts_profile_content_length',50));
                $post_content = wp_trim_words($post_content, $limit,'&hellip;');

                if(0 == $limit) {
                    $post_content = FALSE;
                }

                PeepSoTemplate::exec_template('blogposts', 'blogpost', array('post_content' => $post_content, 'post' => $post));
            }

            $resp['success']		= 1;

            $resp['html']			= ob_get_clean();
        } else {
            $message =  (get_current_user_id() == $owner) ? __('You have no blog posts yet', 'peepsoblogposts') : sprintf(__('%s has no blog posts yet', 'peepsoblogposts'), PeepSoUser::get_instance($owner)->get_firstname());
            $resp['success']		= 0;
            $resp['error'] = PeepSoTemplate::exec_template('profile','no-results-ajax', array('message' => $message), TRUE);
        }

        $resp['page']			= $page;
        $resp['found_blogposts']= abs($count_blogposts - $page * $limit);
        header('Content-Type: application/json');
        echo json_encode($resp);
        exit(0);
    }

    /* * *  UTILITIES * * */

    /**
     * enqueue JS  & CSS
     *
     * @return void
     */
    public function enqueue_scripts()
    {
        // dynamic CSS
        $css = 'plugins/blogposts/blogposts-'.get_transient('peepso_blogposts_css').'.css';
        if(!file_exists(PeepSo::get_peepso_dir().$css) ) {
            $this->rebuild_cache();
            $css = 'plugins/blogposts/blogposts-'.get_transient('peepso_blogposts_css').'.css';
        }

        wp_enqueue_style('peepso-blogposts-dynamic', PeepSo::get_peepso_uri().$css, array(), self::PLUGIN_VERSION, 'all');

        wp_enqueue_script('peepso-blogposts', plugin_dir_url(__FILE__) . 'assets/js/bundle.min.js',
            array('peepso', 'peepso-page-autoload'), self::PLUGIN_VERSION, TRUE);
    }

    /**
     * enqueue JS  & CSS on admin page
     *
     * @return void
     */
    public function enqueue_scripts_admin()
    {
        wp_enqueue_script('peepso-blogposts-admin',
            plugin_dir_url(__FILE__) . 'assets/js/admin.js',
            array('peepso'), self::PLUGIN_VERSION,
            TRUE
        );
    }

    /**
     * return all post types without the blacklisted ones
     *
     * @return array
     */
    public static function get_post_types()
    {
        return array_diff(get_post_types(), self::$post_types_blacklist);
    }

    /* * * ACTIVITY STREAM * * */

    /**
     * create an Activity Stream item when a new post is published
     *
     * @param int 		$ID
     * @param WP_Post 	$post
     * @return bool (FALSE - posting, post type disabled/blacklisted, TRUE - success, NULL - already added)
     */
    function publish_post( $ID, $post ) {

        // is this a regular post?
        if('post' != $post->post_type) 			                                            {	return( FALSE );	}

        // is the post published?
        if(!in_array($post->post_status,  array('publish')))         			            {	return( FALSE );	}

        // is activity posting enabled?
        if(0 == PeepSo::get_option('blogposts_activity_enable', 0 )) 			{	return( FALSE );	}

        // is this post type enabled?
        // if(!PeepSo::get_option('blogposts_activity_type_'.$post->post_type, 0)) {	return( FALSE );	}

        // double check against the blacklist
        if(in_array($post->post_type,  self::$post_types_blacklist)) 			            {	return( FALSE );	}

        // check if it's not marked as already posted to activity and has valid act_id
        $act_id = get_post_meta($ID, self::SHORTCODE, TRUE);
        if(strlen($act_id) && is_numeric($act_id) && 0 < $act_id) 				            {	return( NULL );	}

        // author is not always the current user - ie when admin publishes a post written by someone else
        $author_id = $post->post_author;

        // skip blacklisted author IDs
        $blacklist = array();
        if(in_array($author_id, $blacklist))                                                {   return( FALSE );    }

        // build JSON to be used as post content for later display
        $content = array(
            'post_id' => $ID,
            'post_type' => $post->post_type,
            'shortcode' => self::SHORTCODE,
            'permalink' => get_permalink($ID),
        );

        $extra = array(
            'module_id' => self::MODULE_ID,
            'act_access'=> PeepSo::get_option('blogposts_activity_privacy',PeepSoUser::get_instance($author_id)->get_profile_accessibility()),
            'post_date'		=> $post->post_date,
            'post_date_gmt' => $post->post_date_gmt,
        );

        $content=json_encode($content);

        // create an activity item
        $act = PeepSoActivity::get_instance();
        $act_id = $act->add_post($author_id, $author_id, $content, $extra);

        update_post_meta($act_id, '_peepso_display_link_preview', 0);
        delete_post_meta($act_id, 'peepso_media');

        // mark this post as already posted to activity
        add_post_meta($ID, self::SHORTCODE, $act_id, TRUE);

        return TRUE;
    }

    /**
     * define the "action text" depending on post type eg "published a page"
     *
     * @param $action
     * @param $post
     * @return string
     */
    public function activity_stream_action($action, $post)
    {
        if (self::MODULE_ID === intval($post->act_module_id)) {

            $action = PeepSo::get_option('blogposts_activity_type_post_text_default');

            $content = strip_tags(get_post_field('post_content', $post, 'raw'));
            if($target_post = json_decode($content)) {
                $key_text = 'blogposts_activity_type_'.$target_post->post_type.'_text';
                $action = PeepSo::get_option($key_text, $action);

                if(1==PeepSo::get_option('blogposts_activity_title_after_action_text',0)) {
                    $wp_post = get_post($target_post->post_id);

                    $action .= sprintf(' <a class="ps-blogposts-action-title" href="%s">%s</a>', get_the_permalink($wp_post->ID), $wp_post->post_title);

                }
            }
        }

        return ($action);
    }


    /**
     * parse the activity item JSON to force a nice embed
     *
     * @param $content
     * @param null $post
     * @return string
     */
    public function filter_the_content_activity( $content, $post = NULL )
    {
        if(!stristr($content, self::SHORTCODE)) {
            return $content;
        }

        $content = strip_tags(get_post_field('post_content', $post, 'raw'));

        if($target_post = json_decode($content)) {
            $content = get_permalink($target_post->post_id);
            $content = apply_filters('the_content', $content);
        }

        global $post;
        update_post_meta($post->ID, '_peepso_display_link_preview', 0);
        delete_post_meta($post->ID, 'peepso_media');

        return $content;
    }

    /**
     * Disable repost
     *
     * @param array $actions The default options per post
     * @return  array
     */
    public function filter_activity_post_actions($actions) {
        if ($actions['post']->act_module_id == self::MODULE_ID) {
            unset($actions['acts']['repost']);
        }
        return $actions;
    }

    /**
     * Disable "friends" and "only me" privacy
     *
     * @param array $actions The default options per post
     * @return  array
     */
    public function filter_privacy_access_levels($levels) {

        global $post;

        if(stristr($post->post_content, self::SHORTCODE)) {
            unset($levels[30]);
            unset($levels[40]);
        }

        return $levels;
    }


    /**
     * modify onclick handler delete post for album type post
     * @param array $options
     * @return array $options
     */
    public function post_filters($options) {
        global $post;
        
        if (self::MODULE_ID === intval($post->act_module_id)) {

            // unset capability for editing post
            if (isset($options['edit'])) {
                unset($options['edit']);
            }
        }


        return $options;
    }
    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * PEEPSO CONFIG, PEEPSO COMPATIBILITY, PLUGIN ACTIVATION */

    public function activate()
    {
        if (!$this->peepso_check()) {
            return (FALSE);
        }

        require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'activate.php');
        $install = new PeepSoBlogPostsInstall();
        $res = $install->plugin_activation();
        if (FALSE === $res) {
            // error during installation - disable
            deactivate_plugins(plugin_basename(__FILE__));
        }

        return (TRUE);
    }

    public function admin_config_tabs( $tabs )
    {
        $tabs['blogposts'] = array(
            'label' => __('Blog Posts', 'peepsoblogposts'),
            'icon' => self::ICON,
            'tab' => 'blogposts',
            'description' => __('Example Config Tab', 'peepsoblogposts'),
            'function' => 'PeepSoConfigSectionBlogPosts',
            'cat'   => 'extras',
        );

        return $tabs;
    }

    /**
     * Check if PeepSo class is present (ie the PeepSo plugin is installed and activated)
     * If there is no PeepSo, immediately disable the plugin and display a warning
     * @return bool
     */
    public function peepso_check()
    {
        if (!class_exists('PeepSo')) {
            add_action('admin_notices', array(&$this, 'peepso_disabled_notice'));
            unset($_GET['activate']);
            deactivate_plugins(plugin_basename(__FILE__));
            return (FALSE);
        }

        // PeepSo.com license check
        if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
            add_action('admin_notices', array(&$this, 'license_notice'));
        }

        if (isset($_GET['page']) && 'peepso_config' == $_GET['page'] && !isset($_GET['tab'])) {
            add_action('admin_notices', array(&$this, 'license_notice_forced'));
        }

        // PeepSo.com new version check
        // since 1.7.6
        if(method_exists('PeepSoLicense', 'check_updates_new')) {
            PeepSoLicense::check_updates_new(self::PLUGIN_EDD, self::PLUGIN_SLUG, self::PLUGIN_VERSION, __FILE__);
        }

        return (TRUE);
    }

    public function license_notice()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG);
    }

    public function license_notice_forced()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG, true);
    }

    /**
     * Display a message about PeepSo not present
     */
    public function peepso_disabled_notice()
    {
        ?>
        <div class="error peepso">
            <strong>
                <?php echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'peepsoblogposts'), self::PLUGIN_NAME);?>
            </strong>
        </div>
        <?php
    }

    /**
     * Hook into PeepSo for compatibility checks
     * @param $plugins
     * @return mixed
     */
    public function peepso_filter_all_plugins($plugins)
    {
        $plugins[plugin_basename(__FILE__)] = get_class($this);
        return $plugins;
    }

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  LICENSING, VERSION CHECK, UPDATES */

    /**
     * Called before PeepSo saves the "site" config page
     * Deletes the cached license in order to forcefully revalidate
     */
    public function peepso_filter_before_save_site()
    {
        PeepSoLicense::delete_transient(self::PLUGIN_SLUG);
    }

    /**
     * Adds the license key information to the config metabox
     * @param array $list The list of license key config items
     * @return array The modified list of license key items
     */
    public function peepso_filter_license_config($list)
    {
        $data = array(
            'plugin_slug' => self::PLUGIN_SLUG,
            'plugin_name' => self::PLUGIN_NAME,
            'plugin_edd' => self::PLUGIN_EDD,
            'plugin_version' => self::PLUGIN_VERSION
        );
        $list[] = $data;
        return ($list);
    }

    /* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *  CSS CACHE */
    public function rebuild_cache()
    {
        // Directory where CSS files are stored
        $path = PeepSo::get_peepso_dir().'plugins'.DIRECTORY_SEPARATOR.'blogposts'.DIRECTORY_SEPARATOR;

        if (!file_exists($path) ) {
            @mkdir($path, 0755, TRUE);
        }

        // Try to remove the old file
        $old_file = $path.'blogposts-'.get_transient('peepso_blogposts_css').'.css';
        @unlink($old_file);

        // New cache
        delete_option('peepso_blogposts_css');
        set_transient('peepso_blogposts_css', time());

        $image_height = intval(PeepSo::get_option('blogposts_profile_featured_image_height', 150));
        $box_height = intval(PeepSo::get_option('blogposts_profile_two_column_height', 350));

        if($image_height < 1) {
            $image_height = 1;
        }

        if($box_height < 1 || !PeepSo::get_option('blogposts_profile_two_column_enable', 1)) {
            $box_height = 'auto';
        }

        // @todo cache this
        ob_start();
        ?>
        .ps-blogposts__post-image {
        height: <?php echo $image_height;?>px;
        }

        .ps-blogposts__post-image--left,
        .ps-blogposts__post-image--right {
        width: <?php echo $image_height;?>px;
        }

        .ps-blogposts__post {
        height: <?php echo $box_height;?>px;
        }
        <?php
        $css = ob_get_clean();

        update_option('peepso_blogposts_css', $css);



        $file = $path.'blogposts-'.get_transient('peepso_blogposts_css').'.css';
        $h = fopen( $file, "a" );
        fputs( $h, $css );
        fclose( $h );
    }
}

PeepSoBlogPosts::get_instance();

// EOF
