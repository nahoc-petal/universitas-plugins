jQuery(function( $ ) {

	var $cbProfile = $( 'input[name=blogposts_profile_enable]' ),
		$cbAuthorbox = $( 'input[name=blogposts_authorbox_enable]' ),
		$cbActivity = $( 'input[name=blogposts_activity_enable]' ),
		$cbComment = $( 'input[name=blogposts_comments_enable]' );

	// Handle enable profile checkbox.
	$cbProfile.on( 'click', function() {
		var $box = $( this ).closest( '.postbox' ),
			$fields = $box.find( 'input[name], select[name], textarea[name]' ).not( this ).closest( '.form-group' ),
			$siblingBoxes = $box.siblings( '.postbox' );

		if ( this.checked ) {
			$siblingBoxes.show();
			$fields.show();
            $('#field_blogposts_submissions_header').show();
			$cbAuthorbox.triggerHandler( 'click' );
		} else {
			$fields.hide();
            $('#field_blogposts_submissions_header').hide();
			$siblingBoxes.hide();
		}
	});

	// Handle enable authorbox checkbox.
	$cbAuthorbox.on( 'click', function() {
		var $input = $( 'input[name=blogposts_authorbox_author_name_pre_text]' ),
			$wrapper = $input.closest( '.form-group' );

		if ( this.checked ) {
			$wrapper.show()
		} else {
			$wrapper.hide();
		}
	});

	// Handle enable activity checkbox.
	$cbActivity.on( 'click', function() {
		var $box = $( this ).closest( '.postbox' ),
			$fields = $box.find( 'input[name], select[name], textarea[name]' ).not( this ).closest( '.form-group' ),
			$siblingBoxes = $box.siblings( '.postbox' );

		if ( this.checked ) {
			$fields.show();
			$siblingBoxes.show();
			$cbComment.triggerHandler( 'click' );
		} else {
			$fields.hide();
			$siblingBoxes.hide();
		}
	});

	// Handle enable comment checkbox.
	$cbComment.on( 'click', function() {
		var $cta = $( 'input[name=blogposts_comments_header_call_to_action]' ).closest( '.form-group' ),
			$ha = $( 'input[name=blogposts_comments_header_reactions]' ).closest( '.form-group' ),
			$hc = $( 'input[name=blogposts_comments_header_comments]' ).closest( '.form-group' ),
			$wrappers = $cta.add( $ha ).add( $hc );

		if ( this.checked ) {
			$wrappers.show()
		} else {
			$wrappers.hide();
		}
	});

	// Set initial visibility.
	$cbProfile.triggerHandler( 'click' );
	$cbActivity.triggerHandler( 'click' );

});
