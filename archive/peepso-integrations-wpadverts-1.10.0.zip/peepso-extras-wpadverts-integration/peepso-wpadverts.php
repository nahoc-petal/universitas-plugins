<?php
/**
 * Plugin Name: PeepSo Integrations: WPAdverts
 * Plugin URI: https://peepso.com
 * Description: Integrate WPAdverts  with PeepSo
 * Tags: peepso, wpadverts, integration
 * Author: PeepSo
 * Version: 1.10.0
 * Author URI: https://peepso.com
 * Copyright: (c) 2015 PeepSo, Inc. All Rights Reserved.
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: peepso-wpadverts
 * Domain Path: /language
 *
 * We are Open Source. You can redistribute and/or modify this software under the terms of the GNU General Public License (version 2 or later)
 * as published by the Free Software Foundation. See the GNU General Public License or the LICENSE file for more details.
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.
 */

class PeepSoWPAdverts {

    private static $_instance = NULL;

    const PLUGIN_EDD = '607967';
    const PLUGIN_SLUG = 'PeepSo-WPAdverts';

    const PLUGIN_NAME    = 'Monetization: WPAdverts';
    const PLUGIN_VERSION = '1.10.0';
    const PLUGIN_RELEASE = ''; //ALPHA1, BETA1, RC1, '' for STABLE
    const MODULE_ID      = 1002;

    const PLUGIN_DIR_PATH = '';

    // post meta key for photo type (avatar/cover)
    const POST_META_KEY_WPADVERTS_TYPE          = '_peepso_wpadverts_type';
    const POST_META_KEY_WPADVERTS_TYPE_CLASSIFIEDS   = '_peepso_wpadverts_type_classifieds';
    const POST_META_KEY_WPADVERTS_CLASSIFIEDS_ID     = '_peepso_wpadverts_classifieds_id';

    const ICON = 'https://www.peepso.com/wp-content/plugins/peepso.com-checkout/assets/icons/wpadverts_icon.svg';

    public $shortcodes= array(
        'peepso_wpadverts' => 'PeepSoWPAdvertsShortcode::shortcode_wpadverts',
    );

    private function __construct() {

        add_action('peepso_init', array(&$this, 'init'));
        add_action('plugins_loaded', array(&$this, 'load_textdomain'));

        if (is_admin()) {
			add_action('admin_init', array(&$this, 'wpadverts_check'));
            add_action('admin_init', array(&$this, 'peepso_check'));

            // licensing
            add_action('peepso_config_before_save-site', array(&$this, 'before_save_site'));
            add_action('peepso_config_before_save-wpadverts', array(&$this, 'before_save_wpadverts'));

            add_filter('peepso_license_config', array(&$this, 'add_license_info'), 160);

        } else {
            //
        }

        // Hook into PeepSo routing, enables single item view (eg /wpadverts/?1235/)
        add_filter('peepso_check_query', array(&$this, 'filter_check_query'), 10, 3);

        add_filter('peepso_all_plugins', array($this, 'filter_all_plugins'));
        add_filter('peepso_activity_remove_shortcode', array(&$this, 'peepso_activity_remove_shortcode'));

        // Run our activation
        register_activation_hook( __FILE__, array( $this, 'activate' ) );
    }

    /**
     * Retrieve singleton class instance
     * @return PeepSoWPAdverts instance
     */
    public static function get_instance()
    {
        if (NULL === self::$_instance) {
            self::$_instance = new self();
        }
        return (self::$_instance);
    }

    public function init()
    {
        PeepSo::add_autoload_directory(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR);
        PeepSoTemplate::add_template_directory(plugin_dir_path(__FILE__));

        if (is_admin()) {
			add_action('admin_init', array(&$this, 'wpadverts_check'));
            add_action('admin_init', array(&$this, 'peepso_check'));
            add_filter('peepso_save_post', array(&$this, 'peepso_save_post'));

            // config tabs
            add_filter('peepso_admin_config_tabs', array(&$this, 'admin_config_tabs'), -1);
        } else {
            if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
                return;
            }

            $profile_slug = PeepSo::get_option('wpadverts_navigation_profile_slug', 'classifieds', TRUE);
            add_action('peepso_profile_segment_'.$profile_slug,     array(&$this, 'action_profile_segment_classifieds'));

            // post to activity
            add_action('peepso_activity_post_attachment', array(&$this, 'attach_classifieds'), 20, 1);
            add_filter('peepso_activity_stream_action', array(&$this, 'activity_stream_action'), 10, 2);
            add_filter('peepso_activity_post_actions',      array(&$this, 'modify_post_actions'),50); // priority set to last

            // PeepSo navigation
            add_filter('peepso_navigation',                array(&$this, 'filter_peepso_navigation'));

            // overrides wpadverts template
            add_action("adverts_template_load", array(&$this, "custom_list_template"));

            add_action('wp_enqueue_scripts', array(&$this, 'enqueue_scripts'));

            if(1 == PeepSo::get_option('wpadverts_chat_enable', 0) ) {
                add_action('adverts_tpl_single_bottom', function() {
                    global $post;
                    if('advert' != $post->post_type || !get_current_user_id() || $post->post_author == get_current_user_id() || !class_exists('PeepSoMessages')) { return; }
                    ?>
                    <a href="#" class="ps-js-wpadverts-message" data-id="<?php echo $post->post_author;?>">
                        <i class="ps-icon-envelope-alt"></i><span><?php echo __('Send Message', 'peepso-wpadverts');?></span>
                        <img src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>" style="display:none" /></a>
                    <?php
                    self::get_instance()->enqueue_scripts();
                    wp_enqueue_script('peepso-wpdverts-classifieds');
                    echo '<div style="display:none">';
                    do_action('peepso_activity_dialogs');
                    echo '<div>';
                }, 99);
            }
        }

        add_filter('peepso_navigation_profile', array(&$this, 'filter_peepso_navigation_profile'));

        add_action( 'save_post', array(&$this, 'save_classifieds'), 10, 3 );

        // delete stream when ad deleted
        add_action('before_delete_post', array(&$this, 'delete_stream_classifieds'), 10, 1);

        PeepSoWPAdvertsShortcode::register_shortcodes();
    }

    public function peepso_save_post($shortcode)
    {
        if(array_key_exists($shortcode, $this->shortcodes)) {
            $page = 'page_'.str_replace(array('peepso_','peepso-wpadverts'),'',$shortcode);
            return $page;
        }

        return $shortcode;
    }

    public function peepso_activity_remove_shortcode( $content )
    {
        foreach($this->shortcodes as $shortcode=>$class) {
            foreach($this->shortcodes as $shortcode=>$class) {
                $from = array('['.$shortcode.']','['.$shortcode);
                $to = array('&#91;'.$shortcode.'&#93;', '&#91;'.$shortcode);
                $content = str_ireplace($from, $to, $content);
            }
        }
        return $content;
    }

    /**
     * Called before PeepSo saves the "site" config page
     * Deletes the cached license in order to forcefully revalidate
     */
    public function before_save_site()
    {
        PeepSoLicense::delete_transient(self::PLUGIN_SLUG);
    }

    public function before_save_wpadverts() {
        $_POST['wpadverts_navigation_profile_slug'] = strtolower(preg_replace('/[^a-z0-9\-\_\.]+/i', "", $_POST['wpadverts_navigation_profile_slug']));
    }

    /**
     * Adds the license key information to the config metabox
     * @param array $list The list of license key config items
     * @return array The modified list of license key items
     */
    public function add_license_info($list)
    {
        $data = array(
            'plugin_slug' => self::PLUGIN_SLUG,
            'plugin_name' => self::PLUGIN_NAME,
            'plugin_edd' => self::PLUGIN_EDD,
            'plugin_version' => self::PLUGIN_VERSION
        );
        $list[] = $data;
        return ($list);
    }

    public function license_notice()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG);
    }

    public function license_notice_forced()
    {
        PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG, true);
    }

    public function filter_check_query($sc, $page, $url)
    {
        if(PeepSoWPAdvertsShortcode::SHORTCODE == $page ) {
            $sc = PeepSoWPAdvertsShortcode::get_instance();
            $sc->set_page($url);
        }
    }

    /**
     * Loads the translation file for the PeepSo plugin
     */
    public function load_textdomain()
    {
        $path = str_ireplace(WP_PLUGIN_DIR, '', dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'language' . DIRECTORY_SEPARATOR;
        load_plugin_textdomain('peepso-wpadverts', FALSE, $path);
    }

    /**
     * Hooks into PeepSo for compatibility checks
     * @param $plugins
     * @return mixed
     */
    public function filter_all_plugins($plugins)
    {
        $plugins[plugin_basename(__FILE__)] = get_class($this);
        return $plugins;
    }

    /**
     * Check if PeepSo class is present (ie the PeepSo plugin is installed and activated)
     * If there is no PeepSo, immediately disable the plugin and display a warning
     * Run license and new version checks against PeepSo.com
     * @return bool
     */
    public function peepso_check()
    {
        if (!class_exists('PeepSo')) {
            add_action('admin_notices', array(&$this, 'peepso_disabled_notice'));
            unset($_GET['activate']);
            deactivate_plugins(plugin_basename(__FILE__));
            return (FALSE);
        }

        // PeepSo.com license check
        if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
             add_action('admin_notices', array(&$this, 'license_notice'));
        }

        if (isset($_GET['page']) && 'peepso_config' == $_GET['page'] && !isset($_GET['tab'])) {
            add_action('admin_notices', array(&$this, 'license_notice_forced'));
        }

        // PeepSo.com new version check
        // since 1.7.6
        if(method_exists('PeepSoLicense', 'check_updates_new')) {
            PeepSoLicense::check_updates_new(self::PLUGIN_EDD, self::PLUGIN_SLUG, self::PLUGIN_VERSION, __FILE__);
        }

        return (TRUE);
    }

    /**
     * Display a message about PeepSo not present
     */
    public function peepso_disabled_notice()
    {
        ?>
        <div class="error peepso">
            <strong>
                <?php
				echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'peepso-wpadverts'), self::PLUGIN_NAME),
                    ' <a href="plugin-install.php?tab=plugin-information&amp;plugin=peepso-core&amp;TB_iframe=true&amp;width=772&amp;height=291" class="thickbox">',
                    __('Get it now!', 'peepso-wpadverts'),
                    '</a>';
                ?>
                <?php //echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'peepso-wpadverts'), self::PLUGIN_NAME);?>
            </strong>
        </div>
        <?php
    }

    /**
     * Display a message about WPAdverts not present
     */
    public function wpadverts_disabled_notice()
    {
        ?>
        <div class="error peepso">
            <strong>
                <?php
				echo sprintf(__('The %s plugin requires the WPAdverts plugin to be installed and activated.', 'peepso-wpadverts'), self::PLUGIN_NAME),
                    ' <a href="plugin-install.php?tab=plugin-information&amp;plugin=wpadverts&amp;TB_iframe=true&amp;width=772&amp;height=291" class="thickbox">',
                    __('Get it now!', 'peepso-wpadverts'),
                    '</a>';
                ?>
                <?php //echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'peepso-wpadverts'), self::PLUGIN_NAME);?>
            </strong>
        </div>
        <?php
    }

	public function wpadverts_check()
	{
		if(!function_exists('deactivate_plugins')) {
			require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
		}

		if (!function_exists('adverts_init')) {
			add_action('admin_notices', array($this, 'wpadverts_disabled_notice'));
			unset($_GET['activate']);
			deactivate_plugins(plugin_basename(__FILE__));
			return (FALSE);
		}

		return (TRUE);
	}

    /**
     * Activation hook for the plugin.
     *
     * @since 1.0.0
     */
    public function activate() {

        if (!$this->peepso_check()) {
            return (FALSE);
        }

        require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'install' . DIRECTORY_SEPARATOR . 'activate.php');
        $install = new WPAdvertsPeepSoInstall();
        $res = $install->plugin_activation();
        if (FALSE === $res) {
            // error during installation - disable
            deactivate_plugins(plugin_basename(__FILE__));
        }
        return (TRUE);
    }

    public function admin_enqueue_scripts()
    {
    	//
    }

    /**
     * Enqueue custom scripts and styles
     *
     * @since 1.0.0
     */
    public function enqueue_scripts()
    {
        wp_enqueue_script('peepso-wpdverts-classifieds', plugin_dir_url(__FILE__) . 'assets/js/bundle.min.js', array('peepso', 'peepso-page-autoload'), self::PLUGIN_VERSION, TRUE);
        wp_localize_script('peepso', 'peepsowpadvertsdata', array(
            'listItemTemplate' => PeepSoTemplate::exec_template('wpadverts', 'wpadverts-item', NULL, TRUE),
            'user_id' => get_current_user_id(),
            'module_id' => self::MODULE_ID,
            'lang' => array(
                'more' => __('More', 'peepso-wpadverts'),
                'less' => __('Less', 'peepso-wpadverts'),
                'member' => __('member', 'peepso-wpadverts'),
                'members' => __('members', 'peepso-wpadverts'),
            )
        ));
    }

    /**
     * Publish post
     *
     * @param int $post_id The post ID.
     * @param post $post The post object.
     * @param bool $update Whether this is an existing post being updated or not.
     */
    public function save_classifieds($post_id, $post, $update)
    {
        /*
         * In production code, $slug should be set only once in the plugin,
         * preferably as a class property, rather than in each function that needs it.
         */
        $post_type = get_post_type($post_id);

        // If this isn't a 'advert' post, don't publish it.
        if ( "advert" != $post_type ) return;

        // If post to stream option disabled, don't publish it.
        if ( !PeepSo::get_option('wpadverts_post_to_stream_enable', 1) ) return;

        // If moderation enabled and post_status is `advert-pending`
        if (PeepSo::get_option('wpadverts_moderation_enable', 1) && $post->post_status == 'advert-pending') return;

        // If post status is pending
        if ( $post->post_status == 'pending' || $post->post_status == 'advert_tmp' ) return;

        // If stream already posted. skip creating new stream.
        $args = array(
            'post_status'      => array('publish', 'pending', 'trash', 'expired'),
            'post_type'        => PeepSoActivityStream::CPT_POST,
            'meta_query' => array(
                array(
                    'key'     => self::POST_META_KEY_WPADVERTS_CLASSIFIEDS_ID,
                    'value'   => $post_id,
                    'compare' => '=',
                ),
            ),
        );

        $existing_post = get_posts( $args );
        if( $existing_post ) {
            if($post->post_status == 'trash') {
                $status = 'trash';
            } elseif($post->post_status == 'expired') {
                $status = 'expired';
            }else {
                $status = 'publish';
            }

            // Update the post into the database
            $ad_post = array(
                'ID'           => $existing_post[0]->ID,
                'post_status'  => $status,
                'post_date'		=> $post->post_date,
                'post_date_gmt' => $post->post_date_gmt,
            );
            wp_update_post( $ad_post );
            return ;
        }

        // - Post to stream
        $this->classifieds_id = $post_id;
        add_filter('peepso_activity_allow_empty_content', array(&$this, 'activity_allow_empty_content'), 10, 1);

        $user_id = $post->post_author;
        $content = '';
        $extra = array(
            'module_id' => self::MODULE_ID,
            'act_access' => PeepSo::get_option('wpadverts_post_privacy', PeepSo::ACCESS_PUBLIC),
            'post_date'		=> $post->post_date,
            'post_date_gmt' => $post->post_date_gmt,
        );

        $peepso_activity = PeepSoActivity::get_instance();
        $stream_id = $peepso_activity->add_post($user_id, $user_id, $content, $extra);
        add_post_meta($stream_id, self::POST_META_KEY_WPADVERTS_TYPE, self::POST_META_KEY_WPADVERTS_TYPE_CLASSIFIEDS, true);
        add_post_meta($stream_id, self::POST_META_KEY_WPADVERTS_CLASSIFIEDS_ID, $post_id);

        remove_filter('peepso_activity_allow_empty_content', array(&$this, 'activity_allow_empty_content'));

    }

    /**
     * Checks if empty content is allowed
     * @param string $allowed
     * @return boolean always returns TRUE
     */
    public function activity_allow_empty_content($allowed)
    {
        if(isset($this->classifieds_id)) {
            $allowed = TRUE;
        }

        return ($allowed);
    }

    /**
     * Delete stream
     * @param int $post_id
     */
    public function delete_stream_classifieds($post_id)
    {
        /*
         * In production code, $slug should be set only once in the plugin,
         * preferably as a class property, rather than in each function that needs it.
         */
        $post_type = get_post_type($post_id);
        $post = get_post($post_id);

        // If this isn't a 'advert' post, don't publish it.
        if ( "advert" != $post_type ) return;

        // If stream exists delete activity.
        $args = array(
            'post_status'      => array('publish', 'pending', 'trash'),
            'post_type'        => PeepSoActivityStream::CPT_POST,
            'meta_query' => array(
                array(
                    'key'     => self::POST_META_KEY_WPADVERTS_CLASSIFIEDS_ID,
                    'value'   => $post_id,
                    'compare' => '=',
                ),
            ),
        );

        $existing_post = get_posts( $args );
        if( !$existing_post ) return ;

        global $wpdb;

        $act = $wpdb->get_row( $wpdb->prepare( "SELECT * from $wpdb->prefix" . PeepSoActivity::TABLE_NAME . " WHERE act_external_id= %s AND act_module_id = %s AND act_owner_id = %s", $existing_post[0]->ID, self::MODULE_ID, $existing_post[0]->post_author));
        if( !$act ) return ;
        $activity = PeepSoActivity::get_instance();
        $activity->delete_activity($act->act_id);
        $activity->delete_post($existing_post[0]->ID);

    }

    /**
     * BACKEND SETTINGS
     * ================
     */

    /**
     * Registers a tab in the PeepSo Config Toolbar
     * PS_FILTER
     *
     * @param $tabs array
     * @return array
     */
    public function admin_config_tabs( $tabs )
    {
        $tabs['wpadverts'] = array(
            'label' => __('WPAdverts', 'peepso-wpadverts'),
            'icon' => self::ICON,
            'tab' => 'wpadverts',
            'description' => __('PeepSo - WPAdverts Integration', 'peepso-wpadverts'),
            'function' => 'PeepSoConfigSectionWPAdverts',
            'cat'   => 'integrations',
        );

        return $tabs;
    }

    /**
     * FRONTEND
     * ========
     *
     */


    /**
     * Attach the ads to the post display
     * @param  object $post The post
     */
    public function attach_classifieds($stream_post = NULL)
    {
        $ads_type = get_post_meta($stream_post->ID, self::POST_META_KEY_WPADVERTS_TYPE, true);

        if($ads_type === self::POST_META_KEY_WPADVERTS_TYPE_CLASSIFIEDS) {
            $ads_id = get_post_meta($stream_post->ID, self::POST_META_KEY_WPADVERTS_CLASSIFIEDS_ID, true);

            $post = get_post( $ads_id );
            $type = $post->post_type;
            $expires = get_post_meta( $post->ID, "_expiration_date", true );

            $image = adverts_get_main_image( $ads_id );
            $price = adverts_get_the_price( $ads_id );
            $date = date_i18n( get_option( 'date_format' ), get_post_time( 'U', false, $post->ID ) );
            $location = get_post_meta( $post->ID, "adverts_location", true );
            $expires = esc_html( apply_filters( 'adverts_sh_manage_date', date_i18n( get_option('date_format'), $expires ), $post ) );
            $class_featured = '';
            if( $post->menu_order ) {
                $class_featured = ' ps-classified__item--featured';
            }

            // Setup our entry content
            $content = '<div class="ps-classified__item ps-classified__item--stream' . $class_featured . '">';
                $content .= '<div class="ps-classified__item-body">';

                    if($image) {
                        $content .= '<div class="ps-classified__item-image"><a href="'. get_permalink( $ads_id ) . '"><img src="' . adverts_get_main_image( $ads_id ) . '" /></a></div>';
                    }

                    $content .= '<h3 class="ps-classified__item-title"><a href="'. get_permalink( $ads_id ) . '">'. $post->post_title . '</a></h3>';

                    if($price) {
                        $content .= '<div class="ps-classified__item-details"><a class="ps-classified__item-price" href="'. get_permalink( $ads_id ) . '">'.$price.'</a></div>';
                    }

                    $content .= '<div class="ps-classified__item-desc">' . wpautop( $post->post_content ) . '</div>';
                $content .= '</div>';
                $content .= '<div class="ps-classified__item-footer ps-text--muted">';
                    $content .= '<span><i class="ps-icon-clock"></i> '. $date .'</span> <span><i class="ps-icon-map-marker"></i> '. $location .'</span> ';
                    if((get_current_user_id() == $post->post_author) || is_admin()) {
                        $content .= '<span><i class="ps-icon-clock"></i> '. __('expires', 'peepso-wpadverts') .': '. $expires .'</span>';
                    }
                    $content .= '<div class="ps-classified__item-actions">';
                        if (class_exists('PeepSoMessages') && get_current_user_id() != $post->post_author && 1 == PeepSo::get_option('wpadverts_chat_enable', 0)) {
                            $content .= '<a href="#" class="ps-js-wpadverts-message" data-id="' . $post->post_author . '">';
                            $content .= '<i class="ps-icon-envelope-alt"></i><span>' . __('Send Message', 'peepso-wpadverts') . '</span> ';
                            $content .= '<img src="' . PeepSo::get_asset('images/ajax-loader.gif') . '" style="display:none" /></a> ';
                        }
                        $content .= '<a href="' . get_permalink( $ads_id ) . '" class="ps-link--more"><i class="ps-icon-info-circled"></i><span>' . __('More', 'peepso-wpadverts') . '</span></a>';
                    $content .= '</div>';
                $content .= '</div>';
            $content .= '</div>';

            echo $content;

            // enqueue script handler
            wp_enqueue_script('peepso-wpdverts-classifieds');
        }
    }

    /**
     * Change the activity stream item action string
     * @param  string $action The default action string
     * @param  object $post   The activity post object
     * @return string
     */
    public function activity_stream_action($action, $post)
    {
        if (self::MODULE_ID === intval($post->act_module_id)) {

            $ads_type = get_post_meta($post->ID, self::POST_META_KEY_WPADVERTS_TYPE, true);
            if($ads_type === self::POST_META_KEY_WPADVERTS_TYPE_CLASSIFIEDS) {
                $action = __(' posted a new ad', 'peepso-wpadverts');
            }
        }

        return ($action);
    }



    /**
     * Change act_id on repost button act_id to follow parent's act_id.
     * @param array $options The default options per post
     * @return  array
     */
    public function modify_post_actions($options)
    {
        $post = $options['post'];

        if (self::MODULE_ID === intval($post->act_module_id)) {

            $ads_type = get_post_meta($post->ID, self::POST_META_KEY_WPADVERTS_TYPE, true);
            if($ads_type === self::POST_META_KEY_WPADVERTS_TYPE_CLASSIFIEDS) {
                // disable repost function for classifieds post
                unset($options['acts']['repost']);
            }
        }

        return ($options);
    }

    /**
     * Render classifieds in user profile
     */
    public function action_profile_segment_classifieds()
    {
        $pro = PeepSoProfileShortcode::get_instance();
        $this->view_user_id = PeepSoUrlSegments::get_view_id($pro->get_view_user_id());

        $url = PeepSoUrlSegments::get_instance();
        if ($url->get(3) == 'manage') {

            $shortcode = PeepSoWPAdvertsShortcode::get_instance();
            echo $shortcode->shortcode_manage_ads();

        } else {

            wp_enqueue_script('peepso-wpdverts-classifieds');

            echo PeepSoTemplate::exec_template('wpadverts', 'profile-wpadverts', array('view_user_id' => $this->view_user_id), TRUE);
        }
    }

    /*
     * PeepSo navigation
     */

    public function filter_peepso_navigation($navigation)
    {
        $user = PeepSoUser::get_instance(get_current_user_id());

        $navigation['wpadverts'] = array(
            'href' => PeepSo::get_page('wpadverts'),
            'label' => PeepSo::get_option('wpadverts_navigation_label', __('Classifieds', 'peepso-wpadverts'), TRUE),
            'icon' => 'ps-icon-bullhorn',

            'primary'           => TRUE,
            'secondary'         => FALSE,
            'mobile-primary'    => TRUE,
            'mobile-secondary'  => FALSE,
            'widget'            => TRUE,
        );

        return ($navigation);
    }

    /**
     * Profile Segments - add link
     * @param $links
     * @return mixed
     */
    public function filter_peepso_navigation_profile($links)
    {
        $links['wpadverts'] = array(
            'href' => PeepSo::get_option('wpadverts_navigation_profile_slug', 'classifieds', TRUE),
            'label'=> PeepSo::get_option('wpadverts_navigation_profile_label', __('Classifieds', 'peepso-wpadverts'), TRUE),
            'icon' => 'ps-icon-bullhorn'
        );

        return $links;
    }


    function custom_list_template( $tpl ) {
        // $tpl is an absolute path to a file, for example
        // /home/simpliko/public_html/wp-content/plugins/wpadverts/templates/list.php

        $basename = basename( $tpl );
        // $basename is just a filename for example list.php

        if( $basename == "add.php" ) {
            return dirname( __FILE__ ) . "/templates/overrides/add.php";
        } elseif( $basename == "add-preview.php" ) {
            return dirname( __FILE__ ) . "/templates/overrides/add-preview.php";
        } elseif( $basename == "add-save.php" ) {
            return dirname( __FILE__ ) . "/templates/overrides/add-save.php";
        } elseif( $basename == "manage.php" ) {
            return dirname( __FILE__ ) . "/templates/overrides/manage.php";
        } elseif( $basename == "manage-edit.php" ) {
            return dirname( __FILE__ ) . "/templates/overrides/manage-edit.php";
        } elseif( $basename == "add-preview.php" ) {
            return dirname( __FILE__ ) . "/templates/overrides/single.php";
        } else {
            return $tpl;
        }
    }
}

PeepSoWPAdverts::get_instance();
