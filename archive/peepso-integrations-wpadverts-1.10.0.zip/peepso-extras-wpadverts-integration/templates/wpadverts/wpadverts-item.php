<div class="ps-classified__item-wrapper ps-js-classifieds-item ps-js-classifieds-item--{{= data.id }}">
	<div class="ps-classified__item{{ if (data.is_featured) { }} ps-classified__item--featured {{ } }}">
		<div class="ps-classified__item-body">
			{{ if ( data.image ) { }}
			<a class="ps-classified__item-image" href="{{= data.permalink }}">
				<img src="{{= data.image }}" alt="">
			</a>
			{{ } }}

			<h3 class="ps-classified__item-title">
				<a href="{{= data.permalink }}">{{= data.title }}</a>
			</h3>

			{{ if (data.price) { }}
			<div class="ps-classified__item-details">
				<a class="ps-classified__item-price" href="{{= data.permalink }}">{{= data.price }}</a>
			</div>
			{{ } }}

			<div class="ps-classified__item-desc">{{= data.content }}</div>
		</div>

		<div class="ps-classified__item-footer ps-text--muted">
			<span><i class="ps-icon-user"></i> {{= data.author }}</span>
			<span><i class="ps-icon-clock"></i> {{= data.date_formated }}</span>
			{{ if ( data.location ) { }}
			<span><i class="ps-icon-map-marker"></i> {{= data.location }}</span>
			{{ } }}
			{{ if ( data.is_owner == true || data.is_admin == true ) { }}
			<span><i class="ps-icon-clock"></i> {{ if (data.is_expired) { }}<?php _e('expired', 'peepso-wpadverts'); ?>{{ } else { }}<?php _e('expires', 'peepso-wpadverts'); ?>{{ } }}: {{= data.expires }}</span>
			{{ } }}

			<div class="ps-classified__item-actions">
				<div class="ps-js-action">
                    <?php

                    if( 1 == PeepSo::get_option('wpadverts_chat_enable', 0)) { ?>
					{{ if ( window.ps_messages && ! data.is_owner ) { }}
					<a href="#" class="ps-js-wpadverts-message" data-id="{{= data.user_id }}">
						<i class="ps-icon-envelope-alt"></i>
						<span><?php _e('Send Message', 'peepso-wpadverts'); ?></span>
						<img src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>" style="display:none" />
					</a>
					{{ } }}
                    <?php } ?>
					<a href="{{= data.permalink }}" class="ps-link--more">
						<i class="ps-icon-info-circled"></i>
						<span><?php _e('More', 'peepso-wpadverts'); ?></span>
					</a>
					{{ if ( data.is_owner || data.is_admin ) { }}
					<?php $baseurl = apply_filters( "adverts_manage_baseurl", get_the_permalink() ); ?>
					<a href="<?php esc_attr_e( admin_url( 'admin-ajax.php' ) ) ?>?action=adverts_delete&id={{= data.id }}&redirect_to=<?php esc_attr_e( urlencode( $baseurl ) ) ?>&_ajax_nonce=<?php echo wp_create_nonce('adverts-delete') ?>"
							class="ps-link--delete adverts-manage-action-delete ps-js-delete"
							title="<?php _e('Delete', 'peepso-wpadverts'); ?>"
							data-url="<?php esc_attr_e( admin_url('admin-ajax.php') ); ?>"
							data-id="{{= data.id }}"
							data-nonce="<?php echo wp_create_nonce('adverts-delete') ?>">
						<i class="ps-icon-trash"></i>
						<span><?php _e('Delete', 'peepso-wpadverts'); ?></span>
					</a>
					<a href="{{= data.edit_url }}" class="ps-link--edit">
						<i class="ps-icon-pencil"></i>
						<span><?php _e('Edit', 'peepso-wpadverts'); ?></span>
					</a>
					{{ } }}
				</div>

				{{ if ( data.is_owner || data.is_admin ) { }}
				<div class="ps-js-delete-confirm" style="display:none">
					<i class="ps-icon-trash"></i>
					<i class="ps-icon-spinner" style="display:none"></i>
					<?php _e('Are you sure?', 'peepso-wpadverts'); ?>
					<a href="javascript:" class="ps-js-delete-yes"><?php _e('Yes', 'peepso-wpadverts'); ?></a>
					<a href="javascript:" class="ps-js-delete-no"><?php _e('Cancel', 'peepso-wpadverts'); ?></a>
				</div>
				{{ } }}
			</div>
		</div>
	</div>
</div>
