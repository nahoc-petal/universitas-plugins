<div class="peepso">
	<?php PeepSoTemplate::exec_template('general','navbar'); ?>
	<?php PeepSoTemplate::exec_template('general', 'register-panel'); ?>
	<?php if(get_current_user_id()) { ?>
	<section id="mainbody" class="ps-page-unstyled">
			<section id="component" role="article" class="ps-clearfix">
				<div class="ps-page-actions">
					<a class="ps-btn ps-btn-small" href="<?php echo PeepSo::get_page('wpadverts') . '?create/';?>">
						<?php _e('Create', 'peepso-wpadverts');?>
					</a>
				</div>

				<h4 class="ps-page-title"><?php _e('Classifieds Categories', 'peepso-wpadverts'); ?></h4>

				<div class="ps-tabs__wrapper">
					<div class="ps-tabs ps-tabs--arrows">
						<div class="ps-tabs__item"><a href="<?php echo PeepSo::get_page('wpadverts');?>"><?php _e('Classifieds', 'peepso-wpadverts'); ?></a></div>
						<div class="ps-tabs__item current"><a href="<?php echo PeepSo::get_page('wpadverts').'/?category/';?>"><?php _e('Classifieds Categories', 'peepso-wpadverts'); ?></a></div>
					</div>
				</div>

				<?php echo $ads_category;?>
			</section>
		</section>
	<?php } ?>
</div><!--end row-->

<?php

if(get_current_user_id()) {
	PeepSoTemplate::exec_template('activity', 'dialogs');
}
