<div class="peepso">
	<?php PeepSoTemplate::exec_template('general','navbar'); ?>
	<?php PeepSoTemplate::exec_template('general', 'register-panel'); ?>
	<?php if(get_current_user_id()) { ?>
		<section id="mainbody" class="ps-page-unstyled">
			<section id="component" role="article" class="ps-clearfix">
				<div class="ps-page-actions">
					<a class="ps-btn ps-btn-small" href="<?php echo PeepSo::get_page('wpadverts') . '?create/';?>">
						<?php _e('Create', 'peepso-wpadverts');?>
					</a>

				</div>

				<h4 class="ps-page-title"><?php _e('Classifieds', 'peepso-wpadverts'); ?></h4>

				<!-- 
		        <div class="ps-tabs__wrapper">
					<div class="ps-tabs ps-tabs--arrows">
						<div class="ps-tabs__item current"><a href="<?php echo PeepSo::get_page('wpadverts');?>"><?php _e('Classifieds', 'peepso-wpadverts'); ?></a></div>
						<div class="ps-tabs__item"><a href="<?php echo PeepSo::get_page('wpadverts').'/?category/';?>"><?php _e('Classifieds Categories', 'peepso-wpadverts'); ?></a></div>
					</div>
				</div>
 				-->
 				
				<form class="ps-form ps-form-search" role="form" name="form-peepso-search" onsubmit="return false;">
					<div class="ps-form-row">
						<input placeholder="<?php _e('Start typing to search...', 'peepso-wpadverts');?>" type="text" class="ps-input ps-js-classifieds-query" name="query" value="<?php echo esc_attr($search); ?>" />
					</div>
					<a href="javascript:" class="ps-form-search-opt">
						<span class="ps-icon-cog"></span>
					</a>
				</form>
				<?php
				$default_sorting = '';
				if(!strlen(esc_attr($search)))
				{
					$default_sorting = PeepSo::get_option('classifieds_default_sorting','id');
				}

				?>
				<div class="ps-js-page-filters" style="display:none">
					<div class="ps-page-filters ps-page-filters--classifieds">
						<!--<div class="ps-filters-row">
							<label><?php _e('Location', 'peepso-wpadverts'); ?></label>
							<input placeholder="<?php _e('Start typing to search...', 'peepso-wpadverts');?>" type="text" class="ps-input ps-js-classifieds-location" name="location" value="<?php echo esc_attr($location); ?>" />
						</div>--!>
						<!-- <div class="ps-filters-row">
							<label><?php _e('Sort', 'peepso-wpadverts'); ?></label>
							<select class="ps-select ps-js-classifieds-sortby" style="margin-bottom:5px">
								<option value="id|desc"><?php _e('Recently added', 'peepso-wpadverts'); ?></option>
								<option <?php echo ('post_title' == $default_sorting) ? ' selected="selected" ' : '';?> value="post_title|asc"><?php _e('Alphabetical', 'peepso-wpadverts'); ?></option>
								<option <?php echo ('meta_members_count' == $default_sorting) ? ' selected="selected" ' : '';?>value="meta_members_count|desc"><?php _e('Members count', 'peepso-wpadverts'); ?></option>
							</select>
						</div> -->

						<?php if($adverts_categories) { ?>

							<div class="ps-filters-row">
								<label><?php _e('Category', 'peepso-wpadverts'); ?></label>
								<select class="ps-select ps-js-classifieds-category" style="margin-bottom:5px">
									<option value="0"><?php _e('All categories', 'peepso-wpadverts'); ?></option>
									<?php
									if(count($adverts_categories)) {
										$category = 0;
										foreach($adverts_categories as $id=>$cat) {
											$selected = "";
											// if($id==$category) {
											// 	$selected = ' selected="selected"';
											// }
											echo "<option value=\"{$cat['value']}\"{$selected}>".str_repeat(' - ', $cat['depth'])."{$cat['text']}</option>";
										}
									}
									?>
								</select>
							</div>

						<?php } // ENDIF ?>

					</div>
				</div>

				<div class="ps-clearfix mb-20"></div>
				<div class="ps-classifieds ps-clearfix ps-js-classifieds"></div>
				<div class="ps-scroll ps-clearfix ps-js-classifieds-triggerscroll">
					<img class="post-ajax-loader ps-js-classifieds-loading" src="<?php echo PeepSo::get_asset('images/ajax-loader.gif'); ?>" alt="" style="display:none" />
				</div>
			</section>
		</section>
	<?php } ?>
</div><!--end row-->

<?php

if(get_current_user_id()) {
	PeepSoTemplate::exec_template('activity', 'dialogs');
}
