=== PeepSo - WPAdverts Integration Plugin ===
Contributors: Septiyan, Eric, Matt Jasiukiewicz
Donate link: https://peepso.com
Tags: badge, badges, credly, achievement, award, reward, engagement, nomination, peepso, community, badgeos
Requires at least: 4.6
Tested up to: 4.9
Stable tag: 1.0.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/agpl-3.0.html

Integrates WPAdverts and PeepSo. Users can create classifieds in the community. The classifieds are displayed in users's profiles and community page.

== Description ==

Integrates WPAdverts and PeepSo. Users can create classifieds in the community. The classifieds are displayed in users's profiles and community page.

**Note:** For this integration to work you need both [WPAdverts plugin](http://wordpress.org/extend/plugins/wpadverts/ "WPAdverts") as well as [PeepSo plugin](https://wordpress.org/plugins/peepso-core/ "PeepSo").

== Installation ==


1. Install and activate and configure the free [WPAdverts plugin](http://wordpress.org/extend/plugins/wpadverts/ "WPAdverts") to your WordPress site.
2. Install and activate and configure the free [PeepSo plugin](http://wordpress.org/plugins/peepso-core/ "PeepSo") to your WordPress site.
3. Install and PeepSo - WPAdverts Integration Plugin.
4. Activate the plugin through the 'Plugins' menu in WordPress
5. You're done. You can now proceed to configuring your Classifieds.


== Changelog ==

= 1.0.0 =
* Initial release
