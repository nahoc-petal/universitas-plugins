<?php

class PeepSoClassifiedsAjax extends PeepSoAjaxCallback
{
	/** GROUP SEARCH & LISTING **/

	/**
	 * GET
	 * Search for groups matching the query.
	 * @param  PeepSoAjaxResponse $resp
	 */
	public function search(PeepSoAjaxResponse $resp)
	{
		$page = $this->_input->int('page', 1);
		$order_by = $this->_input->val('order_by', 'id');
		$order = strtoupper($this->_input->val('order', 'DESC'));
		$query = stripslashes_deep($this->_input->val('query', ''));
		$user_id = $this->_input->int('user_id', 0);
		$location = stripslashes_deep($this->_input->val('location', ''));
		$category = $this->_input->int('category', 0);
		$limit = $this->_input->int('limit', 1);

		if (NULL !== $order_by && strlen($order_by)) {
			if ('ASC' !== $order && 'DESC' !== $order) {
				$order = 'ASC';
			}
		}

		$resp->set('page', $page);

		$PeepSoClassifieds = new PeepSoClassifieds();
		$classifieds = $PeepSoClassifieds->get_classifieds($page, $limit, $order_by, $order, $query, $user_id, $location, $category);

		if (count($classifieds) > 0 || $page > 1) {

			$resp->success(TRUE);
			$resp->set('classifieds', $classifieds);
		} else {
            $resp->success(FALSE);
            if($user_id) {
                $message = (get_current_user_id() == $user_id) ? __('You have no classifieds yet', 'peepso-wpadverts') : sprintf(__('%s has no classifieds yet', 'peepso-wpadverts'), PeepSoUser::get_instance($user_id)->get_firstname());
                $resp->error(PeepSoTemplate::exec_template('profile', 'no-results-ajax', array('message' => $message), TRUE));
            } else {
                $message = __('No classifieds found', 'peepso-wpadverts');
                $resp->error(PeepSoTemplate::exec_template('general', 'no-results-ajax', array('message' => $message), TRUE));
            }
		}
	}
}
// EOF
