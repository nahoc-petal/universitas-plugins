<div style="margin-bottom:20px;">
    <img src="<?php echo $image; ?>" style="max-width:100%;" />
</div>