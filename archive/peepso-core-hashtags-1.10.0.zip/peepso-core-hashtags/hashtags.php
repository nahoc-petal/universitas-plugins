<?php
/**
 * Plugin Name: PeepSo Core: Hashtags
 * Plugin URI: https://peepso.com
 * Description: Hashtag support for PeepSo
 * Author: PeepSo
 * Author URI: https://peepso.com
 * Version: 1.10.0
 * Copyright: (c) 2018 PeepSo, Inc. All Rights Reserved.
 * License: GPLv2 or later
 * License URI: http://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: peepsohashtags
 * Domain Path: /language
 *
 * We are Open Source. You can redistribute and/or modify this software under the terms of the GNU General Public License (version 2 or later)
 * as published by the Free Software Foundation. See the GNU General Public License or the LICENSE file for more details.
 * This software is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY.
 */

class PeepSoHashtagsPlugin
{
    private static $_instance = NULL;

    const PLUGIN_NAME	 = 'Core: Hashtags';
    const PLUGIN_EDD     = 2882624;
    const PLUGIN_SLUG    = 'hashtags';

    const PEEPSOCOM_LICENSES = 'http://tiny.cc/peepso-licenses';

    const PLUGIN_VERSION = '1.10.0';
    const PLUGIN_RELEASE = ''; //ALPHA1, BETA1, RC1, '' for STABLE
    const POST_META = 'peepso_hashtags_done';

    const CONFIG_MIN_LENGTH = 3;
    const CONFIG_MAX_LENGTH = 16;
    const CONFIG_POST_COUNT_INTERVAL = 15;
    const CONFIG_POST_COUNT_BATCH_SIZE = 10;

    #private $regex = "/#([\p{Latin}A-Za-z0-9])+/u";
    private $regex = " /#([A-Za-z0-9]+)/u";

    private $widgets = array(
        'PeepSoWidgetHashtags',
    );

    private function __construct()
    {
        add_action('peepso_init', array(&$this, 'init'));

        add_action('plugins_loaded', function() {
            $path = str_ireplace(WP_PLUGIN_DIR, '', dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'language' . DIRECTORY_SEPARATOR;
            load_plugin_textdomain('peepsohashtags', FALSE, $path);
        });

        if (is_admin()) {
            add_action('admin_init', array(&$this, 'peepso_check'));

            // licensing
            add_action('peepso_config_before_save-site', function() {
                PeepSoLicense::delete_transient(self::PLUGIN_SLUG);
            });

            add_filter('peepso_license_config', function($list){
                $list[] = array(
                    'plugin_slug' => self::PLUGIN_SLUG,
                    'plugin_name' => self::PLUGIN_NAME,
                    'plugin_edd' => self::PLUGIN_EDD,
                    'plugin_version' => self::PLUGIN_VERSION
                );
                return ($list);
            }, 160);

        }

        add_filter('peepso_all_plugins', function($plugins) {
            $plugins[plugin_basename(__FILE__)] = get_class($this);
            return $plugins;
        });

        // Run our activation
        register_activation_hook( __FILE__, array( $this, 'activate' ) );

        add_filter('peepso_widgets', function($widgets){

            if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG, 0))
            {
                return $widgets;
            }

            foreach (scandir($widget_dir = dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR . 'widgets' . DIRECTORY_SEPARATOR) as $widget) {
                if (strlen($widget)>=5) require_once($widget_dir . $widget);
            }

            return array_merge($widgets, $this->widgets);

        });

        // Clear POST_META when peepso-post is saved, to recalculate hashtags
        add_action('peepso_activity_after_save_post', function($post_id){
            if('peepso-post'==get_post_type($post_id)) {
                delete_post_meta($post_id, PeepSoHashtagsPlugin::POST_META);
            }
        },10,3);
    }

    public static function get_instance()
    {
        if (NULL === self::$_instance) {
            self::$_instance = new self();
        }
        return (self::$_instance);
    }

    public function init()
    {
        // Run activatuon in case of version number change
        if( $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE != get_transient($trans = 'peepso_'.$this::PLUGIN_SLUG.'_version')) {
            // activate returns false in case of missing license
            if($this->activate()) {
                set_transient($trans, $this::PLUGIN_VERSION.$this::PLUGIN_RELEASE);
            }
        }

        PeepSo::add_autoload_directory(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes' . DIRECTORY_SEPARATOR);
        PeepSoTemplate::add_template_directory(plugin_dir_path(__FILE__));

        // Hooks: common
        add_filter('peepso_activity_post_clauses', function($clauses, $user_id = NULL){
            $PeepSoInput = new PeepSoInput();
            $hashtag = $PeepSoInput->val('search_hashtag', '');
            // exclude where clauses if searching comment
            if(!empty($hashtag) && (FALSE === strpos($clauses['where'], PeepSoActivityStream::CPT_COMMENT ))) {

                // @todo: check regex
                $hashtag = strtolower($hashtag);
                $clauses['where'] .= " AND " . $this->query_where($hashtag);
            }

            return $clauses;
        },1,2);

        // Hooks: backend
        if (is_admin()) {
            add_filter('peepso_admin_config_tabs', array(&$this, 'admin_config_tabs'));
        }

        // Hooks: frontend
        if(!is_admin()) {
            if (PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG, 0)) {
                add_action('wp_enqueue_scripts', array(&$this, 'enqueue_scripts'));

                add_action('peepso_action_render_stream_filters', function () {
                    PeepSoTemplate::exec_template('hashtags', 'stream-filters');
                });
            }
        }

        add_action('peepso_config_before_save-hashtags', function() {

            $rebuild = FALSE;

            if($_POST['hashtags_min_length']!=PeepSo::get_option('hashtags_min_length', PeepSoHashtagsPlugin::CONFIG_MIN_LENGTH)) {
                $rebuild = TRUE;
            }elseif($_POST['hashtags_max_length']!=PeepSo::get_option('hashtags_max_length', PeepSoHashtagsPlugin::CONFIG_MAX_LENGTH)) {
                $rebuild = TRUE;
            }elseif(isset($_POST['hashtags_must_start_with_letter']) && PeepSo::get_option('hashtags_must_start_with_letter')!=$_POST['hashtags_must_start_with_letter']) {
                $rebuild = TRUE;
            } elseif(isset($_POST['hashtags_rebuild'])) {
                    $_POST['hashtags_rebuild']=0;
                    $rebuild = TRUE;
            }


            if($rebuild) {
                $this->build_reset();
                $peepso_admin = PeepSoAdmin::get_instance();
                $peepso_admin->add_notice(__('The hashtag cache has been purged and it may take a while to rebuild it. You can use your site as usual.','peepsohashtags'), 'note');
            }
        });

        $this->build(PeepSo::get_option('hashtags_post_count_batch_size', PeepSoHashtagsPlugin::CONFIG_POST_COUNT_BATCH_SIZE));
    }

    /**
     * Activation hook for the plugin.
     *
     * @since 1.0.0
     */
    public function activate() {

        if (!$this->peepso_check()) {
            return (FALSE);
        }

        require_once(dirname(__FILE__) . DIRECTORY_SEPARATOR . 'classes'. DIRECTORY_SEPARATOR .'tools' . DIRECTORY_SEPARATOR . 'activate.php');

        if (new PeepSoHashtagsInstall()) {
            return TRUE;
        }

        deactivate_plugins(plugin_basename(__FILE__));
        return FALSE;
    }

    /**
     * Adds the license key information to the config metabox
     * @param array $list The list of license key config items
     * @return array The modified list of license key items
     */
    public function add_license_info($list)
    {
        $data = array(
            'plugin_slug' => self::PLUGIN_SLUG,
            'plugin_name' => self::PLUGIN_NAME,
            'plugin_edd' => self::PLUGIN_EDD,
            'plugin_version' => self::PLUGIN_VERSION
        );
        $list[] = $data;
        return ($list);
    }

    /**
     * Registers a tab in the PeepSo Config Toolbar
     * PS_FILTER
     *
     * @param $tabs array
     * @return array
     */
    public function admin_config_tabs( $tabs )
    {
        $tabs['hashtags'] = array(
            'label' => __('Hashtags', 'peepsohashtags'),
            'icon' => 'https://www.peepso.com/wp-content/plugins/peepso.com-checkout/assets/icons/'.self::PLUGIN_EDD.'.svg',
            'tab' => 'hashtags',
            'description' => __('Hashtags', 'peepsohashtags'),
            'function' => 'PeepSoConfigSectionHashtags',
            'cat' => 'core',
        );

        return $tabs;
    }

    /**
     * Load translations
     * @return void
     */
    public function load_textdomain()
    {
        $path = str_ireplace(WP_PLUGIN_DIR, '', dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'language' . DIRECTORY_SEPARATOR;
        load_plugin_textdomain('peepsohashtags', FALSE, $path);
    }

    /**
     * Run processes scanning posts and building the hashtags database
     */
    public function build($limit=10)
    {
        $count =0;
        $count += $this->build_posts($limit);
        $count += $this->build_hashtags($limit);

        return $count;
    }

    /**
     * Process a batch ot posts
     */
    public function build_posts($limit=10) {
        global $wpdb;
        $post_meta  = self::POST_META;

        $post_query = new WP_Query(array(
            'posts_per_page' => $limit,
            'post_type' => 'peepso-post',
            'meta_query' =>  array(
                'relation' => 'OR',
                array(
                    'key' => $post_meta,
                    'value' => '1',
                    'compare' => '!='
                ),
                array(
                    'compare' => 'NOT EXISTS',
                    'key' => $post_meta,
                )
            ),
        ));

        $count = count($post_query->posts);

        if($count) {

            foreach($post_query->posts as $post) {
                // Mark post as done
                #add_post_meta($post->ID, $post_meta, 1, TRUE);

                $content = $post->post_content;

                // Don't match escaped UTF chars
                $content = str_replace('&#x','', $content);

                // regex matches " #", prepend space in case the content starts with #
                $content = ' ' . $content;

                // regex matches " ", convert newlines to spaces
                $content = str_replace("\n", " ", $content);

                // Detect all hashtags
                preg_match_all($this->regex, $content, $matches);
                if ($matches) {

                    $hashtagsArray = array_count_values($matches[0]);
                    $hashtags = array_keys($hashtagsArray);

                    if(count($hashtags)) {

                        foreach($hashtags as $hashtag) {

                            // lowercase and remove the # symbol
                            $hashtag=trim(strtolower($hashtag),'#');

                            if(!self::hashtag_validate($hashtag)) {
                                continue;
                            }
#var_dump($hashtag);
                            // Insert hashtag to database (ht_name is UNIQUE, so IGNORE to supress double value errors)
                            $wpdb->query("INSERT IGNORE INTO `{$wpdb->prefix}peepso_hashtags` SET `ht_name`='$hashtag'");
                        }
                    }

                }
            };
        }
#die();
        return $count;
    }

    /**
     * Process a batch of hashtags
     */
    private function build_hashtags($limit=10) {
        global $wpdb;

        $interval = PeepSo::get_option('hashtags_post_count_interval', PeepSoHashtagsPlugin::CONFIG_POST_COUNT_INTERVAL);

        $hashtags = $wpdb->get_results("SELECT `ht_name` FROM `{$wpdb->prefix}peepso_hashtags`  WHERE `ht_last_count` IS NULL OR `ht_last_count` < DATE_SUB(NOW(),INTERVAL $interval MINUTE) LIMIT $limit", OBJECT); // ARRAY_A);

        $count = count($hashtags);

        if($count) {
            foreach ($hashtags as $hashtag) {

                $hashtag = $hashtag->ht_name;

                $delete = FALSE;
                $count = 0;

                if(!self::hashtag_validate($hashtag)) {
                    $delete = TRUE;
                } else {
                    $sql = "SELECT `ID` FROM $wpdb->posts WHERE post_type='peepso-post' AND `post_status`='publish' AND  " . $this->query_where($hashtag);

                    $wpdb->query($sql);

                    $count = (int)$wpdb->num_rows;

                    if ($count == 0 && 1 == PeepSo::get_option('hashtags_delete_empty', 1)) {
                        $delete = TRUE;
                    } else {
                        $wpdb->query("UPDATE `{$wpdb->prefix}peepso_hashtags` SET `ht_count`= $count, `ht_last_count`=NOW() WHERE `ht_name`='$hashtag'");
                    }
                }

                if ($delete) {
                    $wpdb->query("DELETE FROM `{$wpdb->prefix}peepso_hashtags` WHERE `ht_name`='$hashtag'");
                }
            }
        }

        return $count;
    }

    public static function hashtag_validate($hashtag) {

        $valid = TRUE;

        $min_length = PeepSo::get_option('hashtags_min_length',PeepSoHashtagsPlugin::CONFIG_MIN_LENGTH);
        $max_length = PeepSo::get_option('hashtags_max_length',PeepSoHashtagsPlugin::CONFIG_MAX_LENGTH);

        if(strlen($hashtag) < $min_length) {
            $valid = FALSE;
        } elseif(strlen($hashtag) > $max_length) {
            $valid = FALSE;
        } elseif(is_numeric(substr($hashtag,0,1)) && 1 == PeepSo::get_option('hashtags_must_start_with_letter')) {
            $valid = FALSE;
        }

        return $valid;
    }

    private function query_where($hashtag) {
        global $wpdb;
        $delimiters = array(
            ' ',
            "\n",
            '.',
            ',',
            '-',
            '\_', // escape to be treated literally
            '(',
            ')',
            '[',
            ']',
            '{',
            '}',
            '!',
            ':',
            ';',
            '#',
            '\%', // escape to be treated literally
            '*',
            '<',
        );

        $sql = " (`$wpdb->posts`.`post_content` LIKE '%#$hashtag' "; // hashtag "glued to the end of post

        // hashtag ended by any of the legal delimiters (to avoid counting #hashtag and #hashtagofdoom together
        foreach($delimiters as $d) {
            $sql .= " OR `$wpdb->posts`.`post_content` LIKE '%#{$hashtag}{$d}%' ";
        }

        $sql.=")";

        return $sql;
    }

    public function build_reset() {
        global $wpdb;
        $wpdb->query("DELETE FROM {$wpdb->prefix}peepso_hashtags");
        delete_post_meta_by_key( self::POST_META );

    }

    public function peepso_check()
    {
        if (!class_exists('PeepSo')) {
            add_action('admin_notices', function(){
                ?>
                <div class="error peepso">
                    <strong>
                        <?php echo sprintf(__('The %s plugin requires the PeepSo plugin to be installed and activated.', 'peepso-hello-world'), self::PLUGIN_NAME);?>
                        <a href="<?php echo self::PEEPSOCOM_LICENSES;?>" target="_blank">
                            <?php _e('Get it now!', 'peepsohashtags');?>
                        </a>
                    </strong>
                </div>
                <?php
            });
            unset($_GET['activate']);
            deactivate_plugins(plugin_basename(__FILE__));
            return (FALSE);
        }

        // PeepSo.com license check
        if (!PeepSoLicense::check_license(self::PLUGIN_EDD, self::PLUGIN_SLUG)) {
            add_action('admin_notices', function() {
                PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG);
            });
        }

        if (isset($_GET['page']) && 'peepso_config' == $_GET['page'] && !isset($_GET['tab'])) {
            add_action('admin_notices', function() {
                PeepSo::license_notice(self::PLUGIN_NAME, self::PLUGIN_SLUG, true);
            });
        }

        // PeepSo.com new version check
        // since 1.7.6
        if(method_exists('PeepSoLicense', 'check_updates_new')) {
            PeepSoLicense::check_updates_new(self::PLUGIN_EDD, self::PLUGIN_SLUG, self::PLUGIN_VERSION, __FILE__);
        }

        return (TRUE);
    }

    public function enqueue_scripts()
    {
        #wp_enqueue_style('peepsohashtags', plugin_dir_url(__FILE__) . 'assets/css/hashtags.css', array('peepso'), self::PLUGIN_VERSION, 'all');
        wp_enqueue_script('peepso-hashtags', plugin_dir_url(__FILE__) . 'assets/js/bundle.min.js', array('peepso'), self::PLUGIN_VERSION, TRUE);
        wp_localize_script('peepso-hashtags', 'peepsohashtagsdata', array(
            'url' => PeepSoHashtagsPlugin::hashtag_url(),
            'min_length' => PeepSo::get_option('hashtags_min_length', PeepSoHashtagsPlugin::CONFIG_MIN_LENGTH),
            'max_length' => PeepSo::get_option('hashtags_max_length', PeepSoHashtagsPlugin::CONFIG_MAX_LENGTH),
            'must_start_with_letter' => PeepSo::get_option('hashtags_must_start_with_letter', 0)
        ));
    }

    public static function hashtag_url($hashtag = '') {

        // By default, use non-sef URL
        $questionmark="?";

        // If SEF URLs are enabled
        if (1 == PeepSo::get_option('disable_questionmark_urls', 0)) {

            // Make sure peepso_activity is NOT frontpage
            $frontpage = get_post(get_option('page_on_front'));

            // If it's NOT frontpage, it's safe tu use SEF
            if ('posts' == get_option( 'show_on_front' ) || !has_shortcode($frontpage->post_content, 'peepso_activity')) {
                $questionmark="";
            }
        }

        // Build and return URL
        $url = PeepSo::get_page('activity').$questionmark.'hashtag/'.$hashtag;
        if(strlen($hashtag)) {
            $url .='/';
        }


        return $url;
    }
}

PeepSoHashtagsPlugin::get_instance();

// EOF
