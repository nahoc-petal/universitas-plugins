<?php
require_once(PeepSo::get_plugin_dir() . DIRECTORY_SEPARATOR . 'lib' . DIRECTORY_SEPARATOR . 'install.php');

class PeepSoHashtagsInstall extends PeepSoInstall
{

    public function __construct() {
        return $this->plugin_activation(TRUE);
    }

	// optional default settings
	protected $default_config = array();

	public function plugin_activation( $is_core = FALSE )
	{
		parent::plugin_activation($is_core);

		return (TRUE);
	}

    // optional DB table creation
    public static function get_table_data()
    {
        $aRet = array(
            'hashtags' => "
				CREATE TABLE `hashtags` (
					`ht_id`		    BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
					`ht_name`		VARCHAR(128),
					`ht_count`		BIGINT(20) UNSIGNED NULL DEFAULT '0',
					`ht_last_count` DATETIME NULL,
					PRIMARY KEY (`ht_id`),
					UNIQUE INDEX (`ht_name`),
					INDEX (`ht_count`)
				) ENGINE=InnoDB",
        );

        return $aRet;
    }
}