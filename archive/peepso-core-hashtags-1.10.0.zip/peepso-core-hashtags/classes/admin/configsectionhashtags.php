<?php

class PeepSoConfigSectionHashtags extends PeepSoConfigSectionAbstract
{
	// Builds the groups array
	public function register_config_groups()
	{
        $this->context='left';
        $this->performance();

        $this->context='right';
        $this->advanced();

	}


    /**
     * General Settings Box
     */
    private function performance()
    {
        // Hashtag  post count refresh rate
        $options = array();
        for($i=5;$i<=30;$i+=5) {
            $options[$i]= "$i " . __('minutes', 'peepsohashtags');
            if(PeepSoHashtagsPlugin::CONFIG_POST_COUNT_INTERVAL==$i) { $options[$i].= ' ' . __('(default)','peepsohashtags'); }
        }

        $this->args('options', $options);
        $this->args('default', PeepSoHashtagsPlugin::CONFIG_POST_COUNT_INTERVAL);
        $this->args('descript', __('Deleted and edited posts are checked periodically to update post counts for each hashtag.', 'peepsohashtag').'<br/>'.__('Smaller delay means more database load.', 'peepsohashtags'));

        $this->set_field(
            'hashtags_post_count_interval',
            __('Update post count in tags every', 'peepsohashtags'),
            'select'
        );


        // Hashtag  post count refresh rate
        $options = array();

        for($i=5;$i<=100;$i+=5) {
            $options[$i]= "$i " . __('entries', 'peepsohashtags');
            if(PeepSoHashtagsPlugin::CONFIG_POST_COUNT_BATCH_SIZE==$i) { $options[$i].= ' ' . __('(default)','peepsohashtags'); }
        }

        $this->args('options', $options);
        $this->args('default', PeepSoHashtagsPlugin::CONFIG_POST_COUNT_BATCH_SIZE);
        $this->args('descript', __('How many posts and hashtags to process in a single page load.', 'peepsohashtag').'<br/>'.__('Bigger batches mean faster updates, but generate higher load.', 'peepsohashtags'));

        $this->set_field(
            'hashtags_post_count_batch_size',
            __('Process', 'peepsohashtags'),
            'select'
        );

        // Delete empty hashtags
        $this->args('default', 1);
        $this->args('descript', __('When enabled, hashtags with zero posts will be deleted and not shown in the widget or suggestions. ', 'peepsohashtags').'<br/>'.__('Hashtags with zero posts can occur, when posts are deleted or edited.','peepsohashtags'));

        $this->set_field(
            'hashtags_delete_empty',
            __('Delete empty hashtags', 'peepsohashtags'),
            'yesno_switch'
        );

        $this->set_group(
            'peepso_hashtags_performance',
            __('Performance', 'peepsohashtags')
        );
    }

    /**
     * General Settings Box
     */
    private function advanced()
    {
        // Hashtag  post count refresh rate
        $options = array();
        for($i=1;$i<=5;$i++) {
            $options[$i]= "$i " . _n('character','characters', $i,'peepsohashtags');
            if(PeepSoHashtagsPlugin::CONFIG_MIN_LENGTH==$i) { $options[$i].= ' ' . __('(default)','peepsohashtags'); }
        }

        $this->args('options', $options);
        $this->args('default', PeepSoHashtagsPlugin::CONFIG_MIN_LENGTH);
        $this->args('descript', __('Shorter hashtags will be ignored', 'peepsohashtag'));

        $this->set_field(
            'hashtags_min_length',
            __('Minimum hashtag length', 'peepsohashtags'),
            'select'
        );


        // Hashtag  post count refresh rate
        $options = array();

        for($i=5;$i<=64;$i++) {
            $options[$i]= "$i " . _n('characters','characters', $i,'peepsohashtags');
            if(PeepSoHashtagsPlugin::CONFIG_MAX_LENGTH==$i) { $options[$i].= ' ' . __('(default)','peepsohashtags'); }
        }

        $this->args('options', $options);
        $this->args('default', PeepSoHashtagsPlugin::CONFIG_MAX_LENGTH);
        $this->args('descript', __('Longer hashtags will be ignored', 'peepsohashtags'));

        $this->set_field(
            'hashtags_max_length',
            __('Maximum hashtag length', 'peepsohashtags'),
            'select'
        );

        // Start with letter
        $this->args('default', 0);
        $this->args('descript', __('Enabled: hashtags beginning with a number will be ignored','peepsohashtags'));

        $this->set_field(
            'hashtags_must_start_with_letter',
            __('Hashtags must start with a letter', 'peepsohashtags'),
            'yesno_switch'
        );

        // Rebuild
        $this->args('default', 0);
        $this->args('descript', __('Enable and click "save" to force a hashtag cache rebuild.','peepsohashtags').'<br/>'.__('It will also happen automatically after changing any of the settings above.','peepsohashtags'));

        $this->set_field(
            'hashtags_rebuild',
            __('Reset and rebuild the hashtags cache', 'peepsohashtags'),
            'yesno_switch'
        );

        $this->set_group(
            'peepso_hashtags_advanced',
            __('Advanced', 'peepsohashtags')
        );
    }


}